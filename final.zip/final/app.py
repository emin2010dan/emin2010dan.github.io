import os

from flask import Flask, flash, redirect, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash
from modules import load_csvs_to_df, get_filters, apology, login_required, checkpassword, dict_factory, show_records, controlcsv, pace_to_sec
import multipage_pdf
# from distutils.log import debug
from fileinput import filename


from werkzeug.utils import secure_filename
import csv

# import seaborn as sns
import pandas as pd

import sqlite3 as sql
import config as C
#from datetime import datetime

#from matplotlib.figure import Figure
#import base64
#from io import BytesIO


# Configure application
app = Flask(__name__)

# Configure upload file path flask
app.config['UPLOAD_FOLDER'] = C.UPLOAD_FOLDER
app.secret_key = 'Zr@5=6;2tmg690;y!kk?aIyyLp:%"8h.8wS/sdWKV+cfFG%&jCVAfDm*Ry'


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """ show home page """
    result, headerstr, err_message, df = show_records(C.DATABASE)
    if result:
        return render_template("home.html",
                               df=df,
                               headerstr=headerstr)
    else:
        return render_template("home.html", headerstr=err_message)


@app.route("/deletecsv", methods=["GET", "POST"])
@login_required
def deletecsv():
    """ delete csv page """
    if request.method == "POST":
        # Ensure username was submitted
        csv_id = request.form.get("csv_id")
        if not csv_id:
            return apology("No records deleted", 403)

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM csvs WHERE id = ? and user_id = ?", (csv_id, session["user_id"])).fetchall()
        except Exception as e:
            return apology(f"An error occurred while selecting records: {e}", 403)
        finally:
            cur.close()
            db.close()

        if len(rows) != 1:
            return apology("Record not found", 403)

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.execute(
                "DELETE  FROM csvs WHERE id = ? and user_id = ?", (csv_id, session["user_id"]))
            db.commit()
        except Exception as e:
            return apology(f"An error occurred while deleting records: {e}", 403)
        finally:
            cur.close()
            db.close()

        result, headerstr, err_message, df = show_records(C.DATABASE)
        if result:
            return render_template("deletecsv.html",
                                   df=df, headerstr=headerstr)
        else:
            return render_template("deletecsv.html", headerstr=err_message)

    else:
        result, headerstr, err_message, df = show_records(C.DATABASE)
        if result:
            return render_template("deletecsv.html",
                                   df=df, headerstr=headerstr)
        else:
            return render_template("deletecsv.html", headerstr=err_message)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    session.pop('user_id', None)
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        useradi = request.form.get("username")

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?",
                (useradi,)).fetchall()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)
        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        # Redirect user to home page
        return redirect("/")
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""
    # Forget any user_id
    session.pop('user_id', None)
    # Redirect user to login form
    return redirect("/")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    # Forget any user_id
    # session.clear()
    session.pop('user_id', None)

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        # Ensure password was submitted
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)

        result, message = checkpassword(request.form.get("password"))
        if not result:
            return apology(message, 400)

        if request.form.get("confirmation") != request.form.get("password"):
            return apology("confirmatiom is not correct", 400)

        # Query database for username
        useradi = request.form.get("username")

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?",
                (useradi,)).fetchall()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Ensure username does no exists and password is correct
        if len(rows) != 0:
            return apology("already registered", 400)

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.execute(
                "INSERT INTO users(username,hash) VALUES (?,?)",
                (request.form.get("username"),
                 generate_password_hash(request.form.get("password"))))
            iuserid = cur.lastrowid
            db.commit()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Remember which user has logged in
        session["user_id"] = iuserid

        # Redirect user to home page
        return redirect("/")
    else:
        return render_template("register.html")


@app.route("/changepassword", methods=["GET", "POST"])
@login_required
def changepassword():
    """change password"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        if not request.form.get("oldpassword"):
            return apology("must provide current password", 400)

        # Ensure new password was submitted
        elif not request.form.get("newpassword"):
            return apology("must provide new password", 400)

        # Ensure conformation  was submitted
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)

        result, message = checkpassword(request.form.get("newpassword"))
        if not result:
            return apology(message, 400)

        if request.form.get("confirmation") != request.form.get("newpassword"):
            return apology("confirmatiom is not correct", 400)

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rusers = cur.execute(
                "SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchall()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists
        if len(rusers) != 1:
            return apology("invalid userid", 400)

        # Ensure username exists and password is correct
        if not check_password_hash(rusers[0]["hash"], request.form.get("oldpassword")):
            return apology("invalid  password", 403)

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.execute("UPDATE users SET hash = ? WHERE id = ?",
                        (generate_password_hash(request.form.get("newpassword")), session["user_id"]))
            db.commit()
        except Exception as e:
            return apology(f"An error occurred while updating records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("changepassword.html")


@app.route("/loadcsv", methods=["GET", "POST"])
@login_required
def loadcsv():
    """load csv"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # upload file flask
        f = request.files.get('file')

        if not f:
            return apology("must provide file name", 400)

        # Extracting uploaded file name
        data_filename = secure_filename(f.filename)
        save_filename = os.path.join(app.config['UPLOAD_FOLDER'],
                                     str(session["user_id"]) + "_" + data_filename)

        f.save(save_filename)
        print("===loadcsv : saved file name:", save_filename)
        df = pd.read_csv(save_filename)
        if not controlcsv(df, C.CONTROLLIST):
            os.remove(save_filename)
            return apology("Column name error in csv", 400)

        mindate = df['Date'].min().split()[0]
        maxdate = df['Date'].max().split()[0]
        record_num = len(df)

        try:
            db = sql.connect(C.DATABASE)
            cur = db.cursor()
            cur.execute(
                "REPLACE INTO csvs(csv_name,csv_path,user_id,mindate,maxdate,record_num) VALUES (?,?,?,?,?,?)",
                (data_filename, save_filename, session["user_id"], mindate, maxdate, record_num))
            db.commit()
        except Exception as e:
            return apology(f"An error occurred while inserting records: {e}", 403)
        finally:
            cur.close()
            db.close()

        headerstr = f" Number of records:{record_num}    From:{mindate}    To:{maxdate}"
        return render_template("loadedcsv.html",
                               table=df.to_html(
                                   max_rows=3, classes='table fs_table table-bordered table-secondary table-striped'),
                               headerstr=headerstr)

    else:

        result, headerstr, err_message, df = show_records(C.DATABASE)
        if result:
            return render_template("loadcsv.html",
                                   df=df,
                                   headerstr=headerstr)
        else:
            return render_template("loadcsv.html", headerstr=err_message)


@app.route("/graphs1", methods=["GET", "POST"])
@login_required
def graphs1():
    """display graphs I"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        result, errmsg, dfdic,df = get_filters()
        if not result:
            return apology(errmsg, 403)

        print("-----------------dfdic--------------")
        print(dfdic)

        pdfname = "./static/images/u" + \
            str(session["user_id"]) + "graph1_pdf.pdf"
        dfdic["pdfname"] = pdfname

        multipage_pdf.multipage_pdf(df, dfdic)

        return render_template('graphs1show.html', pdfname=pdfname)

    else:
        result, err_message, df = load_csvs_to_df()
        if not result:
            return apology(err_message, 403)

        mindate = df['Date'].min().split()[0]
        maxdate = df['Date'].max().split()[0]
        minyear = mindate.split("-")[0]
        maxyear = maxdate.split("-")[0]
        minmonth = mindate.split("-")[1]
        maxmonth = maxdate.split("-")[1]

        minpace_m = 1
        minpace_s = 30
        pacestep = 3

        return render_template("graphs1.html", mindate=mindate, maxdate=maxdate,
                               minmonth=minmonth, minyear=minyear,
                               maxmonth=maxmonth, maxyear=maxyear,
                               minpace_m=minpace_m, minpace_s=minpace_s,
                               pacestep=pacestep,
                               show_pace=True
                               )


@app.route("/graphs2", methods=["GET", "POST"])
@login_required
def graphs2():
    """display graphs 2"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        result, errmsg, dfdic,df = get_filters()
        if not result:
            return apology(errmsg, 403)

        print("-----------------dfdic--------------")
        print(dfdic)

        pdfname = "./static/images/u" + \
            str(session["user_id"]) + "graph2_pdf.pdf"
        dfdic["pdfname"] = pdfname

        multipage_pdf.multipage_pdf(df, dfdic)

        return render_template('graphs2show.html', pdfname=pdfname)

    else:
        result, err_message, df = load_csvs_to_df()
        if not result:
            return apology(err_message, 403)

        mindate = df['Date'].min().split()[0]
        maxdate = df['Date'].max().split()[0]
        minyear = mindate.split("-")[0]
        maxyear = maxdate.split("-")[0]
        minmonth = mindate.split("-")[1]
        maxmonth = maxdate.split("-")[1]

        minwatt = 40
        wattstep = 5

        return render_template("graphs2.html", mindate=mindate, maxdate=maxdate,
                               minmonth=minmonth, minyear=minyear,
                               maxmonth=maxmonth, maxyear=maxyear,
                               minwatt=minwatt,
                               wattstep=wattstep,
                               show_watt=True
                               )


@app.route("/graphs3", methods=["GET", "POST"])
@login_required
def graphs3():
    """display graphs 3"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        result, errmsg, dfdic,df = get_filters()
        if not result:
            return apology(errmsg, 403)

        print("-----------------dfdic--------------")
        print(dfdic)

        pdfname = "./static/images/u" + \
            str(session["user_id"]) + "graph3_pdf.pdf"
        dfdic["pdfname"] = pdfname

        multipage_pdf.multipage_pdf(df, dfdic)

        return render_template('graphs3show.html', pdfname=pdfname)

    else:
        result, err_message, df = load_csvs_to_df()
        if not result:
            return apology(err_message, 403)

        mindate = df['Date'].min().split()[0]
        maxdate = df['Date'].max().split()[0]
        minyear = mindate.split("-")[0]
        maxyear = maxdate.split("-")[0]
        minmonth = mindate.split("-")[1]
        maxmonth = maxdate.split("-")[1]

        mincalhr = 350
        calstep = 25

        return render_template("graphs3.html", mindate=mindate, maxdate=maxdate,
                               minmonth=minmonth, minyear=minyear,
                               maxmonth=maxmonth, maxyear=maxyear,
                               mincalhr=mincalhr,
                               calstep=calstep,
                               show_cal=True
                               )


if __name__ == '__main__':
    app.run(debug=True)
