import os


from flask import Flask, flash, redirect, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash
from modules import apology, login_required, checkpassword
import multipage_pdf 
# from distutils.log import debug
from fileinput import filename

from werkzeug.utils import secure_filename
import csv

# import seaborn as sns
import pandas as pd

import sqlite3 as sql
#from datetime import datetime

#from matplotlib.figure import Figure
#import base64
#from io import BytesIO



UPLOAD_FOLDER = './uploads'

# Define allowed files
ALLOWED_EXTENSIONS = {'csv'}

# Configure application
app = Flask(__name__)

# Configure upload file path flask
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'Zr@5=6;2tmg690;y!kk?aIyyLp:%"8h.8wS/sdWKV+cfFG%&jCVAfDm*Ry'


# SQLite database file path
DATABASE = "./final.db"
CONTROLLIST = ['Log ID', 'Date', 'Description', 'Work Time (Formatted)',
               'Work Time (Seconds)', 'Rest Time (Formatted)', 'Rest Time (Seconds)',
               'Work Distance', 'Rest Distance', 'Stroke Rate/Cadence', 'Stroke Count',
               'Pace', 'Avg Watts', 'Cal/Hour', 'Total Cal', 'Avg Heart Rate',
               'Drag Factor', 'Age', 'Weight', 'Type', 'Ranked', 'Comments',
               'Date Entered']
TYPELIST = [ "BikeErg","RowErg","On-snow","On-water","Paddle Adapter",
            "SkiErg"]



def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


def show_records():
    """ show loadad csv records """
    headerstr, err_message = "",""
    df=pd.DataFrame()
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        df = pd.DataFrame.from_dict(cur.execute(
            "SELECT * FROM csvs WHERE user_id = ? ORDER BY mindate", (session["user_id"],)).fetchall())
    except Exception as e:
        err_message = f"An error occured while selecting records:{e}"
        return False,headerstr, err_message,df
    finally:
        cur.close()
        db.close()

    if len(df) > 0:
        mindate = df['mindate'].min()
        maxdate = df['maxdate'].max()
        record_num = df['record_num'].sum()
        headerstr = f" Number of Loaded Csv Records:{record_num}    From:{mindate}    To:{maxdate}"
        df.drop('user_id', inplace=True, axis=1)

        for i in range(len(df)):
            df.loc[i, 'csv_name'] = os.path.basename(
                df.loc[i, 'csv_name']).split("_")[1]

    else:
        headerstr = "No Csv Records Loaded Yet"
    return True,headerstr, err_message,df


@app.route("/")
@login_required
def index():
    """ show home page """
    result,headerstr,err_message,df=show_records()
    if result:
        return render_template("home.html",
                               table=df.to_html(
                                   classes='table table-bordered table-secondary table-striped'),
                               headerstr=headerstr)
    else:
        return render_template("home.html", headerstr=err_message)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    session.pop('user_id', None)

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        useradi = request.form.get("username")

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?",
                (useradi,)).fetchall()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.pop('user_id', None)

    # Redirect user to login form
    return redirect("/")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    # Forget any user_id
    # session.clear()
    session.pop('user_id', None)

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        # Ensure password was submitted
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)

        result, message = checkpassword(request.form.get("password"))
        if not result:
            return apology(message, 400)

        if request.form.get("confirmation") != request.form.get("password"):
            return apology("confirmatiom is not correct", 400)

        # Query database for username
        useradi = request.form.get("username")

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?",
                (useradi,)).fetchall()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Ensure username does no exists and password is correct
        if len(rows) != 0:
            return apology("already registered", 400)

        #

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.execute(
                "INSERT INTO users(username,hash) VALUES (?,?)",
                (request.form.get("username"),
                 generate_password_hash(request.form.get("password"))))
            iuserid = cur.lastrowid
            db.commit()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Remember which user has logged in
        session["user_id"] = iuserid

        # Redirect user to home page
        return redirect("/")
    else:
        return render_template("register.html")


@app.route("/changepassword", methods=["GET", "POST"])
@login_required
def changepassword():
    """change password"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        if not request.form.get("oldpassword"):
            return apology("must provide current password", 400)

        # Ensure new password was submitted
        elif not request.form.get("newpassword"):
            return apology("must provide new password", 400)

        # Ensure conformation  was submitted
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)

        result, message = checkpassword(request.form.get("newpassword"))
        if not result:
            return apology(message, 400)

        if request.form.get("confirmation") != request.form.get("newpassword"):
            return apology("confirmatiom is not correct", 400)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rusers = cur.execute(
                "SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchall()
        except Exception as e:
            return apology(f"An error occurred while listing records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists
        if len(rusers) != 1:
            return apology("invalid userid", 400)

        # Ensure username exists and password is correct
        if not check_password_hash(rusers[0]["hash"], request.form.get("oldpassword")):
            return apology("invalid  password", 403)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.execute("UPDATE users SET hash = ? WHERE id = ?",
                        (generate_password_hash(request.form.get("newpassword")), session["user_id"]))
            db.commit()
        except Exception as e:
            return apology(f"An error occurred while updating records: {e}", 403)
        finally:
            cur.close()
            db.close()

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("changepassword.html")


def controlcsv(df):
    """control csv headers"""
    seqlist = df.keys()

    for i in range(len(seqlist)):
        if seqlist[i] != CONTROLLIST[i]:
            return False
    return True


@app.route("/loadcsv", methods=["GET", "POST"])
@login_required
def loadcsv():
    """load csv"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # upload file flask
        f = request.files.get('file')

        if not f:
            return apology("must provide file name", 400)

        # Extracting uploaded file name
        data_filename = secure_filename(f.filename)
        save_filename = os.path.join(app.config['UPLOAD_FOLDER'],
                                     str(session["user_id"]) + "_" + data_filename)

        f.save(save_filename)
        print("===loadcsv : saved file name:",save_filename)
        df = pd.read_csv(save_filename)
        if not controlcsv(df):
            os.remove(save_filename)
            return apology("Column name error in csv", 400)

        mindate = df['Date'].min().split()[0]
        maxdate = df['Date'].max().split()[0]
        record_num = len(df)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.execute(
                "REPLACE INTO csvs(csv_name,user_id,mindate,maxdate,record_num) VALUES (?,?,?,?,?)",
                (save_filename, session["user_id"], mindate, maxdate, record_num))
            db.commit()
        except Exception as e:
            return apology(f"An error occurred while inserting records: {e}", 403)
        finally:
            cur.close()
            db.close()

        headerstr = f" Number of records:{record_num}    From:{mindate}    To:{maxdate}"
        return render_template("loadedcsv.html",
                               table=df.to_html(
                                   max_rows=3, classes='table fs_table table-bordered table-secondary table-striped'),
                               headerstr=headerstr)
    else:

        result,headerstr,err_message,df=show_records()
        if result:
            return render_template("loadcsv.html",
                                   table=df.to_html(
                                       classes='table table-bordered table-secondary table-striped'),
                                   headerstr=headerstr)
        else:
            return render_template("loadcsv.html", headerstr=err_message)


def load_csvs_to_df():
    """ load all csvs to df """
    df=pd.DataFrame()
    err_message=""
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        rows = cur.execute(
            "SELECT * FROM csvs WHERE user_id = ? ORDER BY mindate", (session["user_id"],)).fetchall()
    except Exception as e:
        err_message = f"An error occurred while listing records: {e}"
        return False,err_message,df
    finally:
        cur.close()
        db.close()

    df = pd.DataFrame()
    for i in range(len(rows)):
        csv_name_filename = rows[i]["csv_name"]
        print("===load_csv_to_df : csv name:",csv_name_filename)
        csv_df = pd.read_csv(csv_name_filename)
        if not controlcsv(df):
            err_message = "Column name error in csv " + csv_name_filename
            return False,err_message,df
        df = pd.concat([df, csv_df],
                       ignore_index=True)
    return True,err_message,df

def pace_to_sec(pace_str):
    """ convert pace to sec """
    try:
        sec_m =  int(pace_str.split(":")[0])
        if sec_m > 4:
            sec_m = 4
        sec_s =  round(float(pace_str.split(":")[1]))
        if sec_s > 59:
            sec_s = 59
        sec_t = (sec_m * 60) + sec_s
        return True, sec_t,sec_m,sec_s
    except:
        return False,0,0,0      
    

def filter_df(df):
    """ filter df acording to filters.html """

    #create new columns

    date1=request.form.get("date1")
    date2=request.form.get("date2")

    if not date1:
            return False,"must provide begining date",df

    if not date2:
            return False,"must provide end date",df
    
    if not date2 >= date1 :
            return False,"ending date must greater than begining date", df
    
    mindate = date1 + " 00:00:00"
    maxdate = date2 + " 23:59:59"

    #print("mintarih oncesi df  boyutu ",len(df)," mindate="+mindate+"maxdate="+maxdate)
    #print("df===================================================================")
    #df2=df["Date"]
    #print(df2.iloc[0])

    indexdrop = df[ df['Date'] < mindate ].index
    df.drop(indexdrop , inplace=True)
    #print("mintarih df tarih filt yeni boyutu ",len(df))

    #print("maxtarih oncesi df  boyutu ",len(df)," mindate=",mindate," maxdate=",maxdate)
    indexdrop = df[ df['Date'] > maxdate ].index
    df.drop(indexdrop , inplace=True)
    #print("maxtarih df tarih filt yeni boyutu ",len(df))

    get_type=[]
    for i in range(len(TYPELIST)):
        if not request.form.get(TYPELIST[i]):
            get_type.append(TYPELIST[i])

    if  "RowErg" in get_type:
        get_type.append("Dynamic RowErg")
        get_type.append("RowErg on Slides")
                 
    if  "On-snow" in get_type:
        get_type.append("Rollerski")              
    print("gettype=",get_type)

    #indexdrop = df[ (df['Type'] not in get_type).bool() ].index
    #df.drop(indexdrop , inplace=True)
    for i in get_type:
        indexdrop = df[ df['Type'] == i ].index
        df.drop(indexdrop , inplace=True)

    #print("df get type filt yeni boyutu ",len(df))
 
    #add Pace(secs)
    pace_sec=[]
    pace_grp=[]
    for i in range(len(df)):
        result,sec_t,sec_m,sec_s=pace_to_sec(df["Pace"].iloc[i])  

        pace_grp.append(str(sec_m)+":"+str(sec_s))
        pace_sec.append(sec_t)
        #print("df degeri=",df["Pace"].iloc[i], " sec =",sec_t)
    df["Pace(sec)"] = pace_sec
    df["Pace(m:s)"] = pace_grp

  


    return True," ",df









@app.route("/graphs1", methods=["GET", "POST"])
@login_required
def graphs1():
    """display graphs I"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":


        result,err_message,df=load_csvs_to_df()
        if not result:
            return apology(err_message, 403)

        mindate = df['Date'].min().split()[0]
        maxdate = df['Date'].max().split()[0]
        record_num = len(df)

        headerstr = f" Number of records:{record_num}    From:{mindate}    To:{maxdate}"
        print(headerstr)

        result,err_message,df=filter_df(df)
        print("filter dan donen df  boyutu ",len(df))
        if not result:
            return apology(err_message, 403)
        
        """ create image without save
        fig = Figure()
        ax = fig.subplots()

        # plotting a histogram
        ax.hist(df["Work Distance"])

        # Save it to a temporary buffer.
        buf = BytesIO()
        fig.savefig(buf, format="png")
        # Embed the result in the html output.
        data = base64.b64encode(buf.getbuffer()).decode("ascii")
        """


        pdfname="./static/images/u" + str(session["user_id"]) + "graph1_pdf.pdf"
        dfdic={}
        dfdic["pdfname"]= pdfname
        dfdic["maintitle"]="Multipage pdf example"
        dfdic["titles"] = ["title 1","title 2","title 3"]
        dfdic["author"] = 'emin2010'
        dfdic["subject"] = 'cs50 final project,analysis of sport data'
        dfdic["keywords"] = 'rowing cycling analysis graphs'
        multipage_pdf.multipage_pdf(df,dfdic)

        return render_template('graphs1show.html', pdfname = pdfname) 

    else:
        result,err_message,df=load_csvs_to_df()
        if not result:
            return apology(err_message, 403)

        mindate = df['Date'].min().split()[0]
        maxdate = df['Date'].max().split()[0]

        return render_template("graphs1.html",mindate=mindate, maxdate=maxdate)


if __name__ == '__main__':
    app.run(debug=True)
