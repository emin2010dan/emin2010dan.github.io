"""
=============
Multipage PDF
=============

"""

import datetime
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
from modules import pace_to_sec,sec_to_pace
import pandas as pd
import config as C

# Create the PdfPages object to which we will save the pages:
# The with statement makes sure that the PdfPages object is closed properly at
# the end of the block, even if an Exception occurs.



def multipage_pdf(df,dfdic):
    """
    -----------------dfdic--------------
    {
    'keywords': 'analysis graphs  RowErg BikeErg On-water  Report_Type:season-report  From_pace:1:30 steps:2  seperate:both  conver_cycling_kms:no', 
    'filter_msgs': ['Total Number of records:5321', "Deleted types:['SkiErg', 'On-snow', 'Paddle Adapter', 'Rollerski']", 'After type filtering,Number of records:5317', 'Report_Type:season-report', ' From_pace:1:30 steps:2', 'seperate:both', 'conver_cycling_kms:no'], 
    'typelist': ['RowErg', 'BikeErg', 'On-water'], 
    'Report_Type': 'season-report', 
    'min_pace_m': '1', 
    'min_pace_s': '30', 
    'pacestep': '2', 
    'seperate': 'both', 
    'conver_cycling_kms': 'no'
    } 

    """



    with PdfPages(dfdic["pdfname"]) as pdf:

        
        """initialize total arrays
        y_coord 
           row icin  mt season degerleri
           bike icin mt season degerleri
           ...
                    x_coord = sesason_lst    
        """

        g1x_season_lst = []
        g1_1y_totm_of_types = {}
        g1_2y_tots_of_types = {}
        for t in dfdic["typelist"]:
            g1_1y_totm_of_types[t]=[]
            g1_2y_tots_of_types[t]=[]


        g2x_pace_lst = []
        g2_1y_totm_of_types = {}
        g2_2y_tots_of_types = {}
        for t in dfdic["typelist"]:
            g2_1y_totm_of_types[t]=[]
            g2_2y_tots_of_types[t]=[]

        graph_pace_sec = (int(dfdic["min_pace_m"]) * 60) + int(dfdic["min_pace_s"])
        for i in range(C.MAX_BINS):
            g2x_pace_lst.append(graph_pace_sec)
            graph_pace_sec += int(dfdic["pacestep"])
            # iniyialize pace totals
            for t in dfdic["typelist"]:
                g2_1y_totm_of_types[t].append(0)
                g2_2y_tots_of_types[t].append(0)


        #create extra pace columns in df 
        
        pace_sec = []
        season_lst = []
        work_type = []

        """----------- filter and summary ---------"""
        for i in range(len(df)):
            dfr = df.iloc[i]

            wtype = dfr["Type"]
            if wtype == "Dynamic RowErg":
                wtype = "RowErg"
            elif wtype == "RowErg on Slides":
                wtype = "RowErg"     
            elif wtype == "Rollerski":
                wtype = "On-snow"
            work_type.append(wtype)    

            result, sec_t, sec_m, sec_s = pace_to_sec(dfr["Pace"])
            pace_sec.append(sec_t)

            # find season yyyy-mm-dd 00:00:00
            wdate =  dfr['Date'].split()[0]
            season = int(wdate.split("-")[0])
            month =  int(wdate.split("-")[1])
            if month> 4:
                season = season + 1
            season_lst.append(season) 

            real_meter = dfr["Work Distance"]
            # find real meters
            if wtype == "BikeErg":
                if dfdic["conver_cycling_kms"] == "yes": 
                   real_meter = round(real_meter / 2.0) 

            # seperate warmup
            if  dfdic["seperate"] != "both":
                warm_pace_sec = (int(dfdic["warm_pace_m"]) * 60) + int(dfdic["warm_pace_s"])
                if (sec_t > warm_pace_sec) and dfdic["seperate"] == "workout":
                    continue
                elif (sec_t <= warm_pace_sec) and dfdic["seperate"] == "warmup":
                    continue




            # calculate season totals
            if season not in g1x_season_lst:
                g1x_season_lst.append(season)
                for t in dfdic["typelist"]:
                    g1_1y_totm_of_types[t].append(0)
                    g1_2y_tots_of_types[t].append(0)

            # seasona ait indexi bul ve toplamları ekle
            for si in range(len(g1x_season_lst)):
                if g1x_season_lst[si] == season:
                    g1_1y_totm_of_types[wtype][si] += real_meter
                    g1_2y_tots_of_types[wtype][si] += dfr["Work Time (Seconds)"]


            # pace e ait indexi bul ve toplamları ekle
            found = False
            for si in range(len(g2x_pace_lst)):
                if g2x_pace_lst[si] >= sec_t:
                    g2_1y_totm_of_types[wtype][si] += real_meter
                    g2_2y_tots_of_types[wtype][si] += dfr["Work Time (Seconds)"]
                    found = True
                    break
            if not found:
                g2_1y_totm_of_types[wtype][len(g2x_pace_lst)-1] += real_meter
                g2_2y_tots_of_types[wtype][len(g2x_pace_lst)-1] += dfr["Work Time (Seconds)"]
                



        df["Pace(sec)"] = pace_sec
        df["Season"] = season_lst
        df["Work_Type"] = work_type 

        # convert seasonal sec to hour
        for si in range(len(g1x_season_lst)):
            for t in dfdic["typelist"]:
                g1_2y_tots_of_types[t][si]= round(g1_2y_tots_of_types[t][si] / 3600)

        # convert seasonal mt to km
        for si in range(len(g1x_season_lst)):
            for t in dfdic["typelist"]:
                g1_1y_totm_of_types[t][si]= round(g1_1y_totm_of_types[t][si] / 1000)    

        # convert pace sec to hour
        for si in range(len(g2x_pace_lst)):
            for t in dfdic["typelist"]:
                g2_2y_tots_of_types[t][si]= round(g2_2y_tots_of_types[t][si] / 3600)

        # convert pace mt to km
        for si in range(len(g2x_pace_lst)):
            for t in dfdic["typelist"]:
                g2_1y_totm_of_types[t][si]= round(g2_1y_totm_of_types[t][si] / 1000) 

        # find string type of x coord 1 season
        g1x_season_str = []
        for i in range(len(g1x_season_lst)):
            g1x_season_str.append(str(g1x_season_lst[i]))

        # find string type of x coord 2 pace
        g2x_pace_str = []
        for i in range(len(g2x_pace_lst)):
            result, res_pace_str = sec_to_pace(g2x_pace_lst[i])  
            if result:
                g2x_pace_str.append(res_pace_str)
        
        """
        plt.figure(figsize=(10, 6))
        plt.xticks(rotation=90)
        gdf = pd.DataFrame(g1_1y_totm_of_types , index=g1x_season_lst)

        ax = gdf.plot.bar(stacked=True)
        plt.xlabel('Pace(sec)')
        plt.ylabel('Workout Kms')
        plt.title("Kms By Season")

        ax.bar_label(ax.containers[0], label_type='edge')
        """

        """------------------------ season graph 1 -----------------------"""
        plt.style.use('seaborn')
        width = 0.4 # the width of the bars: can also be len(x) sequence

        fig, ax = plt.subplots()
        
        bottom = np.zeros(len(g1x_season_str))

        for wtype, wkms in g1_1y_totm_of_types.items():
            p = ax.bar(g1x_season_str, wkms, width, label=wtype, bottom=bottom)
            bottom += wkms
            ax.bar_label(p, label_type='center')

        ax.set_title('Kms By Season')
        plt.xlabel('Season')
        plt.ylabel('Workout Kms')
        ax.legend()

        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()


        """ ---------------- season graphs 2-------------------"""
        # if LaTeX is not installed or error caught, change to `False`
        plt.rcParams['text.usetex'] = False

        plt.style.use('seaborn')

        width = 0.4 # the width of the bars: can also be len(x) sequence

        fig, ax = plt.subplots()
        
        bottom = np.zeros(len(g1x_season_str))

        for wtype, whours in g1_2y_tots_of_types.items():
            p = ax.bar(g1x_season_str, whours, width, label=wtype, bottom=bottom)
            bottom += whours
            ax.bar_label(p, label_type='center')

        ax.set_title('Hours By Season')
        plt.xlabel('Season')
        plt.ylabel('Workout Hours')
        ax.legend()

        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()

        """ ----------pace graphs--meter --------------"""        
  
        # if LaTeX is not installed or error caught, change to `False`
        plt.rcParams['text.usetex'] = False

        plt.style.use('seaborn')

        fig, ax = plt.subplots()
        ax.stackplot(g2x_pace_str, g2_1y_totm_of_types.values(),
                    labels=g2_1y_totm_of_types.keys(), alpha=0.8)
        #ax.legend(loc='upper left', reverse=True)
        ax.legend(loc='upper left')

        fig.autofmt_xdate(rotation=90)
        ax.set_title('Kms By Pace')
        plt.xlabel('Pace')
        plt.ylabel('Workout Kms')
        ax.legend()


        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()



        """ ----------pace graphs----------------"""        
  
        # if LaTeX is not installed or error caught, change to `False`
        plt.rcParams['text.usetex'] = False

        plt.style.use('seaborn')

        fig, ax = plt.subplots()
        ax.stackplot(g2x_pace_str, g2_2y_tots_of_types.values(),
                    labels=g2_2y_tots_of_types.keys(), alpha=0.8)
        #ax.legend(loc='upper left', reverse=True)
        ax.legend(loc='upper left')

        fig.autofmt_xdate(rotation=90)
        ax.set_title('Hours By Pace')
        plt.xlabel('Pace')
        plt.ylabel('Workout Hours')
        ax.legend()


        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()


    

        """ --------------- last page --------------------"""

        plt.rcParams['text.usetex'] = False
        fig = plt.figure(figsize=(10, 6))
        fig.clf()
        xcor=1 - 0.05
        for txt in dfdic["filter_msgs"]:
            fig.text(0.5, xcor,txt,  size=10, ha="center")
            xcor = xcor - 0.05

        pdf.savefig(fig)  # or you can pass a Figure object to pdf.savefig
        plt.close()




        # We can also set the file's metadata via the PdfPages object:
        d = pdf.infodict()
        d['Title'] = dfdic["maintitle"]
        d['Author'] = dfdic["author"]
        d['Subject'] = dfdic["subject"]
        d['Keywords'] = dfdic["keywords"] 
        d['CreationDate'] = datetime.datetime(2009, 11, 13)
        d['ModDate'] = datetime.datetime.today()
