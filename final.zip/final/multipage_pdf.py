"""
=============
Multipage PDF
=============

"""

import datetime
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
from modules import pace_to_sec,sec_to_pace
import pandas as pd
import config as C
from dateutil.relativedelta import relativedelta
from multipage_mdl import create_tot_of_types,convert_daystr,convert_numstr

# Create the PdfPages object to which we will save the pages:
# The with statement makes sure that the PdfPages object is closed properly at
# the end of the block, even if an Exception occurs.



def multipage_pdf(df,dfdic):
    """
    -----------------dfdic--------------
    {'keywords': 'analysis pacegraphs  RowErg  Report_Type:day-report from:2018-03-05 compare:2018-03-08  From_pace:1:30 steps:3  seperate:both  conver_cycling_kms:no', 'graphmenu': 'pace', 
    'filter_msgs': ['Total Number of records:5321', "Deleted types:['BikeErg', 'SkiErg', 'On-water', 'On-snow', 'Paddle Adapter', 'Rollerski']", 'After type filtering,Number of records:3637', 'Report_Type:day-report', 'From:2018-03-05', 'Compare:2018-03-08', ' From_pace:1:30 steps:3', 'seperate:both', 'conver_cycling_kms:no'], 
    'typelist': ['RowErg'], 
    'Report_Type': 'day-report', 
    'date1': '2018-03-05', 
    'date3': '2018-03-08', 
    'min_pace_m': '1', 
    'min_pace_s': '30', 
    'pacestep': '3', 
    'seperate': 'both', 
    'conver_cycling_kms': 'no'
    }

    """



    with PdfPages(dfdic["pdfname"]) as pdf:

        
        """initialize total arrays
        y_coord 
           row icin  mt season degerleri
           bike icin mt season degerleri
           ...
                    x_coord = sesason_lst    
        """
        #initilize graph 1 variables.. 2 seson graphs
        g1x_season_lst,g1_1y_tot_of_types,g1_2y_tot_of_types=create_tot_of_types(dfdic)

        #initialize graph 2 vars. 2 pace graphs
        if dfdic["graphmenu"]== "pace":
            g2x_lst,g2_1y_tot_of_types, g2_2y_tot_of_types=create_tot_of_types(dfdic)
            #initialize graph2  cloumn vars
            graph_pace_sec = (int(dfdic["min_pace_m"]) * 60) + int(dfdic["min_pace_s"])
            for i in range(C.MAX_BINS):
                g2x_lst.append(graph_pace_sec)
                graph_pace_sec += int(dfdic["pacestep"])
                # iniyialize pace totals
                for t in dfdic["typelist"]:
                    g2_1y_tot_of_types[t].append(0)
                    g2_2y_tot_of_types[t].append(0)

        #initialize graph 2 vars.watte graphs
        if dfdic["graphmenu"]== "watt":
            g2x_lst,g2_1y_tot_of_types, g2_2y_tot_of_types=create_tot_of_types(dfdic)
            #initialize graph2  cloumn vars
            graph_watt = int(dfdic["min_watt"])
            for i in range(C.MAX_BINS):
                g2x_lst.append(graph_watt)
                graph_watt += int(dfdic["wattstep"])
                # iniyialize pace totals
                for t in dfdic["typelist"]:
                    g2_1y_tot_of_types[t].append(0)
                    g2_2y_tot_of_types[t].append(0)

        #initialize graph 2 vars.cal graphs
        if dfdic["graphmenu"]== "cal":
            g2x_lst,g2_1y_tot_of_types, g2_2y_tot_of_types=create_tot_of_types(dfdic)
            #initialize graph2  cloumn vars
            graph_watt = int(dfdic["min_calhr"])
            for i in range(C.MAX_BINS):
                g2x_lst.append(graph_watt)
                graph_watt += int(dfdic["calstep"])
                # iniyialize pace totals
                for t in dfdic["typelist"]:
                    g2_1y_tot_of_types[t].append(0)
                    g2_2y_tot_of_types[t].append(0)


        # day report or week report 
        if dfdic["Report_Type"] == "day-report" or dfdic["Report_Type"] == "week-report":
            g3x_lst = []
            g3_1y_tot = []
            g3_2y_tot = []
            #initialize graph3  x cloumn vars 'date1': '2018-03-05'
            real_date1  = datetime.datetime.strptime(dfdic['date1'],"%Y-%m-%d")
            graph_date  = real_date1 
            for i in range(C.MAX_BINS):
                g3x_lst.append(graph_date)
                if dfdic["Report_Type"] == "week-report":
                    graph_date = graph_date +  datetime.timedelta(days=7)
                else:
                    graph_date = graph_date +  datetime.timedelta(days=1)
                # iniyialize totals
                g3_1y_tot.append(0)
                g3_2y_tot.append(0)
            # last day of report
            if dfdic["Report_Type"] == "week-report":
                real_date1end  = g3x_lst[C.MAX_BINS -1] + datetime.timedelta(days=6)
            else:    
                real_date1end  = g3x_lst[C.MAX_BINS -1]
            # compare ?
            if dfdic["compare_graph"]:
                g4x_lst = []
                g4_1y_tot = []
                g4_2y_tot = []
                #initialize graph3  x cloumn vars 'date1': '2018-03-05'
                real_date3  = datetime.datetime.strptime(dfdic['date3'],"%Y-%m-%d")
                graph_date  = real_date3 
                for i in range(C.MAX_BINS):
                    g4x_lst.append(graph_date)
                    if dfdic["Report_Type"] == "week-report":
                        graph_date = graph_date +  datetime.timedelta(days=7)
                    else:
                        graph_date = graph_date +  datetime.timedelta(days=1)
                    # iniyialize totals
                    g4_1y_tot.append(0)
                    g4_2y_tot.append(0)
                # last day of report
                if dfdic["Report_Type"] == "week-report":
                    real_date3end  = g4x_lst[C.MAX_BINS -1] + datetime.timedelta(days=6)
                else:  
                    real_date3end = g4x_lst[C.MAX_BINS -1]                        


        # month report or 3month report 
        if dfdic["Report_Type"] == "month-report" or dfdic["Report_Type"] == "3month-report":
            g3mx_month_lst = []
            g3m_1y_tot = []
            g3m_2y_tot = []
            #initialize graph3  x cloumn vars 'date1': '2018-03-05'
            real_date1  = datetime.datetime.strptime(dfdic['year1']+"-"+dfdic["month1"]+"-01","%Y-%m-%d")
            graph_date  = real_date1 
            for i in range(C.MAX_BINS):
                g3mx_month_lst.append(graph_date)
                if dfdic["Report_Type"] == "3month-report":
                    graph_date = graph_date +  relativedelta(months=3)
                else:
                    graph_date = graph_date +  relativedelta(months=1)
                # iniyialize totals
                g3m_1y_tot.append(0)
                g3m_2y_tot.append(0)
            # last day of report
            if dfdic["Report_Type"] == "3month-report":
                real_date1end  = g3mx_month_lst[C.MAX_BINS -1] + relativedelta(months=3) - datetime.timedelta(days=1) 
            else:    
                real_date1end  = g3mx_month_lst[C.MAX_BINS -1] + relativedelta(months=1) - datetime.timedelta(days=1) 
            # compare ?
            if dfdic["compare_graph"]:
                g4mx_month_lst = []
                g4m_1y_tot = []
                g4m_2y_tot = []
                #initialize graph3  x cloumn vars 'date1': '2018-03-05'
                real_date3  = datetime.datetime.strptime(dfdic['year3']+"-"+dfdic["month3"]+"-01","%Y-%m-%d")
                graph_date  = real_date3 
                for i in range(C.MAX_BINS):
                    g4mx_month_lst.append(graph_date)
                    if dfdic["Report_Type"] == "3month-report":
                        graph_date = graph_date +  relativedelta(months=3)
                    else:
                        graph_date = graph_date +  relativedelta(months=1)
                    # iniyialize totals
                    g4m_1y_tot.append(0)
                    g4m_2y_tot.append(0)
                # last day of report
                if dfdic["Report_Type"] == "3month-report":
                    real_date3end  = g4mx_month_lst[C.MAX_BINS -1] + relativedelta(months=3) - datetime.timedelta(days=1) 
                else:     
                    real_date3end = g4mx_month_lst[C.MAX_BINS -1] + relativedelta(months=1) - datetime.timedelta(days=1) 
                                    




        #create extra columns in df 
        
        pace_sec = []
        season_lst = []
        work_type = []
        work_date = []
        work_joule = []

        """----------- filter and summary ---------"""
        for i in range(len(df)):
            dfr = df.iloc[i]

            #find real workout
            real_type = dfr["Type"]
            if real_type == "Dynamic RowErg":
                real_type = "RowErg"
            elif real_type == "RowErg on Slides":
                real_type = "RowErg"     
            elif real_type == "Rollerski":
                real_type = "On-snow"
            work_type.append(real_type)    

            #find real pace
            result, real_pace, sec_m, sec_s = pace_to_sec(dfr["Pace"])
            pace_sec.append(real_pace)

            # find real_season yyyy-mm-dd 00:00:00
            wdate =  dfr['Date'].split()[0]
            real_season = int(wdate.split("-")[0])
            month =  int(wdate.split("-")[1])
            if month> 4:
                real_season = real_season + 1
            season_lst.append(real_season) 

            real_meter = dfr["Work Distance"]
            # find real meters
            if real_type == "BikeErg":
                if dfdic["conver_cycling_kms"] == "yes": 
                   real_meter = round(real_meter / 2.0) 

            #find real date type str
            real_date_str  = dfr["Date"].split()[0]
            real_date = datetime.datetime.strptime(real_date_str,"%Y-%m-%d")
            work_date.append(real_date)

            # find joule
            real_joule = round(dfr["Avg Watts"] * dfr["Work Time (Seconds)"])
            work_joule.append(real_joule)

            # seperate warmup.. MUST BE LAST GRUP BEFORE TOTALS

            if  (dfdic["seperate"] == "workout") or (dfdic["seperate"] == "warmup"):
                warm_pace_sec = (int(dfdic["warm_pace_m"]) * 60) + int(dfdic["warm_pace_s"])
                if (real_pace > warm_pace_sec) and dfdic["seperate"] == "workout":
                    continue
                elif (real_pace <= warm_pace_sec) and dfdic["seperate"] == "warmup":
                    continue

            """--------- decide what to show for each graph menu --------------"""
            if dfdic["graphmenu"]== "pace":
                item_1y_tot = real_meter
                item_2y_tot =  dfr["Work Time (Seconds)"]
                item_compare = real_pace

            elif dfdic["graphmenu"]== "watt":
                item_1y_tot = real_joule
                item_2y_tot =  dfr["Work Time (Seconds)"]
                item_compare = dfr["Avg Watts"]

            elif dfdic["graphmenu"]== "cal":                   
                item_1y_tot = dfr["Total Cal"]
                item_2y_tot =  dfr["Work Time (Seconds)"]
                item_compare = dfr["Cal/Hour"]


            """ --------calculate season totals----------- """
            # totals for graph 1
            if real_season not in g1x_season_lst:
                g1x_season_lst.append(real_season)
                for t in dfdic["typelist"]:
                    g1_1y_tot_of_types[t].append(0)
                    g1_2y_tot_of_types[t].append(0)
            # find index and add . graph 1
            for si in range(len(g1x_season_lst)):
                if g1x_season_lst[si] == real_season:
                    g1_1y_tot_of_types[real_type][si] += item_1y_tot
                    g1_2y_tot_of_types[real_type][si] += item_2y_tot


            # totals for graph

            found = False
            for si in range(len(g2x_lst)):
                if g2x_lst[si] >= item_compare:
                    g2_1y_tot_of_types[real_type][si] += item_1y_tot
                    g2_2y_tot_of_types[real_type][si] += item_2y_tot
                    found = True
                    break
            if not found:
                g2_1y_tot_of_types[real_type][len(g2x_lst)-1] += item_1y_tot
                g2_2y_tot_of_types[real_type][len(g2x_lst)-1] += item_2y_tot

            # report type day_report
            if dfdic["Report_Type"] == "day-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    si = (real_date - real_date1).days  
                    g3_1y_tot[si] += item_1y_tot
                    g3_2y_tot[si] += item_2y_tot 
                    
                # report type day_report
            if dfdic["Report_Type"] == "day-report" and dfdic["compare_graph"]:
                if real_date >= real_date3 and real_date <= real_date3end:
                    si = (real_date - real_date3).days  
                    g4_1y_tot[si] += item_1y_tot
                    g4_2y_tot[si] += item_2y_tot  

            # report type week_report
            if dfdic["Report_Type"] == "week-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    found = False
                    for si in range(len(g3x_lst)):
                        if g3x_lst[si] <= real_date <= ( g3x_lst[si] + datetime.timedelta(days=6)) :
                            g3_1y_tot[si] += item_1y_tot
                            g3_2y_tot[si] += item_2y_tot
                            #print("------ found----")
                            found = True
                            break
                    if not found:
                        g3_1y_tot[len(g3x_lst)-1] += item_1y_tot
                        g3_2y_tot[len(g3x_lst)-1] += item_2y_tot


                # report type week_report
            if dfdic["Report_Type"] == "week-report" and dfdic["compare_graph"]:
                if real_date >= real_date3 and real_date <= real_date3end:
                    found = False
                    for si in range(len(g4x_lst)):
                        if g4x_lst[si] <= real_date <= ( g4x_lst[si] + datetime.timedelta(days=6)) :
                            g4_1y_tot[si] += item_1y_tot
                            g4_2y_tot[si] += item_2y_tot
                            found = True
                            break
                    if not found:
                        g4_1y_tot[len(g4x_lst)-1] += item_1y_tot
                        g4_2y_tot[len(g4x_lst)-1] += item_2y_tot
            """ -------- end of day and week total calculations -------- """

            # report type month_report
            if dfdic["Report_Type"] == "month-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    found = False
                    for si in range(len(g3mx_month_lst)):
                        if g3mx_month_lst[si] <= real_date <= ( g3mx_month_lst[si] + relativedelta(months=1) -  datetime.timedelta(days=1)) :
                            g3m_1y_tot[si] += item_1y_tot
                            g3m_2y_tot[si] += item_2y_tot
                            #print("------ found----")
                            found = True
                            break
                    if not found:
                        g3m_1y_tot[len(g3mx_month_lst)-1] += item_1y_tot
                        g3m_2y_tot[len(g3mx_month_lst)-1] += item_2y_tot

                # report type day_report
            if dfdic["Report_Type"] == "month-report" and dfdic["compare_graph"]:
                if real_date >= real_date3 and real_date <= real_date3end:
                    found = False
                    for si in range(len(g4mx_month_lst)):
                        if g4mx_month_lst[si] <= real_date <= ( g4mx_month_lst[si] + relativedelta(months=1) - datetime.timedelta(days=1)) :
                            g4m_1y_tot[si] += item_1y_tot
                            g4m_2y_tot[si] += item_2y_tot
                            found = True
                            break
                    if not found:
                        g4m_1y_tot[len(g4mx_month_lst)-1] += item_1y_tot
                        g4m_2y_tot[len(g4mx_month_lst)-1] += item_2y_tot

            # report type 3month_report
            if dfdic["Report_Type"] == "3month-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    found = False
                    for si in range(len(g3mx_month_lst)):
                        if g3mx_month_lst[si] <= real_date <= ( g3mx_month_lst[si] + relativedelta(months=3) -  datetime.timedelta(days=1)) :
                            g3m_1y_tot[si] += item_1y_tot
                            g3m_2y_tot[si] += item_2y_tot
                            #print("------ found----")
                            found = True
                            break
                    if not found:
                        g3m_1y_tot[len(g3mx_month_lst)-1] += item_1y_tot
                        g3m_2y_tot[len(g3mx_month_lst)-1] += item_2y_tot

                # report type day_report
            if dfdic["Report_Type"] == "3month-report" and dfdic["compare_graph"]:
                if real_date >= real_date3 and real_date <= real_date3end:
                    found = False
                    for si in range(len(g4mx_month_lst)):
                        if g4mx_month_lst[si] <= real_date <= ( g4mx_month_lst[si] + relativedelta(months=3) - datetime.timedelta(days=1)) :
                            g4m_1y_tot[si] += item_1y_tot
                            g4m_2y_tot[si] += item_2y_tot
                            found = True
                            break
                    if not found:
                        g4m_1y_tot[len(g4mx_month_lst)-1] += item_1y_tot
                        g4m_2y_tot[len(g4mx_month_lst)-1] += item_2y_tot
            """ -------- end of month 3month total calculations -------- """                       









        # add new columns for future use
        df["Pace(sec)"] = pace_sec
        df["Season"] = season_lst
        df["Work_Type"] = work_type 
        df["Work_Date"] = work_date
        df["Work_Joule"] = work_joule

        """--------- decide what to divide for each graph menu --------------"""
        # find string type of x coord.. graph 1 season
        g1x_season_str = convert_numstr(g1x_season_lst)

        if (dfdic["Report_Type"]== "day-report" or dfdic["Report_Type"]== "week-report") :
            g3x_day_str = convert_daystr(g3x_lst)                                 
        elif (dfdic["Report_Type"]== "month-report" or dfdic["Report_Type"]== "3month-report") :
            g3mx_month_str = convert_daystr(g3mx_month_lst)


        if dfdic["graphmenu"]== "pace":
            divide_1y_tot = 1000
            divide_2y_tot =  3600
            divide_1yday_tot = 1000
            divide_2yday_tot =  60
            # find string type of x coord.. graph 2 pace
            g2x_str = []
            for i in range(len(g2x_lst)):
                result, res_pace_str = sec_to_pace(g2x_lst[i])  
                if result:
                    g2x_str.append(res_pace_str)
            season1_title='Kms By Season'
            season1_xlabel='Season'
            season1_ylabel='Workout Kms'   

            season2_title='Hours By Season'
            season2_xlabel='Season'
            season2_ylabel='Workout Hours' 

            g3_title='Kms By Pace'
            g3_xlabel='Pace'
            g3_ylabel='Workout Kms'

            g4_title='Hours By Pace'
            g4_xlabel='Pace'
            g4_ylabel='Workout Hours'

            g5_xlabel='Date'
            g5_ylabel='Workout Kms'
            if dfdic["Report_Type"]== "3month-report":
                g5_title='Kms By 3month'
            elif dfdic["Report_Type"]== "month-report":    
                g5_title='Kms By Month'
            elif dfdic["Report_Type"]== "week-report":
                g5_title='Kms By Week'
            elif dfdic["Report_Type"]== "day-report":    
                g5_title='Kms By Date'
 

            g6_xlabel='Date'
            g6_ylabel='Workout Hours'
            if dfdic["Report_Type"]== "3month-report":
                g6_title='Duration By 3month'
            elif dfdic["Report_Type"]== "month-report":    
                g6_title='Duration By Month'
            elif dfdic["Report_Type"]== "week-report":
                g6_title='Duration By Week'
                g6_ylabel='Workout Minutes'
            elif dfdic["Report_Type"]== "day-report":    
                g6_title='Duration By Date'  
                g6_ylabel='Workout Minutes' 



        elif dfdic["graphmenu"]== "watt":
            divide_1y_tot = 1000
            divide_2y_tot =  3600
            divide_1yday_tot = 1000
            divide_2yday_tot = 60
            g2x_str = convert_numstr(g2x_lst) 
            season1_title='KiloJoule By Season'
            season1_xlabel='Season'
            season1_ylabel='Workout KiloJoule'   

            season2_title='Hours By Season'
            season2_xlabel='Season'
            season2_ylabel='Workout Hours' 

            g3_title='KiloJoule By Avg.Watt'
            g3_xlabel='Avg.Watt'
            g3_ylabel='Workout KiloJoule'

            g4_title='Hours By Avg.Watt'
            g4_xlabel='Avg.Watt'
            g4_ylabel='Workout Hours'

            g5_xlabel='Date'
            g5_ylabel='Workout KiloJoule'
            if dfdic["Report_Type"]== "3month-report":
                g5_title='KiloJoule By 3month'
            elif dfdic["Report_Type"]== "month-report":    
                g5_title='KiloJoule By Month'
            elif dfdic["Report_Type"]== "week-report":
                g5_title='KiloJoule By Week'
            elif dfdic["Report_Type"]== "day-report":    
                g5_title='KiloJoule By Date'
  

            g6_xlabel='Date'
            g6_ylabel='Workout Hours'
            if dfdic["Report_Type"]== "3month-report":
                g6_title='Duration By 3month'
            elif dfdic["Report_Type"]== "month-report":    
                g6_title='Duration By Month'
            elif dfdic["Report_Type"]== "week-report":
                g6_title='Duration By Week'
                g6_ylabel='Workout Minutes'
            elif dfdic["Report_Type"]== "day-report":    
                g6_title='Duration By Date'  
                g6_ylabel='Workout Minutes' 




        elif dfdic["graphmenu"]== "cal":                   
            divide_1y_tot = 1000
            divide_2y_tot =  3600
            divide_1yday_tot = 1
            divide_2yday_tot = 60
            g2x_str = convert_numstr(g2x_lst) 
            season1_title='kcal By Season'
            season1_xlabel='Season'
            season1_ylabel='Workout kcal'   

            season2_title='Hours By Season'
            season2_xlabel='Season'
            season2_ylabel='Workout Hours' 

            g3_title='Total kcal By Avg.Cal'
            g3_xlabel='Avg.Cal'
            g3_ylabel='Workout Total kcal'

            g4_title='Hours By Avg.Cal'
            g4_xlabel='Avg.Cal'
            g4_ylabel='Workout Hours'

            g5_xlabel='Date'
            g5_ylabel='Workout kcal'
            if dfdic["Report_Type"]== "3month-report":
                g5_title='kcal By 3month'
            elif dfdic["Report_Type"]== "month-report":    
                g5_title='kcal By Month'
            elif dfdic["Report_Type"]== "week-report":
                g5_title='cal By Week'
                g5_ylabel='Workout cal'
            elif dfdic["Report_Type"]== "day-report":    
                g5_title='cal By Date'
                g5_ylabel='Workout cal'

            g6_xlabel='Date'
            g6_ylabel='Workout Hours'
            if dfdic["Report_Type"]== "3month-report":
                g6_title='Duration By 3month'
            elif dfdic["Report_Type"]== "month-report":    
                g6_title='Duration By Month'
            elif dfdic["Report_Type"]== "week-report":
                g6_title='Duration By Week'
                g6_ylabel='Workout Minutes'
            elif dfdic["Report_Type"]== "day-report":    
                g6_title='Duration By Date'  
                g6_ylabel='Workout Minutes' 



        # convert seasonal sec to hour..graph 1
        for si in range(len(g1x_season_lst)):
            for t in dfdic["typelist"]:
                g1_2y_tot_of_types[t][si]= round(g1_2y_tot_of_types[t][si] / divide_2y_tot)

        # convert seasonal mt to km.. graph 1
        for si in range(len(g1x_season_lst)):
            for t in dfdic["typelist"]:
                g1_1y_tot_of_types[t][si]= round(g1_1y_tot_of_types[t][si] / divide_1y_tot)    


        for si in range(len(g2x_lst)):
            for t in dfdic["typelist"]:
                g2_2y_tot_of_types[t][si]= round(g2_2y_tot_of_types[t][si] / divide_2y_tot)

        # convert pace mt to km.. graph2
        for si in range(len(g2x_lst)):
            for t in dfdic["typelist"]:
                g2_1y_tot_of_types[t][si]= round(g2_1y_tot_of_types[t][si] / divide_1y_tot) 

        if dfdic["Report_Type"]== "day-report" or dfdic["Report_Type"]== "week-report" :
            for si in range(len(g3x_lst)):
                g3_2y_tot[si]= round(g3_2y_tot[si] / divide_2yday_tot)

            # convert pace mt to km.. graph3
            for si in range(len(g3x_lst)):
                g3_1y_tot[si]= round(g3_1y_tot[si] / divide_1yday_tot)

            if  dfdic["compare_graph"] :
                for si in range(len(g4x_lst)):
                    g4_2y_tot[si]= round(g4_2y_tot[si] / divide_2yday_tot)

                # convert pace mt to km.. graph3
                for si in range(len(g4x_lst)):
                    g4_1y_tot[si]= round(g4_1y_tot[si] / divide_1yday_tot) 
                   

        if dfdic["Report_Type"]== "month-report" or dfdic["Report_Type"]== "3month-report" :
            for si in range(len(g3mx_month_lst)):
                g3m_2y_tot[si]= round(g3m_2y_tot[si] / divide_2y_tot)

            # convert pace mt to km.. graph3
            for si in range(len(g3mx_month_lst)):
                g3m_1y_tot[si]= round(g3m_1y_tot[si] / divide_1y_tot) 

            if  dfdic["compare_graph"] :
                for si in range(len(g4mx_month_lst)):
                    g4m_2y_tot[si]= round(g4m_2y_tot[si] / divide_2y_tot)

                # convert pace mt to km.. graph3
                for si in range(len(g4mx_month_lst)):
                    g4m_1y_tot[si]= round(g4m_1y_tot[si] / divide_1y_tot) 





        
        """ first version can print only one bar lable
        plt.figure(figsize=(10, 6))
        plt.xticks(rotation=90)
        gdf = pd.DataFrame(g1_1y_tot_of_types , index=g1x_season_lst)

        ax = gdf.plot.bar(stacked=True)
        plt.xlabel('Pace(sec)')
        plt.ylabel('Workout Kms')
        plt.title("Kms By Season")

        ax.bar_label(ax.containers[0], label_type='edge')
        """

        """------------------------ season graph 1 -----------------------"""
        plt.style.use('seaborn')
        width = 0.4 # the width of the bars: can also be len(x) sequence

        fig, ax = plt.subplots()
        
        bottom = np.zeros(len(g1x_season_str))

        for wtype, wkms in g1_1y_tot_of_types.items():
            p = ax.bar(g1x_season_str, wkms, width, label=wtype, bottom=bottom)
            bottom += wkms
            ax.bar_label(p, label_type='center')

        ax.set_title(season1_title)
        plt.xlabel(season1_xlabel)
        plt.ylabel(season1_ylabel)
        ax.legend()

        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()


        """ ---------------- season graphs 2-------------------"""
        # if LaTeX is not installed or error caught, change to `False`
        plt.rcParams['text.usetex'] = False

        plt.style.use('seaborn')

        width = 0.4 # the width of the bars: can also be len(x) sequence

        fig, ax = plt.subplots()
        
        bottom = np.zeros(len(g1x_season_str))

        for wtype, whours in g1_2y_tot_of_types.items():
            p = ax.bar(g1x_season_str, whours, width, label=wtype, bottom=bottom)
            bottom += whours
            ax.bar_label(p, label_type='center')

        ax.set_title(season2_title)
        plt.xlabel(season2_xlabel)
        plt.ylabel(season2_ylabel)
        ax.legend()

        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()

        """ ----------pace graphs--meter --------------"""        

        # if LaTeX is not installed or error caught, change to `False`
        plt.rcParams['text.usetex'] = False
        plt.style.use('seaborn')
        fig, ax = plt.subplots()
        ax.stackplot(g2x_str, g2_1y_tot_of_types.values(),
                    labels=g2_1y_tot_of_types.keys(), alpha=0.8)

        fig.autofmt_xdate(rotation=90)
        ax.set_title(g3_title)
        plt.xlabel(g3_xlabel)
        plt.ylabel(g3_ylabel)
        ax.legend()
        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()

        """ ----------pace graphs- hour----------------"""        
  
        # if LaTeX is not installed or error caught, change to `False`
        plt.rcParams['text.usetex'] = False
        plt.style.use('seaborn')
        fig, ax = plt.subplots()
        ax.stackplot(g2x_str, g2_2y_tot_of_types.values(),
                labels=g2_2y_tot_of_types.keys(), alpha=0.8)
        fig.autofmt_xdate(rotation=90)
        ax.set_title(g4_title)
        plt.xlabel(g4_xlabel)
        plt.ylabel(g4_ylabel)
        ax.legend()
        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()

        """ ----------day-week graphs--meter --------------"""        
        if (dfdic["Report_Type"]== "day-report"  or dfdic["Report_Type"]== "week-report"):

            # if LaTeX is not installed or error caught, change to `False`
            plt.rcParams['text.usetex'] = False
            plt.style.use('seaborn')
            fig, ax = plt.subplots()
            ax.plot(g3x_day_str, g3_1y_tot, color='r', label=dfdic["date1"])
            if dfdic["compare_graph"]:
                ax.plot(g3x_day_str, g4_1y_tot, color='g', label=dfdic["date3"])
                
            fig.autofmt_xdate(rotation=90)
   
            ax.set_title(g5_title)
            plt.xlabel(g5_xlabel)
            plt.ylabel(g5_ylabel)
            ax.legend()
            pdf.savefig()  # saves the current figure into a pdf page
            plt.close()

        """ ----------day-week graphs- hour----------------"""        
        if (dfdic["Report_Type"]== "day-report"  or dfdic["Report_Type"]== "week-report"):
            # if LaTeX is not installed or error caught, change to `False`
            plt.rcParams['text.usetex'] = False
            plt.style.use('seaborn')
            fig, ax = plt.subplots()
            ax.plot(g3x_day_str, g3_2y_tot, color='r', label=dfdic["date1"])
            if dfdic["compare_graph"]:
                ax.plot(g3x_day_str, g4_2y_tot, color='g', label=dfdic["date3"])

            fig.autofmt_xdate(rotation=90)

            ax.set_title(g6_title)
            plt.xlabel(g6_xlabel)
            plt.ylabel(g6_ylabel)
            ax.legend()
            pdf.savefig()  # saves the current figure into a pdf page
            plt.close()

        """ ----------month 3 month graphs--meter --------------"""        
        if (dfdic["Report_Type"]== "month-report"  or dfdic["Report_Type"]== "3month-report"):

            # if LaTeX is not installed or error caught, change to `False`
            plt.rcParams['text.usetex'] = False
            plt.style.use('seaborn')
            fig, ax = plt.subplots()
            ax.plot(g3mx_month_str, g3m_1y_tot, color='r', label=(dfdic["month1"]+"/"+dfdic["year1"]))
            if dfdic["compare_graph"]:
                ax.plot(g3mx_month_str, g4m_1y_tot, color='g', label=(dfdic["month3"]+"/"+dfdic["year3"]))

            fig.autofmt_xdate(rotation=90)
   
            ax.set_title(g5_title)
            plt.xlabel(g5_xlabel)
            plt.ylabel(g5_ylabel)
            ax.legend()
            pdf.savefig()  # saves the current figure into a pdf page
            plt.close()

        """ ----------month 3month graphs- hour----------------"""        
        if  (dfdic["Report_Type"]== "month-report"  or dfdic["Report_Type"]== "3month-report"):
            # if LaTeX is not installed or error caught, change to `False`
            plt.rcParams['text.usetex'] = False
            plt.style.use('seaborn')
            fig, ax = plt.subplots()
            ax.plot(g3mx_month_str, g3m_2y_tot, color='r', label=(dfdic["month1"]+"/"+dfdic["year1"]))
            if dfdic["compare_graph"]:
                ax.plot(g3mx_month_str, g4m_2y_tot, color='g', label=(dfdic["month3"]+"/"+dfdic["year3"]))

            fig.autofmt_xdate(rotation=90)
    
            ax.set_title(g6_title)

            plt.xlabel(g6_xlabel)
            plt.ylabel(g6_ylabel)
            ax.legend()
            pdf.savefig()  # saves the current figure into a pdf page
            plt.close()

        """ --------------- last page --------------------"""

        plt.rcParams['text.usetex'] = False
        fig = plt.figure(figsize=(10, 6))
        fig.clf()
        xcor=1 - 0.05
        for txt in dfdic["filter_msgs"]:
            fig.text(0.5, xcor,txt,  size=10, ha="center")
            xcor = xcor - 0.05

        pdf.savefig(fig)  # or you can pass a Figure object to pdf.savefig
        plt.close()


        # We can also set the file's metadata via the PdfPages object:
        d = pdf.infodict()
        d['Title'] = dfdic["maintitle"]
        d['Author'] = dfdic["author"]
        d['Subject'] = dfdic["subject"]
        d['Keywords'] = dfdic["keywords"] 
        d['CreationDate'] = datetime.datetime(2009, 11, 13)
        d['ModDate'] = datetime.datetime.today()
