# SQLite database file path
DATABASE = "./final.db"
CONTROLLIST = ['Log ID', 'Date', 'Description', 'Work Time (Formatted)',
               'Work Time (Seconds)', 'Rest Time (Formatted)', 'Rest Time (Seconds)',
               'Work Distance', 'Rest Distance', 'Stroke Rate/Cadence', 'Stroke Count',
               'Pace', 'Avg Watts', 'Cal/Hour', 'Total Cal', 'Avg Heart Rate',
               'Drag Factor', 'Age', 'Weight', 'Type', 'Ranked', 'Comments',
               'Date Entered']
TYPELIST = ["RowErg","BikeErg", "SkiErg","On-water", "On-snow",  "Paddle Adapter" ]
MAX_BINS = 40
MAX_PACESTEPS = 10
MAX_PACE_MIN = 5
UPLOAD_FOLDER = './uploads'
# Define allowed files
ALLOWED_EXTENSIONS = {'csv'}
