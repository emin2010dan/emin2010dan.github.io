import csv
import datetime
import pytz
import requests
import subprocess
import urllib
import uuid
import re

from flask import redirect, render_template, session
from functools import wraps


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.
    yenisi
    https://flask.palletsprojects.com/en/2.3.x/patterns/viewdecorators/#view-decorators

    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not ('user_id' in session):
        #if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function





def checkpassword(password):
    """check password."""
    if len(password) < 8:
        return False, "Password must be longer than 7 chars"
    elif not re.search("[a-z]", password):
        return False, "Password must contain lowercase"
    elif not re.search("[A-Z]", password):
        return False, "Password must contain uppercase"
    elif not re.search("[0-9]", password):
        return False, "Password must contain numbers"
    else:
        return True, "valid password"
