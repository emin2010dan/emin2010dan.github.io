import csv
import datetime
import pytz
import requests
import subprocess
import urllib
import uuid
import re

from flask import redirect, render_template, session
from functools import wraps
import pandas as pd
import sqlite3 as sql
import config as C


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.
    yenisi
    https://flask.palletsprojects.com/en/2.3.x/patterns/viewdecorators/#view-decorators

    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not ('user_id' in session):
        #if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function





def checkpassword(password):
    """check password."""
    if len(password) < 8:
        return False, "Password must be longer than 7 chars"
    elif not re.search("[a-z]", password):
        return False, "Password must contain lowercase"
    elif not re.search("[A-Z]", password):
        return False, "Password must contain uppercase"
    elif not re.search("[0-9]", password):
        return False, "Password must contain numbers"
    else:
        return True, "valid password"
    


def dict_factory(cursor, row):
    """ convert to dictionary """
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d    


def show_records(DATABASE):
    """ show loadad csv records """
    headerstr, err_message = "", ""
    df = pd.DataFrame()
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        df = pd.DataFrame.from_dict(cur.execute(
            "SELECT * FROM csvs WHERE user_id = ? ORDER BY mindate", (session["user_id"],)).fetchall())
    except Exception as e:
        err_message = f"An error occured while selecting records:{e}"
        return False, headerstr, err_message, df
    finally:
        cur.close()
        db.close()

    if len(df) > 0:
        mindate = df['mindate'].min()
        maxdate = df['maxdate'].max()
        record_num = df['record_num'].sum()
        headerstr = f" Number of Loaded Csv Records:{record_num}    From:{mindate}    To:{maxdate}"
        df.drop('user_id', inplace=True, axis=1)

        # for i in range(len(df)):
        #    df.loc[i, 'csv_name'] = os.path.basename(
        #        df.loc[i, 'csv_name']).split("_")[1]
        df.drop(["csv_path"], axis=1, inplace=True)
        
      
    else:
        headerstr = "No Csv Records Loaded Yet"
    return True, headerstr, err_message, df


def controlcsv(df,CONTROLLIST):
    """control csv headers"""
    seqlist = df.keys()

    for i in range(len(seqlist)):
        if seqlist[i] != CONTROLLIST[i]:
            return False
    return True

def pace_to_sec(pace_str):
    """ convert pace to sec """
    try:
        sec_m = int(pace_str.split(":")[0])
        if sec_m > C.MAX_PACE_MIN:
            sec_m = C.MAX_PACE_MIN
        sec_s = round(float(pace_str.split(":")[1]))
        if sec_s > 59:
            sec_s = 59
        sec_t = (sec_m * 60) + sec_s
        return True, sec_t, sec_m, sec_s
    except:
        return False, 0, 0, 0
    
def sec_to_pace(sec_int):
    """ convert sec to pace """
    try:
        sec_m = sec_int // 60
        sec_s = sec_int - (sec_m * 60)
        sec_str = str(sec_m) + ":" + '{:02d}'.format(sec_s)
        return True, sec_str
    except:
        return False, ""   
    
def sec_to_minsec(sec_int):
    """ convert sec to min and sec """
    try:
        sec_m = sec_int // 60
        sec_s = sec_int - (sec_m * 60)
        return True, sec_m,sec_s
    except:
        return False, 0,0    
    
