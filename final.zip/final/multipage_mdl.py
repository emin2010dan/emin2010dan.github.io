# modules for multipage pdf
import numpy as np
from dateutil.relativedelta import relativedelta
import datetime


def create_tot_of_types(dfdic):
    """ initilize for total of types"""
    gx_lst = []
    g_1y_tot_of_types = {}
    g_2y_tot_of_types = {}
    for t in dfdic["typelist"]:
        g_1y_tot_of_types[t] = []
        g_2y_tot_of_types[t] = []
    return gx_lst, g_1y_tot_of_types, g_2y_tot_of_types


def convert_daystr(g_day_lst):
    """ convert day list to string list"""
    g_day_str = []
    for i in range(len(g_day_lst)):
        g_day_str.append(g_day_lst[i].strftime('%m/%d/%y'))
    return(g_day_str)


def convert_numstr(g_num_lst):
    """ convert a number list to string list"""
    g_str = []
    for i in range(len(g_num_lst)):
        g_str.append(str(g_num_lst[i]))
    return(g_str)


""" Dont delete, will be needed in the future
def find_totmsg(msg, g3_1y_tot, g3x_day_str):
    # print message for titles 
    totval = sum(g3_1y_tot)
    avgval = totval/len(g3x_day_str)
    return f" ({msg} Avg: {avgval:.2f})"
"""


def print_total_graph(pdf, plt, dfdic,
                      season1_title, season1_xlabel, season1_ylabel,
                      g1x_season_lst, g1x_season_str, g1_1y_tot_of_types
                      ):
    """ print total graphs"""
    num_items = 0
    for si in range(len(g1x_season_lst)):
        for t in dfdic["typelist"]:
            if g1_1y_tot_of_types[t][si] > 0:
                num_items += 1
    # if there is only one element this graph is not needed
    if num_items > 1:
        try:
            plt.rcParams['text.usetex'] = False
            plt.style.use('seaborn')
            width = 0.4  # the width of the bars: can also be len(x) sequence

            fig, ax = plt.subplots()
            ax.set_title(season1_title)
            bottom = np.zeros(len(g1x_season_str))

            for wtype, wkms in g1_1y_tot_of_types.items():
                if sum(wkms) > 0:
                    p = ax.bar(g1x_season_str, wkms, width,
                               label=wtype, bottom=bottom)
                    bottom += wkms
                    ax.bar_label(p, label_type='center')

            plt.xlabel(season1_xlabel)
            plt.ylabel(season1_ylabel)
            ax.legend()
            pdf.savefig()  # saves the current figure into a pdf page
            plt.close()
        except Exception as e:
            print(
                f"--Plot exception1:{e} Main: {g1x_season_lst} Data: {g1_1y_tot_of_types} ")


def print_pie_charts(pdf, plt, dfdic,
                     g1x_season_str, g1x_season_lst, g1_1y_tot_of_types,
                     season1_title
                     ):
    """ print 2 pie charts if there is enough data """
    if len(g1x_season_str) > 1 or len(dfdic["typelist"]) > 1:

        totals = []
        explode = []
        totval = 0
        for si in range(len(g1x_season_lst)):
            totnum = 0
            for t in dfdic["typelist"]:
                totnum += g1_1y_tot_of_types[t][si]
            totals.append(totnum)
            totval += totnum
            explode.append(0.1)

        totals2 = []
        explode2 = []
        for t in dfdic["typelist"]:
            totnum = 0
            for si in range(len(g1x_season_lst)):
                totnum += g1_1y_tot_of_types[t][si]
            totals2.append(totnum)
            explode2.append(0.1)

        if totval > 0:
            try:
                if dfdic["Report_Type"] == "season-report":
                    fig, ax = plt.subplots(1, 2)
                    ax[0].pie(totals, explode=explode,
                              startangle=90, labels=g1x_season_str, autopct='%1.1f%%')
                    fig.suptitle(season1_title + " & Work Type " +
                                 f" (Total: {totval:.2f})")
                    ax[1].pie(totals2, explode=explode2,
                              startangle=90, labels=dfdic["typelist"], autopct='%1.1f%%')
                    pdf.savefig()
                    plt.close()
                else:
                    fig, ax = plt.subplots()
                    ax.pie(totals2, explode=explode2,
                           startangle=90, labels=dfdic["typelist"], autopct='%1.1f%%')
                    fig.suptitle(season1_title +
                                 f" (Total: {totval:.2f})")
                    pdf.savefig()
                    plt.close()
            except Exception as e:
                print(
                    f"--Plot exception2: {e} Main: {g1x_season_lst} Data: {g1_1y_tot_of_types} ")


def divide_tot_of_types(dfdic, g1x_season_lst, g1_2y_tot_of_types, divide_2y_tot):
    """ divide totals for better graphs"""
    for si in range(len(g1x_season_lst)):
        for t in dfdic["typelist"]:
            g1_2y_tot_of_types[t][si] = round(
                g1_2y_tot_of_types[t][si] / divide_2y_tot, 2)


def divide_graph_items(g3x_lst,
                       g3_2y_tot, divide_2yday_tot,
                       g3_1y_tot, divide_1yday_tot
                       ):
    """ divide graph items for better graphs"""
    for si in range(len(g3x_lst)):
        g3_2y_tot[si] = round(g3_2y_tot[si] / divide_2yday_tot, 2)

    # convert pace mt to km.. graph3
    for si in range(len(g3x_lst)):
        g3_1y_tot[si] = round(g3_1y_tot[si] / divide_1yday_tot, 2)


def print_3graphs(pdf, plt,
                  g2x_str, g2_1y_tot_of_types,
                  g3_title, g3_xlabel, g3_ylabel):
    # print graph type 3
    try:
        plt.rcParams['text.usetex'] = False
        plt.style.use('seaborn')
        fig, ax = plt.subplots()
        ax.stackplot(g2x_str, g2_1y_tot_of_types.values(),
                     labels=g2_1y_tot_of_types.keys(), alpha=0.8)

        fig.autofmt_xdate(rotation=90)
        ax.set_title(g3_title)
        plt.xlabel(g3_xlabel)
        plt.ylabel(g3_ylabel)
        ax.legend()
        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()
    except Exception as e:
        print(
            f"--Plot exception5: {e}Main: {g2x_str} Data: {g2_1y_tot_of_types} ")


def print_4graphs(pdf, plt, dfdic,
                  g3x_day_str, g3_1y_tot, g4_1y_tot,
                  g5_title, g5_xlabel, g5_ylabel,
                  dfdic_date1, dfdic_date3):
    # print graph type 4
    try:
        #totmsg = find_totmsg("", g3_1y_tot, g3x_day_str)
        #compmsg = ""
        plt.rcParams['text.usetex'] = False
        plt.style.use('seaborn')
        fig, ax = plt.subplots()
        if dfdic["compare_graph"]:
            ax.plot(g3x_day_str, g3_1y_tot,
                color='r', label=dfdic_date1)
            ax.plot(g3x_day_str, g4_1y_tot,
                    color='g', label=dfdic_date3)
            #compmsg = find_totmsg("Compare ", g4_1y_tot, g3x_day_str)
        else:
            ax.bar(g3x_day_str, g3_1y_tot,
                color='r', label=dfdic_date1)
                
            

        fig.autofmt_xdate(rotation=90)

        ax.set_title(g5_title)  # + totmsg + compmsg)
        plt.xlabel(g5_xlabel)
        plt.ylabel(g5_ylabel)
        ax.legend()
        pdf.savefig()  # saves the current figure into a pdf page
        plt.close()
    except Exception as e:
        print(
            f"--Plot exception7: {e} {e}Main: {g3x_day_str} Data: {g3_1y_tot} ")
