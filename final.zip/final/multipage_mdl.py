# modules for multipage pdf

def create_tot_of_types (dfdic):
        """ initilize for total of types"""
        gx_lst = []
        g_1y_tot_of_types = {}
        g_2y_tot_of_types = {}
        for t in dfdic["typelist"]:
            g_1y_tot_of_types[t]=[]
            g_2y_tot_of_types[t]=[]
        return gx_lst,g_1y_tot_of_types,g_2y_tot_of_types
          
def convert_daystr(g_day_lst):
    g_day_str = []
    for i in range(len(g_day_lst)):
        g_day_str.append( g_day_lst[i].strftime('%m/%d/%y'))
    return(g_day_str)

def convert_numstr(g_num_lst):
        g_str = []
        for i in range(len(g_num_lst)):
            g_str.append(str(g_num_lst[i]))
        return(g_str)    



