



# Analyze Workouts of Rowers
#### Video Demo:  <https://www.youtube.com/watch?v=ZxF6apaHk0g>




#### Description: As an old rower I know that Rowers/Cyclists/Skiers who work with computer aided ergometers, have lots of raw csv data but not useful graphics. I wrote a program to convert csv files of ergometers to userful graphics to analyze workouts.




#### How To Use:




1- Enter my home page [Home Page](https://emin2010dan.github.io/) and select the Sport Calculators page. Cs50 project is at the top of the page. Press the `Go to CS50X Final Project` button to connect pythonanywhere.








2- Or use this link to connect the project directly. [CS50X Final Project Page](https://emin2010dan.pythonanywhere.com/login)




3- If you are a rower, cyclist or skier download your csv data from  [Concept2's page's](https://log.concept2.com) `History` tab . It is a free site and you can record your on water or on ski workouts even if you have no ergometers.


![Login page image](https://i.ibb.co/qmrHdhz/Ekran-g-r-nt-s-2023-09-14-155418.png)


If you have not any csv data to test please use my user's:
```
- Username: hd5
- Password: hD123456
```


4- Every user needs to register. A user record is needed to differentiate their csv files. Please do not use your real name or banking passwords.




![Register page image](https://i.ibb.co/QmsjkJz/Ekran-g-r-nt-s-2023-09-14-155641.png)




5- After login, the Main menu shows your pre-loaded csv files. Every loaded file remains until you delete them. There is no private information like name,telephone,address in these files so saving them to pythonanywhere causes no security problems.


![Home page image](https://i.ibb.co/k4DSN2C/Ekran-g-r-nt-s-2023-09-14-155736.png)

 If you don't want to save, you can delete them after getting the reports.

![Delete Csv page image](https://i.ibb.co/cFZXq5g/Ekran-g-r-nt-s-2023-09-15-141435.png)


6- To load new files or to refresh them (this season's file changes every day) enter `Load Csv` page:


![Load Csv page image](https://i.ibb.co/S5G0jkn/Ekran-g-r-nt-s-2023-09-14-165653.png)


Choose the file you want to load from your computer. Program will show first and last records and number of workouts after the load.

![Load Csv Result page image](https://i.ibb.co/RHwhtp6/Ekran-g-r-nt-s-2023-09-15-141304.png)

7- Enter `Pace Graphs` page for pace (show speed of rowers) and km graphs. Pace is time needed to row 500 meters and it is used to compare rower's capacity.


![Pace Graphs page image](https://i.ibb.co/tCB5K5T/Ekran-g-r-nt-s-2023-09-14-165750.png)


In this page, the left top box is used to select types of workouts that you want to put in graphs. Right top box asks for min pace and steps for graphs. This is the main function of this graph. It separates workouts according to their speeds(paces). Right bottom box converts cycling kms to rowing kms if you want to compare them. You can cycle two times easily so without dividing biking kms to 2, comparing them with rowing kilometers is meaningless. Unfortunately ergometer firm do not do this conversion.


8- Another important calculation is to separate warmup/cooldown workouts from actual workouts. If you want to compare your workouts, you have to eliminate warm ups. To separate warm ups, you have to enter your 2k pace(speed) + 30 seconds. 2k pace is the first number an ergometer user learns.


![Separate workouts card image](https://i.ibb.co/47vdfBh/Ekran-g-r-nt-s-2023-09-14-165840.png)


9- You can get a summary or very detailed reports using this box. Season report summarized all data you loaded. If you want more detail, quarterly(3 months), monthly, weekly and daily reports are also available. For quarterly and monthly reports the program asks for a beginning month/year. If you want to compare the km and working hours of these months with other months, the program asks for a second date.


![Monthly card image](https://i.ibb.co/51SBwK6/Ekran-g-r-nt-s-2023-09-14-165908.png)


10- For weekly and daily reports, you need to enter the beginning date.


![Weekly card image](https://i.ibb.co/r24sWHr/Ekran-g-r-nt-s-2023-09-14-165937.png)


11- First page of graphs is always for total values. If you ask for a season graph, every season is separated by stacked bars.


![Kms By Season image](https://i.ibb.co/7yhqZYb/Ekran-g-r-nt-s-2023-09-14-170304.png)

![Hours By Season image](https://i.ibb.co/FBrM6Dy/Ekran-g-r-nt-s-2023-09-15-141530.png)



12- Same information with pie charts is also available.


![Kms By Season pie chart image](https://i.ibb.co/MGx9zKP/Ekran-g-r-nt-s-2023-09-14-170327.png)

![Hours By Season pie chart image](https://i.ibb.co/JWY2wKS/Ekran-g-r-nt-s-2023-09-15-141550.png)

13- Most important part of the program is this page. It categorizes your workouts according to your paces(speeds). You can see groups. The Fastest group is actual workouts. Others are warm-ups/cool-downs.


![Kms By Pace image](https://i.ibb.co/YT6gT3X/Ekran-g-r-nt-s-2023-09-14-170343.png)

![Hours By Pace image](https://i.ibb.co/JjhPSw7/Ekran-g-r-nt-s-2023-09-15-141606.png)

14- If you want a comparison, the program compares your workout kms and hours of two dates in the same graph. There are more graphs in the program,I only give one sample.


![Kms By Date image](https://i.ibb.co/k38sJmk/Ekran-g-r-nt-s-2023-09-15-141732.png)

![Kms By Pace image](https://i.ibb.co/VMfDHvw/Ekran-g-r-nt-s-2023-09-14-170610.png)


15- Watt graph page prints watt and joule values instead of pace/km. It asks for minimum watt instead of minimum pace for graphs.


![Watt Graphs page image](https://i.ibb.co/yp42c4n/Ekran-g-r-nt-s-2023-09-14-170645.png)


16- Calorie graph is for users that are only concerned with losing weight. It gives total calorie values in graphs.


![Calorie Graphs page image](https://i.ibb.co/GJzcnff/Ekran-g-r-nt-s-2023-09-14-170708.png)












#### Design Issues:




Project is installed in pythonanywhere for ergometer(either rowerg, bikeerg or skierg) users or rowers at water or skiers  to use free. Also connected to my homepage. Concept2 is the most preferred brand in the ergometer sector. As a concept2 row and bike ergometer user, I used their csv files for graphics. But it is very easy to convert the program to other csv formats since it adds all needed columns to the dictionary before generating reports.




The only need for a database is to store user records and their csv file names. I do not need to save graphic results so sqlite is enough for me. In pythonanywhere, I use pure sql commands not cs50's library so I put them in try blocks and add commits if necessary.




At the beginning of the project, I tried really hard to use the Bokeh library for graphics. It is more flexible than matplotlib but unfortunately free hosting sites have problems with this library. I read many blogs about it and my test program did not work in Pythonanywhere. In the end I decided to use matplotlib. It's more simple but enough for this project. I added more graphs of different types for each data since the pdf file has no limit to carry.




Users may enter very complex queries such as convert bike kms to row kms plus filter warmup workouts plus group data weekly by comparing it to a different date. So users can get different graphs from the same data. I put a report page at the end of graphs to remind the users about their input parameters. At the beginning I wanted to send graphs to users by getting their emails. But using pdf instead of images made it unnecessary. A user can easily download pdf files on screen. Also some users may not want to give their email addresses.



Matplotlib may crash anytime if it can't fit labels into graphs. So I had to put all plot commands in try blocks.








#### Contact Info:
- Name: Hayrettin Emin Demirel
- Email: emin2010dan@gmail.com
- City: Istanbul
- Country: Turkey
- Age: 60
- Profession: Computer Engineer(Retired)
- School: Middle East Technical University
- [Home Page](https://emin2010dan.github.io/)




- [Rowing Profile](https://log.concept2.com/profile/935482)




- [CS50X Final Project Page](https://emin2010dan.pythonanywhere.com/login)




#### Files:




- app.py : main program to control all menus and handle inputs.




- config.py: All global variables that are shared between modules are defined here.




- final.db: user records and list of csv files that belong to these users. Other than name, no csv data is saved in db. There is no need to use heavy load dbs like mysql so I prefer sqlite.  




- modules.py: modules of app.py are defined here




- multipage_mdl.py : modules of multipage_pdf.py are defined here.




- multipage_pdf.py: create multi page pdfs from 2 dictionaries sent by app.py. df is raw data from csv files. dfdic is user input.




 

