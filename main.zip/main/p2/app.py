from flask import Flask
import os

execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))


if execution_dir == file_dir:
    DISPATCHER = "yok"
else:
    DISPATCHER = "var" 
print("------------------------",DISPATCHER)

app = Flask(__name__)

if DISPATCHER == "yok":
    print("-----------/,/login,/x -------------")
    @app.route('/')
    def hello_world():
        return 'Hello World!2222'

    @app.route('/login')
    def hello_worldplog2():
        return 'Hello World!login 2222'

    @app.route('/x')
    def hello_worldx():
        return 'Hello World!xxxx2222'
else:
    print("-----------/p,/p/login,/p/x -------------")

    @app.route('/')
    def hello_worldp():
        return 'Hello World!p 222'

    @app.route('/login')
    def hello_worldplog():
        return 'Hello World!p/login 2222'

    @app.route('/x')
    def hello_worldx2():
        return 'Hello World!p xxxx2222'

if __name__ == '__main__':
    app.run(debug=True)
