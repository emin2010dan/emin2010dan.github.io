


cd ..
ls -l yedekler
echo "Yedek ismi bosluksuz"
read name
if [ -d "yedekler" ]; then
 if [ -d "yedekler"/$name ]; then  
    diff main "yedekler"/$name > diff_yedek.log
    more diff_yedek.log 
 else
    echo "error: no yedekler/"$name
    exit 1
  fi  
else
  echo "error: no yedekler"
  exit 1
fi   