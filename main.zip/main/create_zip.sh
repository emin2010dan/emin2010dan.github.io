cd ..
if [ -d "pythonanywhere" ]; then
 if [ -d "main" ]; then
 rm -rf ./pythonanywhere/*
 cp -r main pythonanywhere
 cd pythonanywhere
 find . -type d -name "__pycache__" -exec rm -rf "{}"  \;
 find . -type d -name ".pytest_cache" -exec rm -rf "{}"  \;
 find . -type d -name ".vscode" -exec rm -rf "{}"  \;
 find . -type d -name ".git" -exec rm -rf "{}"  \;
 rm -rf ./main/logs/*
 rm -rf ./main/cs50pfinal/plogs/*
 rm -rf ./main/cs50pfinal/puploads/*
 rm -rf ./main/cs50pfinal/static/images/*
 rm -rf ./main/final/logs/*
 rm -rf ./main/final/uploads/*
 rm -rf ./main/final/static/images/*
 find . -name README.md -exec rm -rf "{}"  \;
 find . -name .gitignore -exec rm -rf "{}"  \;
 rm -f main.zip
 zip -r main.zip main
else
 echo "error: no main"
 exit 1
fi
else
  echo "error: no pythonanywhere"
  exit 1
fi   