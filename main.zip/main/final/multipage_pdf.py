"""
=============
Multipage PDF
=============

"""

import datetime
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt

import pandas as pd
from dateutil.relativedelta import relativedelta
import os
import logging

execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))
if execution_dir == file_dir:
    INDISPATCHER = False
else:
    INDISPATCHER = True    

if INDISPATCHER:
    from .modules import pace_to_sec, sec_to_pace
    from .multipage_mdl import create_tot_of_types,convert_daystr,convert_numstr,print_total_graph,print_pie_charts,divide_tot_of_types,divide_graph_items,print_3graphs,print_4graphs
    from .config import DATABASE,CONTROLLIST,TYPELIST,MAX_BINS,MAX_PACESTEPS,MAX_PACE_MIN,UPLOAD_FOLDER,ALLOWED_EXTENSIONS 
else:
    from modules import pace_to_sec, sec_to_pace
    from multipage_mdl import create_tot_of_types,convert_daystr,convert_numstr,print_total_graph,print_pie_charts,divide_tot_of_types,divide_graph_items,print_3graphs,print_4graphs
    from config import DATABASE,CONTROLLIST,TYPELIST,MAX_BINS,MAX_PACESTEPS,MAX_PACE_MIN,UPLOAD_FOLDER,ALLOWED_EXTENSIONS 


import matplotlib
matplotlib.use('Agg')


def multipage_pdf(df, dfdic):

    with PdfPages(dfdic["pdfname"]) as pdf:

        """initialize total arrays
        y_coord 
           row icin  mt season degerleri
           bike icin mt season degerleri
           ...
                    x_coord = sesason_lst    
        """
        # initilize graph 1 variables.. 2 seson graphs
        g1x_season_lst, g1_1y_tot_of_types, g1_2y_tot_of_types = create_tot_of_types(
            dfdic)

        # initialize graph 2 vars. 2 pace graphs
        if dfdic["graphmenu"] == "pace":
            g2x_lst, g2_1y_tot_of_types, g2_2y_tot_of_types = create_tot_of_types(
                dfdic)
            # initialize graph2  cloumn vars
            graph_pace_sec = (int(dfdic["min_pace_m"])
                              * 60) + int(dfdic["min_pace_s"])
            for i in range( MAX_BINS):
                g2x_lst.append(graph_pace_sec)
                graph_pace_sec += int(dfdic["pacestep"])
                # iniyialize pace totals
                for t in dfdic["typelist"]:
                    g2_1y_tot_of_types[t].append(0)
                    g2_2y_tot_of_types[t].append(0)

        # initialize graph 2 vars.watte graphs
        if dfdic["graphmenu"] == "watt":
            g2x_lst, g2_1y_tot_of_types, g2_2y_tot_of_types = create_tot_of_types(
                dfdic)
            # initialize graph2  cloumn vars
            graph_watt = int(dfdic["min_watt"])
            for i in range( MAX_BINS):
                g2x_lst.append(graph_watt)
                graph_watt += int(dfdic["wattstep"])
                # iniyialize pace totals
                for t in dfdic["typelist"]:
                    g2_1y_tot_of_types[t].append(0)
                    g2_2y_tot_of_types[t].append(0)

        # initialize graph 2 vars.cal graphs
        if dfdic["graphmenu"] == "cal":
            g2x_lst, g2_1y_tot_of_types, g2_2y_tot_of_types = create_tot_of_types(
                dfdic)
            # initialize graph2  cloumn vars
            graph_watt = int(dfdic["min_calhr"])
            for i in range( MAX_BINS):
                g2x_lst.append(graph_watt)
                graph_watt += int(dfdic["calstep"])
                # iniyialize pace totals
                for t in dfdic["typelist"]:
                    g2_1y_tot_of_types[t].append(0)
                    g2_2y_tot_of_types[t].append(0)

        # day report or week report
        if dfdic["Report_Type"] == "day-report":
            MAXCOL = 31
        elif dfdic["Report_Type"] == "week-report":
            MAXCOL = 26
        elif dfdic["Report_Type"] == "month-report":
            MAXCOL = 24
        elif dfdic["Report_Type"] == "3month-report":
            MAXCOL = 8

        if dfdic["Report_Type"] == "day-report" or dfdic["Report_Type"] == "week-report":
            g3x_lst = []
            g3_1y_tot = []
            g3_2y_tot = []
            # initialize graph3  x cloumn vars 'date1': '2018-03-05'
            real_date1 = datetime.datetime.strptime(dfdic['date1'], "%Y-%m-%d")
            graph_date = real_date1
            for i in range(MAXCOL):
                g3x_lst.append(graph_date)
                if dfdic["Report_Type"] == "week-report":
                    graph_date = graph_date + datetime.timedelta(days=7)
                else:
                    graph_date = graph_date + datetime.timedelta(days=1)
                # iniyialize totals
                g3_1y_tot.append(0)
                g3_2y_tot.append(0)
                if graph_date > datetime.datetime.today():
                    break
            # last day of report
            if dfdic["Report_Type"] == "week-report":
                real_date1end = g3x_lst[len(
                    g3x_lst) - 1] + datetime.timedelta(days=6)
            else:
                real_date1end = g3x_lst[len(g3x_lst) - 1]
            # compare ?
            if dfdic["compare_graph"]:
                g4x_lst = []
                g4_1y_tot = []
                g4_2y_tot = []
                # initialize graph3  x cloumn vars 'date1': '2018-03-05'
                real_date3 = datetime.datetime.strptime(
                    dfdic['date3'], "%Y-%m-%d")
                graph_date = real_date3
                for i in range(len(g3x_lst)):
                    g4x_lst.append(graph_date)
                    if dfdic["Report_Type"] == "week-report":
                        graph_date = graph_date + datetime.timedelta(days=7)
                    else:
                        graph_date = graph_date + datetime.timedelta(days=1)
                    # iniyialize totals
                    g4_1y_tot.append(0)
                    g4_2y_tot.append(0)

                # last day of report
                if dfdic["Report_Type"] == "week-report":
                    real_date3end = g4x_lst[len(
                        g4x_lst) - 1] + datetime.timedelta(days=6)
                else:
                    real_date3end = g4x_lst[len(g4x_lst) - 1]

        # month report or 3month report
        if dfdic["Report_Type"] == "month-report" or dfdic["Report_Type"] == "3month-report":
            g3mx_month_lst = []
            g3m_1y_tot = []
            g3m_2y_tot = []
            # initialize graph3  x cloumn vars 'date1': '2018-03-05'
            real_date1 = datetime.datetime.strptime(
                dfdic['year1']+"-"+dfdic["month1"]+"-01", "%Y-%m-%d")
            graph_date = real_date1
            for i in range(MAXCOL):
                g3mx_month_lst.append(graph_date)
                if dfdic["Report_Type"] == "3month-report":
                    graph_date = graph_date + relativedelta(months=3)
                else:
                    graph_date = graph_date + relativedelta(months=1)
                # iniyialize totals
                g3m_1y_tot.append(0)
                g3m_2y_tot.append(0)
                if graph_date > datetime.datetime.today():
                    break
            # last day of report
            if dfdic["Report_Type"] == "3month-report":
                real_date1end = g3mx_month_lst[len(
                    g3mx_month_lst) - 1] + relativedelta(months=3) - datetime.timedelta(days=1)
            else:
                real_date1end = g3mx_month_lst[len(
                    g3mx_month_lst) - 1] + relativedelta(months=1) - datetime.timedelta(days=1)
            # compare ?
            if dfdic["compare_graph"]:
                g4mx_month_lst = []
                g4m_1y_tot = []
                g4m_2y_tot = []
                # initialize graph3  x cloumn vars 'date1': '2018-03-05'
                real_date3 = datetime.datetime.strptime(
                    dfdic['year3']+"-"+dfdic["month3"]+"-01", "%Y-%m-%d")
                graph_date = real_date3
                for i in range(len(g3mx_month_lst)):
                    g4mx_month_lst.append(graph_date)
                    if dfdic["Report_Type"] == "3month-report":
                        graph_date = graph_date + relativedelta(months=3)
                    else:
                        graph_date = graph_date + relativedelta(months=1)
                    # iniyialize totals
                    g4m_1y_tot.append(0)
                    g4m_2y_tot.append(0)

                # last day of report
                if dfdic["Report_Type"] == "3month-report":
                    real_date3end = g4mx_month_lst[len(
                        g4mx_month_lst) - 1] + relativedelta(months=3) - datetime.timedelta(days=1)
                else:
                    real_date3end = g4mx_month_lst[len(
                        g4mx_month_lst) - 1] + relativedelta(months=1) - datetime.timedelta(days=1)

        # create extra columns in df

        pace_sec = []
        season_lst = []
        work_type = []
        work_date = []
        work_joule = []

        """----------- filter and summary ---------"""
        for i in range(len(df)):
            dfr = df.iloc[i]

            # find real workout
            real_type = dfr["Type"]
            if real_type == "Dynamic RowErg":
                real_type = "RowErg"
            elif real_type == "RowErg on Slides":
                real_type = "RowErg"
            elif real_type == "Rollerski":
                real_type = "On-snow"
            work_type.append(real_type)

            # find real pace
            result, real_pace, sec_m, sec_s = pace_to_sec(dfr["Pace"])
            pace_sec.append(real_pace)

            # find real_season yyyy-mm-dd 00:00:00
            wdate = dfr['Date'].split()[0]
            real_season = int(wdate.split("-")[0])
            month = int(wdate.split("-")[1])
            if month > 4:
                real_season = real_season + 1
            season_lst.append(real_season)

            real_meter = dfr["Work Distance"]
            # find real meters
            if real_type == "BikeErg":
                if dfdic["conver_cycling_kms"] == "yes":
                    real_meter = round(real_meter / 2.0)

            # find real date type str
            real_date_str = dfr["Date"].split()[0]
            real_date = datetime.datetime.strptime(real_date_str, "%Y-%m-%d")
            work_date.append(real_date)

            # find joule
            real_joule = round(dfr["Avg Watts"] * dfr["Work Time (Seconds)"])
            work_joule.append(real_joule)

            # seperate warmup.. MUST BE LAST GRUP BEFORE TOTALS

            if (dfdic["seperate"] == "workout") or (dfdic["seperate"] == "warmup"):
                warm_pace_sec = (
                    int(dfdic["warm_pace_m"]) * 60) + int(dfdic["warm_pace_s"])
                if (real_pace > warm_pace_sec) and dfdic["seperate"] == "workout":
                    continue
                elif (real_pace <= warm_pace_sec) and dfdic["seperate"] == "warmup":
                    continue

            """--------- decide what to show for each graph menu --------------"""
            if dfdic["graphmenu"] == "pace":
                item_1y_tot = real_meter
                item_2y_tot = dfr["Work Time (Seconds)"]
                item_compare = real_pace

            elif dfdic["graphmenu"] == "watt":
                item_1y_tot = real_joule
                item_2y_tot = dfr["Work Time (Seconds)"]
                item_compare = dfr["Avg Watts"]

            elif dfdic["graphmenu"] == "cal":
                item_1y_tot = dfr["Total Cal"]
                item_2y_tot = dfr["Work Time (Seconds)"]
                item_compare = dfr["Cal/Hour"]

            add_to_totals = False
            # report type day_report
            if dfdic["Report_Type"] == "day-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    add_to_totals = True
                    si = (real_date - real_date1).days
                    g3_1y_tot[si] += item_1y_tot
                    g3_2y_tot[si] += item_2y_tot

                if dfdic["compare_graph"]:
                    if real_date >= real_date3 and real_date <= real_date3end:
                        si = (real_date - real_date3).days
                        g4_1y_tot[si] += item_1y_tot
                        g4_2y_tot[si] += item_2y_tot

            # report type week_report
            elif dfdic["Report_Type"] == "week-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    add_to_totals = True
                    found = False
                    for si in range(len(g3x_lst)):
                        if g3x_lst[si] <= real_date <= (g3x_lst[si] + datetime.timedelta(days=6)):
                            g3_1y_tot[si] += item_1y_tot
                            g3_2y_tot[si] += item_2y_tot
                            found = True
                            break
                    if not found:
                        g3_1y_tot[len(g3x_lst)-1] += item_1y_tot
                        g3_2y_tot[len(g3x_lst)-1] += item_2y_tot

                if dfdic["compare_graph"]:
                    if real_date >= real_date3 and real_date <= real_date3end:
                        found = False
                        for si in range(len(g4x_lst)):
                            if g4x_lst[si] <= real_date <= (g4x_lst[si] + datetime.timedelta(days=6)):
                                g4_1y_tot[si] += item_1y_tot
                                g4_2y_tot[si] += item_2y_tot
                                found = True
                                break
                        if not found:
                            g4_1y_tot[len(g4x_lst)-1] += item_1y_tot
                            g4_2y_tot[len(g4x_lst)-1] += item_2y_tot

                """ -------- end of day and week total calculations -------- """

            # report type month_report
            elif dfdic["Report_Type"] == "month-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    add_to_totals = True
                    found = False
                    for si in range(len(g3mx_month_lst)):
                        if g3mx_month_lst[si] <= real_date <= (g3mx_month_lst[si] + relativedelta(months=1) - datetime.timedelta(days=1)):
                            g3m_1y_tot[si] += item_1y_tot
                            g3m_2y_tot[si] += item_2y_tot
                            found = True
                            break
                    if not found:
                        g3m_1y_tot[len(g3mx_month_lst)-1] += item_1y_tot
                        g3m_2y_tot[len(g3mx_month_lst)-1] += item_2y_tot

                if dfdic["compare_graph"]:
                    if real_date >= real_date3 and real_date <= real_date3end:
                        found = False
                        for si in range(len(g4mx_month_lst)):
                            if g4mx_month_lst[si] <= real_date <= (g4mx_month_lst[si] + relativedelta(months=1) - datetime.timedelta(days=1)):
                                g4m_1y_tot[si] += item_1y_tot
                                g4m_2y_tot[si] += item_2y_tot
                                found = True
                                break
                        if not found:
                            g4m_1y_tot[len(g4mx_month_lst)-1] += item_1y_tot
                            g4m_2y_tot[len(g4mx_month_lst)-1] += item_2y_tot

            # report type 3month_report
            elif dfdic["Report_Type"] == "3month-report":
                if real_date >= real_date1 and real_date <= real_date1end:
                    add_to_totals = True
                    found = False
                    for si in range(len(g3mx_month_lst)):
                        if g3mx_month_lst[si] <= real_date <= (g3mx_month_lst[si] + relativedelta(months=3) - datetime.timedelta(days=1)):
                            g3m_1y_tot[si] += item_1y_tot
                            g3m_2y_tot[si] += item_2y_tot
                            found = True
                            break
                    if not found:
                        g3m_1y_tot[len(g3mx_month_lst)-1] += item_1y_tot
                        g3m_2y_tot[len(g3mx_month_lst)-1] += item_2y_tot
    # find index of column and add item value added_date relativedelta(months=3) - datetime.timedelta(days=1)

                    # report type day_report
                if dfdic["compare_graph"]:
                    if real_date >= real_date3 and real_date <= real_date3end:
                        found = False
                        for si in range(len(g4mx_month_lst)):
                            if g4mx_month_lst[si] <= real_date <= (g4mx_month_lst[si] + relativedelta(months=3) - datetime.timedelta(days=1)):
                                g4m_1y_tot[si] += item_1y_tot
                                g4m_2y_tot[si] += item_2y_tot
                                found = True
                                break
                        if not found:
                            g4m_1y_tot[len(g4mx_month_lst)-1] += item_1y_tot
                            g4m_2y_tot[len(g4mx_month_lst)-1] += item_2y_tot
                """ -------- end of month 3month total calculations -------- """

            if dfdic["Report_Type"] == "season-report" or add_to_totals:
                """ --------calculate season totals----------- """
                # totals for graph 1
                if dfdic["Report_Type"] == "season-report":
                    if real_season not in g1x_season_lst:
                        g1x_season_lst.append(real_season)
                        for t in dfdic["typelist"]:
                            g1_1y_tot_of_types[t].append(0)
                            g1_2y_tot_of_types[t].append(0)
                else:
                    if "Total" not in g1x_season_lst:
                        g1x_season_lst.append("Total")
                        for t in dfdic["typelist"]:
                            g1_1y_tot_of_types[t].append(0)
                            g1_2y_tot_of_types[t].append(0)

                # find index and add . graph 1
                for si in range(len(g1x_season_lst)):
                    if (g1x_season_lst[si] == real_season and dfdic["Report_Type"] == "season-report") or (dfdic["Report_Type"] != "season-report"):
                        g1_1y_tot_of_types[real_type][si] += item_1y_tot
                        g1_2y_tot_of_types[real_type][si] += item_2y_tot

                # totals for graph

                found = False
                for si in range(len(g2x_lst)):
                    if g2x_lst[si] >= item_compare:
                        g2_1y_tot_of_types[real_type][si] += item_1y_tot
                        g2_2y_tot_of_types[real_type][si] += item_2y_tot
                        found = True
                        break
                if not found:
                    g2_1y_tot_of_types[real_type][len(
                        g2x_lst)-1] += item_1y_tot
                    g2_2y_tot_of_types[real_type][len(
                        g2x_lst)-1] += item_2y_tot

        # add new columns for future use
        df["Pace(sec)"] = pace_sec
        df["Season"] = season_lst
        df["Work_Type"] = work_type
        df["Work_Date"] = work_date
        df["Work_Joule"] = work_joule

        """--------- decide what to divide for each graph menu --------------"""
        # find string type of x coord.. graph 1 season
        if dfdic["Report_Type"] == "season-report":
            g1x_season_str = convert_numstr(g1x_season_lst)
        else:
            g1x_season_str = g1x_season_lst

        if (dfdic["Report_Type"] == "day-report" or dfdic["Report_Type"] == "week-report"):
            g3x_day_str =  convert_daystr(g3x_lst)
        elif (dfdic["Report_Type"] == "month-report" or dfdic["Report_Type"] == "3month-report"):
            g3mx_month_str =  convert_daystr(g3mx_month_lst)

        if dfdic["graphmenu"] == "pace":
            divide_1y_tot = 1000
            divide_2y_tot = 3600
            divide_1yday_tot = 1000
            divide_2yday_tot = 60
            # find string type of x coord.. graph 2 pace
            g2x_str = []
            for i in range(len(g2x_lst)):
                result, res_pace_str = sec_to_pace(g2x_lst[i])
                if result:
                    g2x_str.append(res_pace_str)
            if dfdic["Report_Type"] == "season-report":
                season1_title = 'Kms By Season'
                season2_title = 'Hours By Season'
                season1_xlabel = 'Season'
                season2_xlabel = 'Season'
            else:
                season1_title = 'Total Kms By Work Type'
                season2_title = 'Total Hours By Work Type'
                season1_xlabel = ' '
                season2_xlabel = ' '

            season1_ylabel = 'Workout Kms'
            season2_ylabel = 'Workout Hours'

            g3_title = 'Kms By Pace'
            g3_xlabel = 'Pace'
            g3_ylabel = 'Workout Kms'

            g4_title = 'Hours By Pace'
            g4_xlabel = 'Pace'
            g4_ylabel = 'Workout Hours'

            g5_xlabel = 'Date'
            g5_ylabel = 'Workout Kms'
            if dfdic["Report_Type"] == "3month-report":
                g5_title = 'Kms By 3month'
            elif dfdic["Report_Type"] == "month-report":
                g5_title = 'Kms By Month'
            elif dfdic["Report_Type"] == "week-report":
                g5_title = 'Kms By Week'
            elif dfdic["Report_Type"] == "day-report":
                g5_title = 'Kms By Date'

            g6_xlabel = 'Date'
            g6_ylabel = 'Workout Hours'
            if dfdic["Report_Type"] == "3month-report":
                g6_title = 'Duration By 3month'
            elif dfdic["Report_Type"] == "month-report":
                g6_title = 'Duration By Month'
            elif dfdic["Report_Type"] == "week-report":
                g6_title = 'Duration By Week'
                g6_ylabel = 'Workout Minutes'
            elif dfdic["Report_Type"] == "day-report":
                g6_title = 'Duration By Date'
                g6_ylabel = 'Workout Minutes'

        elif dfdic["graphmenu"] == "watt":
            divide_1y_tot = 1000
            divide_2y_tot = 3600
            divide_1yday_tot = 1000
            divide_2yday_tot = 60
            g2x_str =  convert_numstr(g2x_lst)
            if dfdic["Report_Type"] == "season-report":
                season1_title = 'KiloJoule By Season'
                season2_title = 'Hours By Season'
                season1_xlabel = 'Season'
                season2_xlabel = 'Season'
            else:
                season1_title = 'Total KiloJoule By Work Type'
                season2_title = 'Total Hours By Work Type'
                season1_xlabel = ' '
                season2_xlabel = ' '

            season1_ylabel = 'Workout KiloJoule'
            season2_ylabel = 'Workout Hours'

            g3_title = 'KiloJoule By Avg.Watt'
            g3_xlabel = 'Avg.Watt'
            g3_ylabel = 'Workout KiloJoule'

            g4_title = 'Hours By Avg.Watt'
            g4_xlabel = 'Avg.Watt'
            g4_ylabel = 'Workout Hours'

            g5_xlabel = 'Date'
            g5_ylabel = 'Workout KiloJoule'
            if dfdic["Report_Type"] == "3month-report":
                g5_title = 'KiloJoule By 3month'
            elif dfdic["Report_Type"] == "month-report":
                g5_title = 'KiloJoule By Month'
            elif dfdic["Report_Type"] == "week-report":
                g5_title = 'KiloJoule By Week'
            elif dfdic["Report_Type"] == "day-report":
                g5_title = 'KiloJoule By Date'

            g6_xlabel = 'Date'
            g6_ylabel = 'Workout Hours'
            if dfdic["Report_Type"] == "3month-report":
                g6_title = 'Duration By 3month'
            elif dfdic["Report_Type"] == "month-report":
                g6_title = 'Duration By Month'
            elif dfdic["Report_Type"] == "week-report":
                g6_title = 'Duration By Week'
                g6_ylabel = 'Workout Minutes'
            elif dfdic["Report_Type"] == "day-report":
                g6_title = 'Duration By Date'
                g6_ylabel = 'Workout Minutes'

        elif dfdic["graphmenu"] == "cal":
            divide_1y_tot = 1000
            divide_2y_tot = 3600
            divide_1yday_tot = 1
            divide_2yday_tot = 60
            g2x_str =  convert_numstr(g2x_lst)
            if dfdic["Report_Type"] == "season-report":
                season1_title = 'kcal By Season'
                season2_title = 'Hours By Season'
                season2_xlabel = 'Season'
                season1_xlabel = 'Season'
            else:
                season1_title = 'Total kcal By Work Type'
                season2_title = 'Total Hours By Work Type'
                season2_xlabel = ' '
                season1_xlabel = ' '

            season1_ylabel = 'Workout kcal'
            season2_ylabel = 'Workout Hours'

            g3_title = 'Total kcal By Avg.Cal'
            g3_xlabel = 'Avg.Cal'
            g3_ylabel = 'Workout Total kcal'

            g4_title = 'Hours By Avg.Cal'
            g4_xlabel = 'Avg.Cal'
            g4_ylabel = 'Workout Hours'

            g5_xlabel = 'Date'
            g5_ylabel = 'Workout kcal'
            if dfdic["Report_Type"] == "3month-report":
                g5_title = 'kcal By 3month'
            elif dfdic["Report_Type"] == "month-report":
                g5_title = 'kcal By Month'
            elif dfdic["Report_Type"] == "week-report":
                g5_title = 'cal By Week'
                g5_ylabel = 'Workout cal'
            elif dfdic["Report_Type"] == "day-report":
                g5_title = 'cal By Date'
                g5_ylabel = 'Workout cal'

            g6_xlabel = 'Date'
            g6_ylabel = 'Workout Hours'
            if dfdic["Report_Type"] == "3month-report":
                g6_title = 'Duration By 3month'
            elif dfdic["Report_Type"] == "month-report":
                g6_title = 'Duration By Month'
            elif dfdic["Report_Type"] == "week-report":
                g6_title = 'Duration By Week'
                g6_ylabel = 'Workout Minutes'
            elif dfdic["Report_Type"] == "day-report":
                g6_title = 'Duration By Date'
                g6_ylabel = 'Workout Minutes'

        # convert seasonal sec to hour..graph 1
        divide_tot_of_types(dfdic, g1x_season_lst,
                              g1_2y_tot_of_types, divide_2y_tot)

        divide_tot_of_types(dfdic, g1x_season_lst,
                              g1_1y_tot_of_types, divide_1y_tot)

        divide_tot_of_types(
            dfdic, g2x_lst, g2_2y_tot_of_types, divide_2y_tot)

        # convert pace mt to km.. graph2
        divide_tot_of_types(
            dfdic, g2x_lst, g2_1y_tot_of_types, divide_1y_tot)

        if dfdic["Report_Type"] == "day-report" or dfdic["Report_Type"] == "week-report":
            divide_graph_items(g3x_lst, g3_2y_tot,
                                 divide_2yday_tot, g3_1y_tot, divide_1yday_tot)

            if dfdic["compare_graph"]:
                divide_graph_items(
                    g4x_lst, g4_2y_tot, divide_2yday_tot, g4_1y_tot, divide_1yday_tot)

        if dfdic["Report_Type"] == "month-report" or dfdic["Report_Type"] == "3month-report":
            divide_graph_items(g3mx_month_lst, g3m_2y_tot,
                                 divide_2y_tot, g3m_1y_tot, divide_1y_tot)

            if dfdic["compare_graph"]:
                divide_graph_items(
                    g4mx_month_lst, g4m_2y_tot, divide_2y_tot, g4m_1y_tot, divide_1y_tot)

        """------------------------ season graph 1 -----------------------"""
        print_total_graph(pdf, plt, dfdic,
                            season1_title, season1_xlabel, season1_ylabel,
                            g1x_season_lst, g1x_season_str, g1_1y_tot_of_types
                            )
        """ ------pie char if number of slides > 1------- """
        print_pie_charts(pdf, plt, dfdic,
                           g1x_season_str, g1x_season_lst, g1_1y_tot_of_types,
                           season1_title
                           )
        """ ---------------- season graphs 2-------------------"""
        print_total_graph(pdf, plt, dfdic,
                            season2_title, season2_xlabel, season2_ylabel,
                            g1x_season_lst, g1x_season_str, g1_2y_tot_of_types
                            )

        """ --------pie char if number of slides > 1-------- """
        print_pie_charts(pdf, plt, dfdic,
                           g1x_season_str, g1x_season_lst, g1_2y_tot_of_types,
                           season2_title
                           )

        """ ----------pace graphs--meter --------------"""
        print_3graphs(pdf, plt, g2x_str, g2_1y_tot_of_types,
                        g3_title, g3_xlabel, g3_ylabel)

        """ ----------pace graphs- hour----------------"""
        print_3graphs(pdf, plt, g2x_str, g2_2y_tot_of_types,
                        g4_title, g4_xlabel, g4_ylabel)

        """ ----------day-week graphs--meter --------------"""
        if (dfdic["Report_Type"] == "day-report" or dfdic["Report_Type"] == "week-report"):
            if not dfdic["compare_graph"]:
                g4_1y_tot = {}
                dfdic_comp = ""
            else:
                dfdic_comp = dfdic["date3"]
            print_4graphs(pdf, plt, dfdic,
                            g3x_day_str, g3_1y_tot, g4_1y_tot,
                            g5_title, g5_xlabel, g5_ylabel,
                            dfdic["date1"], dfdic_comp)

        """ ----------day-week graphs- hour----------------"""
        if (dfdic["Report_Type"] == "day-report" or dfdic["Report_Type"] == "week-report"):
            if not dfdic["compare_graph"]:
                g4_2y_tot = {}
                dfdic_comp = ""
            else:
                dfdic_comp = dfdic["date3"]
            print_4graphs(pdf, plt, dfdic,
                            g3x_day_str, g3_2y_tot, g4_2y_tot,
                            g6_title, g6_xlabel, g6_ylabel,
                            dfdic["date1"], dfdic_comp)

        """ ----------month 3 month graphs--meter --------------"""
        if (dfdic["Report_Type"] == "month-report" or dfdic["Report_Type"] == "3month-report"):
            if not dfdic["compare_graph"]:
                g4m_1y_tot = {}
                dfdic_comp = ""
            else:
                dfdic_comp = (dfdic["month3"]+"/"+dfdic["year3"])

            print_4graphs(pdf, plt, dfdic,
                            g3mx_month_str, g3m_1y_tot, g4m_1y_tot,
                            g5_title, g5_xlabel, g5_ylabel,
                            (dfdic["month1"]+"/"+dfdic["year1"]), dfdic_comp)

        """ ----------month 3month graphs- hour----------------"""
        if (dfdic["Report_Type"] == "month-report" or dfdic["Report_Type"] == "3month-report"):
            if not dfdic["compare_graph"]:
                g4m_2y_tot = {}
                dfdic_comp = ""
            else:
                dfdic_comp = (dfdic["month3"]+"/"+dfdic["year3"])
            print_4graphs(pdf, plt, dfdic,
                            g3mx_month_str, g3m_2y_tot, g4m_2y_tot,
                            g6_title, g6_xlabel, g6_ylabel,
                            (dfdic["month1"]+"/"+dfdic["year1"]), dfdic_comp)

        """ --------------- last page --------------------"""
        try:
            plt.rcParams['text.usetex'] = False
            fig = plt.figure(figsize=(10, 6))
            fig.clf()
            xcor = 1 - 0.05
            for txt in dfdic["filter_msgs"]:
                fig.text(0.5, xcor, txt,  size=10, ha="center")
                xcor = xcor - 0.05

            pdf.savefig(fig)  # or you can pass a Figure object to pdf.savefig
            plt.close()
        except Exception as e:
            err_message = f"multipage_pdf_last_page:Plot exception11: {e}"
            logging.info(f"{err_message}" )

        # We can also set the file's metadata via the PdfPages object:
        d = pdf.infodict()
        d['Title'] = dfdic["maintitle"]
        d['Author'] = dfdic["author"]
        d['Subject'] = dfdic["subject"]
        d['Keywords'] = dfdic["keywords"]
        d['CreationDate'] = datetime.datetime.today()
        d['ModDate'] = datetime.datetime.today()
