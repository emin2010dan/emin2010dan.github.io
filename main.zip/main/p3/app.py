from flask import Flask

import os
execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))
if execution_dir == file_dir:
    INDISPATCHER = False
else:
    INDISPATCHER = True   

if INDISPATCHER:
    PREFIX="/p"
else:
    PREFIX=""
print("-------------INDISPATCHER=",INDISPATCHER,"-------PREFIX=",PREFIX)


app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!333'


@app.route('/x')
def hello_worldx():
    return 'Hello World!x 333'


if __name__ == '__main__':
    app.run(debug=True)
