import csv
import re
import cv2
import numpy as np
from PIL import Image, ImageFilter
from flask import redirect, render_template, session
from functools import wraps
from datetime import datetime
import os
import logging
import random
import copy

execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))
if execution_dir == file_dir:
    INDISPATCHER = False
else:
    INDISPATCHER = True

if INDISPATCHER:
    PREFIX = "/p"
    from .pconfig import FILE_DIR,STATIC_FOLDER, DATABASE,PLANSHEADER,PLANHEADER,EXERCISEHEADER,RGBHEADER
else:
    PREFIX = ""
    from pconfig import FILE_DIR,STATIC_FOLDER, DATABASE,PLANSHEADER,PLANHEADER,EXERCISEHEADER,RGBHEADER


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    logging.info("p-Apology:" + message)
    return render_template("papology.html", PREFIX=PREFIX, top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.
    yenisi
    https://flask.palletsprojects.com/en/2.3.x/patterns/viewdecorators/#view-decorators

    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not ('user_id' in session):
            # if session.get("user_id") is None:
            return redirect(PREFIX+"/login")
        return f(*args, **kwargs)

    return decorated_function


def checkpassword(password):
    """check password."""
    if len(password) < 8:
        return False, "Password must be longer than 7 chars"
    elif not re.search("[a-z]", password):
        return False, "Password must contain lowercase"
    elif not re.search("[A-Z]", password):
        return False, "Password must contain uppercase"
    elif not re.search("[0-9]", password):
        return False, "Password must contain numbers"
    else:
        return True, "valid password"


def dict_factory(cursor, row):
    """ convert to dictionary """
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

def controlcsv(df, CONTROLLIST):
    """control csv headers"""
    seqlist = df[0].keys()

    for i in CONTROLLIST:
        if not (i  in seqlist):
            return False
    return True



def read_plans():
    """ read plans """
    csv_filename = os.path.join(STATIC_FOLDER, "chatgpt plans.csv")

    db_plans = []

    try:
        with open(csv_filename) as dbfile:
            db_reader = csv.DictReader(dbfile)
            for dbline in db_reader:
                if dbline["Exercise Name"] == "" or dbline["Exercise Name"] is None:
                    err_message = f"Error Empty Exercise Name: "
                    logging.error(f"read_plans: {err_message} : csv_filename:{csv_filename}")
                    return False, err_message, db_plans 
                if dbline["How Many Days"] == "" or dbline["How Many Days"] is None or (not str(dbline["How Many Days"]).isdigit()) :
                    err_message = f"Error How Many Days:  "
                    logging.error(f"read_plans: {err_message} : csv_filename:{csv_filename}")
                    return False, err_message, db_plans 
                db_plans.append(dbline)

        if not controlcsv(db_plans, PLANSHEADER):
            err_message = f"Plans Header Error:   Name {csv_filename}"
            logging.error(f"read_plans: {err_message}")
            return False, err_message, db_plans


        
        for pi in range(len(db_plans)):
            plan_filename = os.path.join(STATIC_FOLDER, db_plans[pi]["Csv File"] + ".csv")
            db_plan = []
            with open(plan_filename) as dbfile:
                db_reader = csv.DictReader(dbfile)
                for dbline in db_reader:
                    if dbline["Day"] == "" or dbline["Day"] is None:
                        err_message = f"Error Empty Day "
                        logging.error(f"read_plans: {err_message} : plan_filename:{plan_filename}")
                        return False, err_message, db_plans 
                    
                    if len(dbline["Day"].split()) != 2:
                        err_message = f"Error value Day: {dbline['Day']} "
                        logging.error(f"read_plans: {err_message} : plan_filename:{plan_filename}")
                        return False, err_message, db_plans 

                    if  (not str(dbline["Day"].split()[1]).isdigit()):
                        err_message = f"Error value not digit Day: {dbline['Day']} "
                        logging.error(f"read_plans: {err_message} : plan_filename:{plan_filename}")
                        return False, err_message, db_plans 
                    db_plan.append(dbline)

            if not controlcsv(db_plan, PLANHEADER):
                err_message = f"Plan Header Error:   Name {csv_filename}"
                logging.error(f"read_plans: {err_message}")
                return False, err_message, db_plans
            db_plans[pi]["plan"] = db_plan

    except Exception as e:
        err_message = f"Error reading plans: {e}"
        logging.error(f"read_plans: {err_message}")
        return False, err_message, db_plans
    
    return True,"",db_plans
    

def create_masks():
    """ createmasks for PIL """
    csv_filename = os.path.join(STATIC_FOLDER, "rgb.csv")
    
    db_mask = []
    dbsor = []
    dbbck = []
    dbbody = []
    try:
        try:
            with open(csv_filename) as dbfile:
                db_reader = csv.DictReader(dbfile)
                for dbline in db_reader:
                    db_mask.append(dbline)
        except Exception as e:
            err_message = f"Error reading csv file: {e}"
            logging.error(
                f"create_masks: {err_message} : csv_filename:{csv_filename}")
            return False, err_message, db_mask, dbsor, dbbck,dbbody
        
        if not controlcsv(db_mask, RGBHEADER):
            err_message = f"rgb Header Error:   Name {csv_filename}"
            logging.error(f"create_masks: {err_message}")
            return False, err_message, db_mask, dbsor, dbbck,dbbody

        for i in range(len(db_mask)):
            db_mask[i]["mask"] = []

        for bi in range(2):
            body_filename = os.path.join(STATIC_FOLDER, "body"+str(bi)+".png")
            try:
                bodyimage = Image.open(body_filename)
            except Exception as e:
                err_message = f"Error getting body image: {e}"
                logging.error(f"create_masks: {err_message}")
                return False, err_message,db_mask, dbsor, dbbck,dbbody
            bodysize = bodyimage.size
            dbbody.append(bodyimage)

            mask_filename = os.path.join(STATIC_FOLDER, "coloured_mask"+str(bi)+".png")
            try:
                cmask = cv2.imread(mask_filename)
            except Exception as e:
                err_message = f"Error reading mask file: {e}"
                logging.error(
                    f"create_masks: {err_message} : mask_filename:{mask_filename}")
                return False, err_message, db_mask, dbsor, dbbck,dbbody

            for i in range(len(db_mask)):
                
                lower_color = np.array(
                    [int(db_mask[i]["B"]), int(db_mask[i]["G"]), int(db_mask[i]["R"])])
                upper_color = np.array(
                    [int(db_mask[i]["B"]), int(db_mask[i]["G"]), int(db_mask[i]["R"])])

                mask2 = cv2.inRange(cmask, lower_color, upper_color)
                tmp_mask_filename = os.path.join(
                    STATIC_FOLDER, "M_" + db_mask[i]["Muscle"]+str(bi)+".png")

                cv2.imwrite(tmp_mask_filename, mask2)
                maskf = Image.open(tmp_mask_filename)
                db_mask[i]["mask"].append(maskf)

        for i in range(5):

            sorr_filename = os.path.join(
                STATIC_FOLDER, "sore" + str(i) + ".png")

            try:
                sorrimage = Image.open(sorr_filename)
            except Exception as e:
                err_message = f"Error getting soreness image: {e} sorr_filename:{sorr_filename}"
                logging.error(f"create_masks: {err_message}")
                return False, err_message,db_mask, dbsor, dbbck,dbbody
            dbsor.append(sorrimage)

            bck_filename = os.path.join(
                STATIC_FOLDER, "bck" + str(i) + ".jpg")

            try:
                background = Image.open(bck_filename).resize(bodysize)
            except Exception as e:
                err_message = f"Error getting bck image: {e}"
                logging.error(f"create_masks: {err_message}")
                return False, err_message,db_mask, dbsor, dbbck,dbbody
            dbbck.append(background)

    except Exception as e:
        err_message = f"Error getting masks: {e}"
        logging.error(f"create_masks: {err_message}")
        return False, err_message, db_mask, dbsor, dbbck,dbbody

    return True, "", db_mask, dbsor, dbbck,dbbody


def find_soreness(db_mask):
    """ 
    returns result, err_message, db__user   
    """
    err_message = ""
    total = 0
    db_user = {}
    db_user["sx"] = random.randint(0, 1)
    try:

        #logging.info(db_mask )
        for i in range(len(db_mask)):
            db_user[db_mask[i]["Muscle"]] = random.randint(1, 5)
            total = total + (db_user[db_mask[i]["Muscle"]]
                             * int(db_mask[i]["Percentage"]) / 100.0)

        soreness_level = round(total * 100.0 / 5.0)
        if soreness_level > 80:
            err_message = "Rest Welll,Soreness Level:" + str(soreness_level)
        elif soreness_level > 60:
            err_message = "Rest, Soreness Level:" + str(soreness_level)
        elif soreness_level > 20:
            err_message = "Soreness Level:" + str(soreness_level)
        elif soreness_level < 10:
            err_message = "Go to Gym,Soreness Level:" + str(soreness_level)

    except Exception as e:
        err_message = f"Error finding soreness: {e}"
        logging.error(f"find soreness: {err_message}")
        return False, err_message, db_user

    return True, err_message, db_user


def create_bd_image(DB_MASK, DB_SOR, DB_BCK,DB_BODY, db_user, user_imagename):
    """
    returns result, err_message  
    """
    user_sx = db_user["sx"]
    bodyimage = DB_BODY[user_sx]

    background = DB_BCK[int(db_user["Backround"]) - 1]

    try:

        for i in range(1, len(DB_MASK)):
            # sornes = 1-5, db_sor = 0-4
            sorrimage = DB_SOR[db_user[DB_MASK[i]["Muscle"]] - 1]
            maskg = DB_MASK[i]["mask"][user_sx]
            bodyimage.paste(sorrimage, (0, 0), mask=maskg)

        # mask[0] is background mask
        maskg = DB_MASK[0]["mask"][user_sx]
        bodyimage.paste(background, (0, 0), mask=maskg)
        bodyimage = bodyimage.filter(ImageFilter.GaussianBlur(radius=1))

    except Exception as e:
        err_message = f"Error: {e}"
        logging.error(f"create_bd_image: {err_message}")
        return False, err_message

    bodyimage.save(user_imagename)
    return True, ""


def read_exercises():
    """ read exercises """
    csv_filename = os.path.join(STATIC_FOLDER, "chatgpt exercises.csv")
    db_ex = []

    try:
        with open(csv_filename) as dbfile:
            db_reader = csv.DictReader(dbfile)
            id_count = 0
            for dbline in db_reader:
                if dbline["Exercise Name"] == "" or dbline["Exercise Name"] is None:
                    err_message = f"Error Empty Exercise Name: "
                    logging.error(f"read_exercises: {err_message} : csv_filename:{csv_filename}")
                    return False, err_message, db_ex 
                dbline["id"] = id_count
                id_count = id_count + 1
                db_ex.append(dbline)
    except Exception as e:
        err_message = f"Error reading csv file: {e}"
        logging.error(
            f"read_exercises: {err_message} : csv_filename:{csv_filename}")
        return False, err_message, db_ex
    
    if not controlcsv(db_ex, EXERCISEHEADER):
        err_message = f"Exercise Header Error:  Name {csv_filename}"
        logging.error(f"read_exercises: {err_message}")
        return False, err_message, db_ex
    
    return True, "", db_ex

def read_user_plan(user_id):
        """ read user plan """
        user_plan = []
        #check if user has plan or not
        
        plan_csvname = FILE_DIR + "/static/images/u" + str(user_id) + "plan.csv"
        if os.path.isfile(plan_csvname):
            try:
                with open(plan_csvname) as dbfile:
                    db_reader = csv.DictReader(dbfile)
                    for dbline in db_reader:
                        user_plan.append(dbline)

            except Exception as e:
                err_message = f"Error reading user plan: {e}"
                logging.error(f"read_user_plan: {err_message}")
                return False, err_message, user_plan   
        return True,"",user_plan

def write_user_plan(user_id,user_plan):
        """ write user plan """

        try:
            plan_csvname = FILE_DIR + "/static/images/u" + str(user_id) + "plan.csv"
            if os.path.isfile(plan_csvname):
                datestamp=datetime.now().strftime("%Y%m%d_%H%M%S")
                old_csvname = FILE_DIR + "/static/images/o" + str(user_id) + "_" +datestamp + "plan.csv"
                os.rename(plan_csvname, old_csvname)

            with open(plan_csvname, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=user_plan[0].keys())
                writer.writeheader()
                for  row in user_plan:
                    writer.writerow(row)
        except Exception as e:
            err_message = f"Error writing user plan: {e}"
            logging.error(f"write_user_plan: {err_message}")
            return False, err_message
        return True,""

def get_weekday_abbr(nowvalue):
    """ get weekday """
    return nowvalue.strftime('%a')

def get_max_id(anylist):
    """ get max id of any dict list """
    max_id = 0
    for iv in anylist:
        if int(iv["id"]) > max_id:
            max_id = int(iv["id"])
    return max_id

def create_todayadvice(db_user,todayplan,db_ex,db_mask):
    """ create todays advice
    returns: result, err_message, advicestr, todayadvice
    """
    todayplan_ext = copy.deepcopy(todayplan)
    err_message = ""
    advicestr = ""
    todayadvice = []
    todays_plan_sorenes = {}
    for mi in range(1,len(db_mask)):
        todays_plan_sorenes[db_mask[mi]["Muscle"]] = 0
        todays_plan_sorenes[db_mask[mi]["Muscle"]+"_exercises"] = []

    # find todays total soreness of todays exercises
    for ti in range(len(todayplan_ext)):
        exercise_name = todayplan_ext[ti]["Exercise Name"]
        exercise_sets =  todayplan_ext[ti]["Number of Sets"]
        # if it is 3 set then normal sorenes
        # if more than 3 than more soreness
        exercise_sorenes_weight = int(exercise_sets) / 3.0
        ex_id = None
        for ei in range(len(db_ex)):
            if exercise_name == db_ex[ei]["Exercise Name"]:
                ex_id = ei
                break
        if ex_id == None:
            err_message= "Exercise not Found{exercise_name}"
            logging.critical(f"create_todayadvice:{err_message} ")
            return False,err_message,advicestr,todayadvice
        
        for di in range(1,len(db_mask)): 
            if not (db_mask[di]["Muscle"] in db_ex[ex_id]):
                err_message= 'Muscle {db_mask[di]["Muscle"]} not Found in exercise {exercise_name}'
                logging.critical(f"create_todayadvice:{err_message} ")
                return False,err_message,advicestr,todayadvice 
            inc_value = ( int(db_ex[ex_id][db_mask[di]["Muscle"]]) * exercise_sorenes_weight)
            if inc_value > 0:
                todays_plan_sorenes[db_mask[di]["Muscle"]+"_exercises"].append(db_ex[ex_id]["Exercise Name"]) 
            todays_plan_sorenes[db_mask[di]["Muscle"]] += inc_value

    # find todays total soreness after exercise by adding db_users
    todays_total_sorenes = {}
    for i in range(1,len(db_mask)):
        todays_total_sorenes[db_mask[i]["Muscle"]] = todays_plan_sorenes[db_mask[i]["Muscle"]] + db_user[db_mask[i]["Muscle"]]
    #print("========================================================================")
    #print("-------todays_total_sorenes-------------",todays_total_sorenes)
    #print("----------------------")
    #print("-------todays_plan_sorenes-------------",todays_plan_sorenes)
    #print("----------------------")
    #print("-------todays_db_user-------------",db_user)

    critic_ex = []
    warn_ex = []
    for di in range(1,len(db_mask)):
        if todays_total_sorenes[db_mask[di]["Muscle"]] > 7:
            todayadvice.append({ "Subject": db_mask[di]["Muscle"], "Advice": "is overtraining" })
            for exname in todays_plan_sorenes[db_mask[di]["Muscle"]+"_exercises"]:
                if not exname in critic_ex:
                    critic_ex.append(exname)
        elif  todays_total_sorenes[db_mask[di]["Muscle"]] > 5:
            todayadvice.append({ "Subject": db_mask[di]["Muscle"], "Advice": "is under risk" })    
            for exname in todays_plan_sorenes[db_mask[di]["Muscle"]+"_exercises"]:
                if not exname in warn_ex:
                    warn_ex.append(exname) 

    todayadvice.append({ "Subject": "", "Advice": "" })
    for ti in range(len(todayplan_ext)):
        if todayplan_ext[ti]["Exercise Name"]  in  critic_ex:
            todayadvice.append({ "Subject": todayplan_ext[ti]["Exercise Name"], "Advice": "work light or cancel" })                 
            
        elif todayplan_ext[ti]["Exercise Name"]  in  warn_ex:
            todayadvice.append({ "Subject": todayplan_ext[ti]["Exercise Name"], "Advice": "work light with caution" })
    
    if len(critic_ex) > 0:
        advicestr = "Critical Advices"
    elif len(warn_ex) > 0:
        advicestr = "Warnings"

    return True, "", advicestr, todayadvice
