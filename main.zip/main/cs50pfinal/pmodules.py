"""
modules of main project

"""

import csv
import re
import cv2
import numpy as np
from PIL import Image, ImageFilter
from flask import redirect, render_template, session, request
from functools import wraps
from datetime import datetime, timedelta
import os
import logging
import copy
import sqlite3 as sql


execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))

# Is Dispatcher ACTIVE or NOT
if execution_dir == file_dir:
    INDISPATCHER = False
else:
    INDISPATCHER = True

if INDISPATCHER:
    PREFIX = "/p"
    from .pconfig import (
        FILE_DIR,
        STATIC_FOLDER,
        DATABASE,
        PLANSHEADER,
        PLANHEADER,
        EXERCISEHEADER,
        RGBHEADER,
    )
else:
    PREFIX = ""
    from pconfig import (
        FILE_DIR,
        STATIC_FOLDER,
        DATABASE,
        PLANSHEADER,
        PLANHEADER,
        EXERCISEHEADER,
        RGBHEADER,
    )


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    logging.info("p-Apology:" + message)
    return (
        render_template(
            "papology.html", PREFIX=PREFIX, top=code, bottom=escape(message)
        ),
        code,
    )


def login_required(f):
    """
    Decorate routes to require login.
    new link
    https://flask.palletsprojects.com/en/2.3.x/patterns/viewdecorators/#view-decorators

    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not ("user_id" in session):
            # if session.get("user_id") is None:
            return redirect(PREFIX + "/login")
        return f(*args, **kwargs)

    return decorated_function


def checkpassword(password):
    """
    check password.
    """
    if len(password) < 8:
        return False, "Password must be longer than 7 chars"
    elif not re.search("[a-z]", password):
        return False, "Password must contain lowercase"
    elif not re.search("[A-Z]", password):
        return False, "Password must contain uppercase"
    elif not re.search("[0-9]", password):
        return False, "Password must contain numbers"
    else:
        return True, "valid password"


def dict_factory(cursor, row):
    """
    convert to dictionary
    """
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


def controlcsv(df, CONTROLLIST):
    """control csv headers"""
    seqlist = df[0].keys()

    for i in CONTROLLIST:
        if not (i in seqlist):
            return False
    return True


def read_plans(db_ex, dic_ex):
    """read plans"""
    csv_filename = os.path.join(STATIC_FOLDER, "chatgpt plans.csv")

    db_plans = []

    try:
        with open(csv_filename) as dbfile:
            db_reader = csv.DictReader(dbfile)
            for dbline in db_reader:
                if dbline["Exercise Name"] == "" or dbline["Exercise Name"] is None:
                    err_message = f"Error Empty Exercise Name: "
                    logging.error(
                        f"read_plans: {err_message} : csv_filename:{csv_filename}"
                    )
                    return False, err_message, db_plans
                if (
                    dbline["How Many Days"] == ""
                    or dbline["How Many Days"] is None
                    or (not str(dbline["How Many Days"]).isdigit())
                ):
                    err_message = f"Error How Many Days:  "
                    logging.error(
                        f"read_plans: {err_message} : csv_filename:{csv_filename}"
                    )
                    return False, err_message, db_plans
                db_plans.append(dbline)

        if not controlcsv(db_plans, PLANSHEADER):
            err_message = f"Plans Header Error:   Name {csv_filename}"
            logging.error(f"read_plans: {err_message}")
            return False, err_message, db_plans

        for pi in range(len(db_plans)):
            plan_filename = os.path.join(
                STATIC_FOLDER, db_plans[pi]["Csv File"] + ".csv"
            )
            db_plan = []
            with open(plan_filename) as dbfile:
                db_reader = csv.DictReader(dbfile)
                for dbline in db_reader:
                    if dbline["Day"] == "" or dbline["Day"] is None:
                        err_message = f"Error Empty Day "
                        logging.error(
                            f"read_plans: {err_message} : plan_filename:{plan_filename}"
                        )
                        return False, err_message, db_plans

                    if len(dbline["Day"].split()) != 2:
                        err_message = f"Error value Day: {dbline['Day']} "
                        logging.error(
                            f"read_plans: {err_message} : plan_filename:{plan_filename}"
                        )
                        return False, err_message, db_plans

                    if not str(dbline["Day"].split()[1]).isdigit():
                        err_message = f"Error value not digit Day: {dbline['Day']} "
                        logging.error(
                            f"read_plans: {err_message} : plan_filename:{plan_filename}"
                        )
                        return False, err_message, db_plans
                    if not dbline["Exercise Name"] in dic_ex:
                        err_message = f'undefined exercise{dbline["Exercise Name"]} '
                        logging.error(f"read_plans: {err_message}")
                        return False, err_message, db_plans
                    dbline["VideoLink"] = db_ex[dic_ex[dbline["Exercise Name"]]][
                        "VideoLink"
                    ]
                    db_plan.append(dbline)

            if not controlcsv(db_plan, PLANHEADER):
                err_message = f"Plan Header Error:   Name {csv_filename}"
                logging.error(f"read_plans: {err_message}")
                return False, err_message, db_plans
            db_plans[pi]["plan"] = db_plan

    except Exception as e:
        err_message = f"Error reading plans: {e}"
        logging.error(f"read_plans: {err_message}")
        return False, err_message, db_plans

    return True, "", db_plans


def create_masks():
    """createmasks for PIL"""
    csv_filename = os.path.join(STATIC_FOLDER, "rgb.csv")

    db_mask = []
    dbsor = []
    dbbck = []
    dbbody = []
    try:
        # read rgb file for muscles
        try:
            with open(csv_filename) as dbfile:
                db_reader = csv.DictReader(dbfile)
                for dbline in db_reader:
                    db_mask.append(dbline)
        except Exception as e:
            err_message = f"Error reading csv file: {e}"
            logging.error(f"create_masks: {err_message} : csv_filename:{csv_filename}")
            return False, err_message, db_mask, dbsor, dbbck, dbbody

        if not controlcsv(db_mask, RGBHEADER):
            err_message = f"rgb Header Error:   Name {csv_filename}"
            logging.error(f"create_masks: {err_message}")
            return False, err_message, db_mask, dbsor, dbbck, dbbody

        # create mask files of every muscle and save to memeory
        for i in range(len(db_mask)):
            db_mask[i]["mask"] = []

        for bi in range(2):
            body_filename = os.path.join(STATIC_FOLDER, "body" + str(bi) + ".png")
            try:
                bodyimage = Image.open(body_filename)
            except Exception as e:
                err_message = f"Error getting body image: {e}"
                logging.error(f"create_masks: {err_message}")
                return False, err_message, db_mask, dbsor, dbbck, dbbody
            bodysize = bodyimage.size
            dbbody.append(bodyimage)

            mask_filename = os.path.join(
                STATIC_FOLDER, "coloured_mask" + str(bi) + ".png"
            )
            try:
                cmask = cv2.imread(mask_filename)
            except Exception as e:
                err_message = f"Error reading mask file: {e}"
                logging.error(
                    f"create_masks: {err_message} : mask_filename:{mask_filename}"
                )
                return False, err_message, db_mask, dbsor, dbbck, dbbody

            for i in range(len(db_mask)):
                # every muscle has its colors in colored image< use them to create muscle masks
                lower_color = np.array(
                    [int(db_mask[i]["B"]), int(db_mask[i]["G"]), int(db_mask[i]["R"])]
                )
                upper_color = np.array(
                    [int(db_mask[i]["B"]), int(db_mask[i]["G"]), int(db_mask[i]["R"])]
                )

                mask2 = cv2.inRange(cmask, lower_color, upper_color)
                tmp_mask_filename = os.path.join(
                    STATIC_FOLDER, "M_" + db_mask[i]["Muscle"] + str(bi) + ".png"
                )

                # save the mask images to disk for debug purposes
                cv2.imwrite(tmp_mask_filename, mask2)
                maskf = Image.open(tmp_mask_filename)
                db_mask[i]["mask"].append(maskf)

        # read soreness files to memory for fast processing
        for i in range(5):
            sorr_filename = os.path.join(STATIC_FOLDER, "sore" + str(i) + ".png")

            try:
                sorrimage = Image.open(sorr_filename)
            except Exception as e:
                err_message = (
                    f"Error getting soreness image: {e} sorr_filename:{sorr_filename}"
                )
                logging.error(f"create_masks: {err_message}")
                return False, err_message, db_mask, dbsor, dbbck, dbbody
            dbsor.append(sorrimage)

            bck_filename = os.path.join(STATIC_FOLDER, "bck" + str(i) + ".jpg")

            try:
                background = Image.open(bck_filename).resize(bodysize)
            except Exception as e:
                err_message = f"Error getting bck image: {e}"
                logging.error(f"create_masks: {err_message}")
                return False, err_message, db_mask, dbsor, dbbck, dbbody
            dbbck.append(background)

    except Exception as e:
        err_message = f"Error getting masks: {e}"
        logging.error(f"create_masks: {err_message}")
        return False, err_message, db_mask, dbsor, dbbck, dbbody

    return True, "", db_mask, dbsor, dbbck, dbbody


def find_soreness(db_mask, len_db_mask, db_ex, dic_ex):
    """
    find soreness of body
    returns result, err_message, db__user
    """
    err_message = ""
    db_user = {}

    try:
        for di in range(len_db_mask):
            db_user[db_mask[di]["Muscle"]] = 0

        get_workdate = get_todayYMD(datetime.now())
        for daycount in range(session["recovery_level"]):
            result, err_message, user_work = get_recorded_workouts(get_workdate)
            if not result:
                return False, err_message, db_user

            # ATTENTION THIS LOOP'S ALGORITHM MUST BE SAME WITH ADVICES
            # calculate soreness of a day
            days_plan_sorenes = {}
            for mi in range(1, len_db_mask):
                days_plan_sorenes[db_mask[mi]["Muscle"]] = 0

            for pi in range(len(user_work)):
                exercise_name = user_work[pi]["exercise_name"]
                exercise_sets = user_work[pi]["number_of_sets"]
                intensity_level = user_work[pi]["intensity_level"]
                # if it is 3 set then normal sorenes
                # if more than 3 than more soreness
                exercise_sorenes_weight = int(exercise_sets) / 3.0
                if intensity_level == "light":
                    exercise_sorenes_weight = exercise_sorenes_weight * 0.5
                elif intensity_level == "hard":
                    exercise_sorenes_weight = exercise_sorenes_weight * 1.5

                if not exercise_name in dic_ex:
                    err_message = "Exercise not Found{exercise_name}"
                    logging.critical(f"find_soreness:{err_message} ")
                    return False, err_message, db_user
                ex_id = dic_ex[exercise_name]

                # temporary control
                if exercise_name != db_ex[ex_id]["Exercise Name"]:
                    err_message = "dic_ex error id {ex_id} {exercise_name}"
                    logging.critical(f"find_soreness:{err_message} ")
                    return False, err_message, db_user

                # calculate soreness of 1 exercise
                soreness_of_fulbody = 0
                if not ("FullBody" in db_ex[ex_id]):
                    err_message = (
                        "Muscle FullBody not Found in exercise {exercise_name}"
                    )
                    logging.critical(f"find_soreness:{err_message} ")
                    return False, err_message, db_user
                soreness_of_fulbody = int(db_ex[ex_id]["FullBody"])

                for di in range(1, len_db_mask):
                    soreness_of_1muscle = 0
                    if not (db_mask[di]["Muscle"] in db_ex[ex_id]):
                        err_message = 'Muscle {db_mask[di]["Muscle"]} not Found in exercise {exercise_name}'
                        logging.critical(f"find_soreness:{err_message} ")
                        return False, err_message, db_user
                    else:
                        soreness_of_1muscle = int(db_ex[ex_id][db_mask[di]["Muscle"]])
                    # get soreness from full body exercise
                    if soreness_of_1muscle == 0:
                        soreness_of_1muscle = soreness_of_fulbody

                    inc_value = soreness_of_1muscle * exercise_sorenes_weight
                    days_plan_sorenes[db_mask[di]["Muscle"]] += inc_value

            # if user rest completely in  session["recovery_level"]
            for di in range(1, len_db_mask):
                days_plan_sorenes[db_mask[di]["Muscle"]] = float(
                    days_plan_sorenes[db_mask[di]["Muscle"]]
                    / session["recovery_level"]
                    * (session["recovery_level"] - daycount)
                )
                db_user[db_mask[di]["Muscle"]] = (
                    db_user[db_mask[di]["Muscle"]]
                    + days_plan_sorenes[db_mask[di]["Muscle"]]
                )

            # print("---------total soreness---------------daycount--------",daycount)
            # print(db_user)

            get_workdate = get_beforedate(get_workdate)

        total = 0
        for di in range(1, len_db_mask):
            db_user[db_mask[di]["Muscle"]] = round(db_user[db_mask[di]["Muscle"]])
            if db_user[db_mask[di]["Muscle"]] > 4:
                db_user[db_mask[di]["Muscle"]] = 4
            elif db_user[db_mask[di]["Muscle"]] < 0:
                db_user[db_mask[di]["Muscle"]] = 0
            total = total + (
                db_user[db_mask[di]["Muscle"]] * int(db_mask[di]["Percentage"]) / 100.0
            )

        db_user["Backround"] = min(round(total), 4)

        # print("---------sondurum soreness---------------total--------",total)
        # print(db_user)

        soreness_level = round(total * 100.0 / 4.0)
        if soreness_level > 95:
            err_message = "Rest Welll,Soreness Level:" + str(soreness_level)
        elif soreness_level > 75:
            err_message = "Rest, Soreness Level:" + str(soreness_level)
        elif soreness_level > 10:
            err_message = "Soreness Level:" + str(soreness_level)
        elif soreness_level < 10:
            err_message = "Go to Gym.Soreness Level:" + str(soreness_level)

    except Exception as e:
        err_message = f"Error finding soreness: {e}"
        logging.error(f"find soreness: {err_message}")
        return False, err_message, db_user

    return True, err_message, db_user


def create_bd_image(
    DB_MASK, len_db_mask, DB_SOR, DB_BCK, DB_BODY, db_user, user_imagename
):
    """
    create body image using soreness data db_user
    returns result, err_message
    """

    user_sx = session["user_sx"]
    bodyimage = DB_BODY[user_sx]

    background = DB_BCK[int(db_user["Backround"])]

    try:
        for i in range(1, len_db_mask):
            # sornes = 1-5, db_sor = 0-4
            sorrimage = DB_SOR[db_user[DB_MASK[i]["Muscle"]]]
            maskg = DB_MASK[i]["mask"][user_sx]
            bodyimage.paste(sorrimage, (0, 0), mask=maskg)

        # mask[0] is background mask
        maskg = DB_MASK[0]["mask"][user_sx]
        bodyimage.paste(background, (0, 0), mask=maskg)
        bodyimage = bodyimage.filter(ImageFilter.GaussianBlur(radius=1))

    except Exception as e:
        err_message = f"Error: {e}"
        logging.error(f"create_bd_image: {err_message}")
        return False, err_message

    bodyimage.save(user_imagename)
    return True, ""


def read_exercises():
    """
    read exercises from csvs and control and index them
    """

    # main exercise definition csv
    csv_filename = os.path.join(STATIC_FOLDER, "chatgpt exercises.csv")
    db_ex = []
    dic_ex = {}
    try:
        with open(csv_filename) as dbfile:
            db_reader = csv.DictReader(dbfile)
            id_count = 0
            for dbline in db_reader:
                if dbline["Exercise Name"] == "" or dbline["Exercise Name"] is None:
                    err_message = f"Error Empty Exercise Name: "
                    logging.error(
                        f"read_exercises: {err_message} : csv_filename:{csv_filename}"
                    )
                    return False, err_message, db_ex
                dbline["id"] = id_count
                dic_ex[dbline["Exercise Name"]] = id_count
                id_count = id_count + 1
                db_ex.append(dbline)

    except Exception as e:
        err_message = f"Error reading csv file: {e}"
        logging.error(f"read_exercises: {err_message} : csv_filename:{csv_filename}")
        return False, err_message, db_ex

    if not controlcsv(db_ex, EXERCISEHEADER):
        err_message = f"Exercise Header Error:  Name {csv_filename}"
        logging.error(f"read_exercises: {err_message}")
        return False, err_message, db_ex

    return True, "", db_ex, dic_ex


def read_user_plan(user_id, db_ex, dic_ex):
    """
    read user plan if exists
    get videolink from exercise file
    """
    user_plan = []
    # check if user has plan or not

    plan_csvname = FILE_DIR + "/static/images/u" + str(user_id) + "plan.csv"
    if os.path.isfile(plan_csvname):
        try:
            with open(plan_csvname) as dbfile:
                db_reader = csv.DictReader(dbfile)
                for dbline in db_reader:
                    if not dbline["Exercise Name"] in dic_ex:
                        err_message = f'Error in user plan:undefined exercise{dbline["Exercise Name"]} '
                        logging.error(f"read_user_plan: {err_message}")
                        return False, err_message, user_plan
                    dbline["VideoLink"] = db_ex[dic_ex[dbline["Exercise Name"]]][
                        "VideoLink"
                    ]
                    user_plan.append(dbline)

        except Exception as e:
            err_message = f"Error reading user plan: {e}"
            logging.error(f"read_user_plan: {err_message}")
            return False, err_message, user_plan
    return True, "", user_plan


def write_user_plan(user_id, user_plan):
    """
    write user plan to a csv

    """

    try:
        plan_csvname = FILE_DIR + "/static/images/u" + str(user_id) + "plan.csv"

        if os.path.isfile(plan_csvname):
            os.remove(plan_csvname)
            """ rename of old file for debug purposes
            datestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            old_csvname = (
                FILE_DIR
                + "/static/images/o"
                + str(user_id)
                + "_"
                + datestamp
                + "plan.csv"
            )
            os.rename(plan_csvname, old_csvname)
            """

        if len(user_plan) > 0:
            with open(plan_csvname, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=user_plan[0].keys())
                writer.writeheader()
                for row in user_plan:
                    writer.writerow(row)

    except Exception as e:
        err_message = f"Error writing user plan: {e}"
        logging.error(f"write_user_plan: {err_message}")
        return False, err_message
    return True, ""


def get_weekday_abbr(nowvalue):
    """
    get weekday
    the reason of this function is to change now's value in debugging
    """
    return nowvalue.strftime("%a")


def get_todayYMD(nowvalue):
    """
    get today's string . this procedure is needed in tests
    """
    return nowvalue.strftime("%Y-%m-%d")


def get_max_id(anylist):
    """
    get max id of any dict list, needed to index dictionary lists in memories
    """
    max_id = 0
    for iv in anylist:
        if int(iv["id"]) > max_id:
            max_id = int(iv["id"])
    return max_id


def create_todayadvice(db_user, todayplan, db_ex, dic_ex, db_mask, len_db_mask):
    """
    create todays advice
    use user soreness date db_user and todays's plan
    the algorithm must be compatible with soreness calculation one
    returns: result, err_message, advicestr, todayadvice,todayplan_ext
    """
    todayplan_ext = copy.deepcopy(todayplan)
    err_message = ""
    advicestr = ""
    todayadvice = []

    get_workdate = get_todayYMD(datetime.now())
    result, err_message, user_work = get_recorded_workouts(get_workdate)
    if not result:
        logging.error(f"create_todayadvice:get_recorded:{err_message} ")
        return False, err_message, advicestr, todayadvice, todayplan_ext

    while True:
        found = False
        if len(todayplan_ext) > 0 and len(user_work) > 0:
            for ti in range(len(todayplan_ext)):
                for ui in range(len(user_work)):
                    if (
                        todayplan_ext[ti]["Exercise Name"].strip()
                        == user_work[ui]["exercise_name"].strip()
                    ):
                        found = True
                        break
                if found:
                    del todayplan_ext[ti]
                    del user_work[ui]
                    break
        if not found:
            break

    # ATTENTION THIS LOOP'S ALGORITM MUST BE SAME WITH find_soreness
    todays_plan_sorenes = {}
    for mi in range(1, len_db_mask):
        todays_plan_sorenes[db_mask[mi]["Muscle"]] = 0
        todays_plan_sorenes[db_mask[mi]["Muscle"] + "_exercises"] = []

    # find todays total soreness of todays exercises
    for ti in range(len(todayplan_ext)):
        exercise_name = todayplan_ext[ti]["Exercise Name"]
        exercise_sets = todayplan_ext[ti]["Number of Sets"]
        # if it is 3 set then normal sorenes
        # if more than 3 than more soreness
        exercise_sorenes_weight = int(exercise_sets) / 3.0

        if not exercise_name in dic_ex:
            err_message = "Exercise not Found{exercise_name}"
            logging.critical(f"create_todayadvice:{err_message} ")
            return False, err_message, advicestr, todayadvice, todayplan_ext
        ex_id = dic_ex[exercise_name]

        # temporary control, may be deleted after tests
        if exercise_name != db_ex[ex_id]["Exercise Name"]:
            err_message = "dic_ex error id {ex_id} {exercise_name}"
            logging.critical(f"create_todayadvice:{err_message} ")
            return False, err_message, advicestr, todayadvice, todayplan_ext

        # calculate soreness of 1 exercise
        soreness_of_fulbody = 0
        if not ("FullBody" in db_ex[ex_id]):
            err_message = "Muscle FullBody not Found in exercise {exercise_name}"
            logging.critical(f"create_todayadvice:{err_message} ")
            return False, err_message, advicestr, todayadvice, todayplan_ext
        soreness_of_fulbody = int(db_ex[ex_id]["FullBody"])

        for di in range(1, len_db_mask):
            soreness_of_1muscle = 0
            if not (db_mask[di]["Muscle"] in db_ex[ex_id]):
                err_message = 'Muscle {db_mask[di]["Muscle"]} not Found in exercise {exercise_name}'
                logging.critical(f"create_todayadvice:{err_message} ")
                return False, err_message, advicestr, todayadvice, todayplan_ext
            else:
                soreness_of_1muscle = int(db_ex[ex_id][db_mask[di]["Muscle"]])
            # get soreness from full body exercise
            if soreness_of_1muscle == 0:
                soreness_of_1muscle = soreness_of_fulbody

            inc_value = soreness_of_1muscle * exercise_sorenes_weight
            # record the exercise name associated with the muscle
            if inc_value > 0:
                todays_plan_sorenes[db_mask[di]["Muscle"] + "_exercises"].append(
                    db_ex[ex_id]["Exercise Name"]
                )
            todays_plan_sorenes[db_mask[di]["Muscle"]] += inc_value

    # find todays total soreness after exercise by adding db_users
    todays_total_sorenes = {}
    for i in range(1, len_db_mask):
        todays_total_sorenes[db_mask[i]["Muscle"]] = (
            todays_plan_sorenes[db_mask[i]["Muscle"]] + db_user[db_mask[i]["Muscle"]]
        )

    # create warnings and critical advices acording to soreness level after today's exercises
    critic_ex = []
    warn_ex = []
    for di in range(1, len_db_mask):
        if todays_total_sorenes[db_mask[di]["Muscle"]] > 5:
            todayadvice.append(
                {"Subject": db_mask[di]["Muscle"], "Advice": "is overtraining"}
            )
            for exname in todays_plan_sorenes[db_mask[di]["Muscle"] + "_exercises"]:
                if not exname in critic_ex:
                    critic_ex.append(exname)
        elif todays_total_sorenes[db_mask[di]["Muscle"]] > 4:
            todayadvice.append(
                {"Subject": db_mask[di]["Muscle"], "Advice": "is under risk"}
            )
            for exname in todays_plan_sorenes[db_mask[di]["Muscle"] + "_exercises"]:
                if not exname in warn_ex:
                    warn_ex.append(exname)

    todayadvice.append({"Subject": "", "Advice": ""})
    for ti in range(len(todayplan_ext)):
        if todayplan_ext[ti]["Exercise Name"] in critic_ex:
            todayadvice.append(
                {
                    "Subject": todayplan_ext[ti]["Exercise Name"],
                    "Advice": "work light or cancel",
                }
            )

        elif todayplan_ext[ti]["Exercise Name"] in warn_ex:
            todayadvice.append(
                {
                    "Subject": todayplan_ext[ti]["Exercise Name"],
                    "Advice": "work light with caution",
                }
            )

    if len(critic_ex) > 0:
        advicestr = "Critical Advices"
    elif len(warn_ex) > 0:
        advicestr = "Warnings"

    return True, "", advicestr, todayadvice, todayplan_ext


def get_recorded_workouts(get_date):
    """
    get_recorded_workouts
    returns result,err-message,db_recorded
    """
    db_recorded = []
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        db_recorded = cur.execute(
            "SELECT * FROM exercises WHERE user_id = ? AND exercise_date = ? ",
            (
                session["user_id"],
                get_date,
            ),
        ).fetchall()
    except Exception as e:
        err_message = f"Error occurred: {e}"
        logging.error(
            f"get_recorded_workouts: {err_message} : userd_id:{session['user_id']}"
        )
        return False, err_message, db_recorded
    finally:
        cur.close()
        db.close()
    return True, "", db_recorded


def get_beforedate(get_workdate):
    """
    get 1 day before
    """
    real_date1 = datetime.strptime(get_workdate, "%Y-%m-%d")
    real_date1 = real_date1 - timedelta(days=1)
    return real_date1.strftime("%Y-%m-%d")


def get_afterdate(get_workdate):
    """
    get 1 day after
    """
    real_date1 = datetime.strptime(get_workdate, "%Y-%m-%d")
    real_date1 = real_date1 + timedelta(days=1)
    return real_date1.strftime("%Y-%m-%d")


def clear_user():
    """clear user data"""
    session.pop("user_id", None)
    session.pop("user_plan", None)
    session.pop("user_sx", None)
    session.pop("recovery_level", None)
    session.clear()


def get_user_info():
    """
    get user info from user
    """
    get_recoverylevel = request.form.get("recoverylevel")
    if not get_recoverylevel:
        err_message = "recovery level is missing"
        return False, err_message, 0, 0

    if not get_recoverylevel.isdigit():
        err_message = "Error in recovery level"
        return False, err_message, 0, 0

    get_recoverylevel = int(get_recoverylevel)
    if get_recoverylevel < 1 or get_recoverylevel > 10:
        err_message = "Error in recovery level"
        return False, err_message, 0, 0

    get_usersx = request.form.get("usersx")
    if not get_usersx:
        err_message = "body type is missing"
        return False, err_message, 0, 0

    if not get_usersx.isdigit():
        err_message = "Error in body type"
        return False, err_message, 0, 0

    get_usersx = int(get_usersx)
    if get_usersx < 0 or get_usersx > 1:
        err_message = "Error in body type"
        return False, err_message, 0, 0
    return True, "", get_usersx, get_recoverylevel
