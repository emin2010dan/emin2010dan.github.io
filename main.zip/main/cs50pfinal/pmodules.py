import csv
#import datetime
#import pytz
#import requests
#import subprocess
#import urllib
#import uuid
import re

import cv2
import numpy as np
from PIL import Image, ImageFilter

from flask import redirect, render_template, session, request
from functools import wraps
import pandas as pd
import sqlite3 as sql
import os
import logging
import random

execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))
if execution_dir == file_dir:
    INDISPATCHER = False
else:
    INDISPATCHER = True       

if INDISPATCHER:
    PREFIX="/p"
    from .pconfig import STATIC_FOLDER,DATABASE, CONTROLLIST, TYPELIST, MAX_BINS, MAX_PACESTEPS, MAX_PACE_MIN, UPLOAD_FOLDER, ALLOWED_EXTENSIONS
else:
    PREFIX=""
    from pconfig import STATIC_FOLDER,DATABASE, CONTROLLIST, TYPELIST, MAX_BINS, MAX_PACESTEPS, MAX_PACE_MIN, UPLOAD_FOLDER, ALLOWED_EXTENSIONS


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [
            ("-", "--"),
            (" ", "-"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    logging.info("p-Apology:" + message)
    return render_template("papology.html",PREFIX=PREFIX, top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.
    yenisi
    https://flask.palletsprojects.com/en/2.3.x/patterns/viewdecorators/#view-decorators

    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not ('user_id' in session):
            # if session.get("user_id") is None:
            return redirect(PREFIX+"/login")
        return f(*args, **kwargs)

    return decorated_function


def checkpassword(password):
    """check password."""
    if len(password) < 8:
        return False, "Password must be longer than 7 chars"
    elif not re.search("[a-z]", password):
        return False, "Password must contain lowercase"
    elif not re.search("[A-Z]", password):
        return False, "Password must contain uppercase"
    elif not re.search("[0-9]", password):
        return False, "Password must contain numbers"
    else:
        return True, "valid password"


def dict_factory(cursor, row):
    """ convert to dictionary """
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


def show_records(DATABASE):
    """ show loadad csv records """
    headerstr, err_message = "", ""
    df = pd.DataFrame()
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        df = pd.DataFrame.from_dict(cur.execute(
            "SELECT * FROM csvs WHERE user_id = ? ORDER BY mindate", (session["user_id"],)).fetchall())
    except Exception as e:
        err_message = f"Error occured:{e}"
        logging.error(f"p-show_recods: {err_message} userd_id{session['user_id']}" )
        return False, headerstr, err_message, df
    finally:
        cur.close()
        db.close()

    if len(df) > 0:
        mindate = df['mindate'].min()
        maxdate = df['maxdate'].max()
        record_num = df['record_num'].sum()
        headerstr = f" Number of Loaded Csv Records:{record_num}    From:{mindate}    To:{maxdate}"
        df.drop('user_id', inplace=True, axis=1)

        # for i in range(len(df)):
        #    df.loc[i, 'csv_name'] = os.path.basename(
        #        df.loc[i, 'csv_name']).split("_")[1]
        df.drop(["csv_path"], axis=1, inplace=True)

    else:
        headerstr = "No Csv Records Loaded Yet"
    return True, headerstr, err_message, df


def controlcsv(df, CONTROLLIST):
    """control csv headers"""
    seqlist = df.keys()

    for i in range(len(seqlist)):
        if seqlist[i] != CONTROLLIST[i]:
            return False
    return True


def pace_to_sec(pace_str):
    """ convert pace to sec """
    try:
        sec_m = int(pace_str.split(":")[0])
        if sec_m > MAX_PACE_MIN:
            sec_m = MAX_PACE_MIN
        sec_s = round(float(pace_str.split(":")[1]))
        if sec_s > 59:
            sec_s = 59
        sec_t = (sec_m * 60) + sec_s
        return True, sec_t, sec_m, sec_s
    except:
        return False, 0, 0, 0


def sec_to_pace(sec_int):
    """ convert sec to pace """
    try:
        sec_m = sec_int // 60
        sec_s = sec_int - (sec_m * 60)
        sec_str = str(sec_m) + ":" + '{:02d}'.format(sec_s)
        return True, sec_str
    except:
        return False, ""


def load_csvs_to_df():
    """ load all csvs to df """
    df = pd.DataFrame()
    err_message = ""
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        rows = cur.execute(
            "SELECT * FROM csvs WHERE user_id = ? ORDER BY mindate", (session["user_id"],)).fetchall()
    except Exception as e:
        err_message = f"Error occurred: {e}"
        logging.error(f"p-load_csv_to_df: {err_message} : userd_id:{session['user_id']}" )
        return False, err_message, df
    finally:
        cur.close()
        db.close()

    df = pd.DataFrame()
    for i in range(len(rows)):
        csv_name_filename = rows[i]["csv_path"]
        # Harvard,pythonanywhere,home pc have different naming formats
        # delete csvs records when final.db is transferred
        #print("===load_csv_to_df : csv name:", csv_name_filename)
        try: 
            csv_df = pd.read_csv(csv_name_filename)
            if not controlcsv(df,  CONTROLLIST):
                err_message = "Column name error in csv " + csv_name_filename
                return False, err_message, df
            df = pd.concat([df, csv_df],
                        ignore_index=True)
        except Exception as e:
            err_message = f"Error reading file: {e}"
            logging.error(f"p-load_csv_to_df2: {err_message} : csv_name_filename:{csv_name_filename}" )
            return False, err_message, df
    if len(df) == 0:
       return False, f"No data to show", df     
    return True, err_message, df


def sec_to_minsec(sec_int):
    """ convert sec to min and sec """
    try:
        sec_m = sec_int // 60
        sec_s = sec_int - (sec_m * 60)
        return True, sec_m, sec_s
    except:
        return False, 0, 0


def get_filters():
    """ get filter values"""
    try:
        dfdic = {}
        dfdic["keywords"] = 'analysis pacegraphs '
        dfdic["filter_msgs"] = []
        dfdic["filter_msgs"].append(f"Report Parameters")

        graphmenu = request.form.get("graphmenu")
        if not graphmenu:
            return False, "must provide Graph Type", dfdic, {}
        if not (graphmenu == "pace" or graphmenu == "cal" or graphmenu == "watt"):
            return False, "unknown Graph Type", dfdic, {}
        dfdic["graphmenu"] = graphmenu
        dfdic["keywords"] = dfdic["keywords"] + " " + \
            " graphmenu:" + dfdic["graphmenu"]
        dfdic["filter_msgs"].append(" Graph Menu:" + dfdic["graphmenu"])

        result, err_message, df = load_csvs_to_df()
        if not result:
            return False, err_message, dfdic, {}

        dfdic["filter_msgs"].append(f"Total Number of records:{len(df)}")

        # Included Workouts
        dfdic["typelist"] = []
        get_type = []
        for i in range(len(TYPELIST)):
            if not request.form.get(TYPELIST[i]):
                get_type.append(TYPELIST[i])
            else:
                dfdic["typelist"].append(TYPELIST[i])
                dfdic["keywords"] = dfdic["keywords"] + " " + TYPELIST[i]

        if "RowErg" in get_type:
            get_type.append("Dynamic RowErg")
            get_type.append("RowErg on Slides")

        if "On-snow" in get_type:
            get_type.append("Rollerski")

        dfdic["filter_msgs"].append("Deleted types:" + str(get_type))

        for i in get_type:
            indexdrop = df[df['Type'] == i].index
            df.drop(indexdrop, inplace=True)
        dfdic["filter_msgs"].append(
            f"After type filtering,Number of records:{len(df)}")

        # Report Type
        Report_Type = request.form.get("Report_Type")

        if not Report_Type:
            return False, "must provide Report Type", dfdic, {}
        dfdic["Report_Type"] = Report_Type
        dfdic["keywords"] = dfdic["keywords"] + \
            " " + " Report_Type:" + Report_Type
        dfdic["filter_msgs"].append("Report_Type:" + Report_Type)

        if (Report_Type == "day-report") or (Report_Type == "week-report"):
            date1 = request.form.get("date1")

            if not date1:
                return False, "must provide begining date", dfdic, {}

            dfdic["date1"] = date1

            dfdic["keywords"] = dfdic["keywords"] + " from:" + date1
            dfdic["filter_msgs"].append(f"From:{ date1 }")

            # Compare with other dates
            get3dateb = request.form.get("get3dateb")
            if get3dateb:
                date3 = request.form.get("date3")
                if date3:
                    dfdic["date3"] = date3
                    dfdic["compare_graph"] = True
                    dfdic["keywords"] = dfdic["keywords"] + \
                        " " + "compare:" + date3
                    dfdic["filter_msgs"].append(f"Compare:{ date3 }")

        if (Report_Type == "month-report") or (Report_Type == "3month-report"):
            month1 = request.form.get("month1")
            year1 = request.form.get("year1")

            if not month1:
                return False, "must provide begining month", dfdic, {}
            if not year1:
                return False, "must provide begining year", dfdic, {}

            dfdic["month1"] = month1
            dfdic["year1"] = year1
            # Compare with other months
            get3monthb = request.form.get("get3monthb")
            if get3monthb:
                month3 = request.form.get("month3")
                year3 = request.form.get("year3")
                if month3 and year3:
                    dfdic["month3"] = month3
                    dfdic["year3"] = year3
                    dfdic["compare_graph"] = True
                    dfdic["keywords"] = dfdic["keywords"] + \
                        " " + "compare:" + month3 + "/" + year3
                    dfdic["filter_msgs"].append(
                        f"Compare:{ month3 }/{ year3 }")

        # Seperate workouts from warmups
        seperate = request.form.get("seperate")
        if not seperate:
            return False, "must provide seperate info", dfdic, {}
        dfdic["seperate"] = seperate
        dfdic["keywords"] = dfdic["keywords"] + " " + " seperate:" + seperate
        dfdic["filter_msgs"].append("seperate:" + seperate)

        if seperate != "both":
            warm_pace_m = request.form.get("warm_pace_m")
            warm_pace_s = request.form.get("warm_pace_s")

            if not warm_pace_m:
                return False, "must provide pace value for warmups", dfdic, {}

            if not warm_pace_s:
                return False, "must provide pace value for warmups", dfdic, {}

            dfdic["warm_pace_m"] = warm_pace_m
            dfdic["warm_pace_s"] = warm_pace_s
            dfdic["keywords"] = dfdic["keywords"] + " " + \
                " warmup_pace:" + warm_pace_m + ":" + warm_pace_s
            dfdic["filter_msgs"].append(
                " From_pace:" + warm_pace_m + ":" + warm_pace_s)

        if dfdic["graphmenu"] == "pace":

            # Begininig Pace for Graphs
            min_pace_m = request.form.get("min_pace_m")
            min_pace_s = request.form.get("min_pace_s")
            pacestep = request.form.get("pacestep")

            if not min_pace_m:
                return False, "must provide pace value for graphs", dfdic, {}

            if not min_pace_s:
                return False, "must provide pace value for graphs", dfdic, {}

            if not pacestep:
                return False, "must provide pace steps for graphs", dfdic, {}

            dfdic["min_pace_m"] = min_pace_m
            dfdic["min_pace_s"] = min_pace_s
            dfdic["pacestep"] = pacestep
            dfdic["keywords"] = dfdic["keywords"] + " " + " From_pace:" + \
                min_pace_m + ":" + min_pace_s + " steps:" + pacestep
            dfdic["filter_msgs"].append(
                " From_pace:" + min_pace_m + ":" + min_pace_s + " steps:" + pacestep)

            # Convert Cycling Kms to Rowing Kms(Divide half)conver_cycling_kms
            conver_cycling_kms = request.form.get("conver_cycling_kms")
            if not conver_cycling_kms:
                return False, "must provide conver_cycling_kms info", dfdic, {}
            dfdic["conver_cycling_kms"] = conver_cycling_kms
            dfdic["keywords"] = dfdic["keywords"] + " " + \
                " conver_cycling_kms:" + conver_cycling_kms
            dfdic["filter_msgs"].append(
                "conver_cycling_kms:" + conver_cycling_kms)

        if dfdic["graphmenu"] == "watt":
            # Begininig watt for Graphs
            min_watt = request.form.get("min_watt")
            wattstep = request.form.get("wattstep")

            if not min_watt:
                return False, "must provide watt value for graphs", dfdic, {}

            if not wattstep:
                return False, "must provide watt steps for graphs", dfdic, {}

            dfdic["min_watt"] = min_watt
            dfdic["wattstep"] = wattstep
            dfdic["keywords"] = dfdic["keywords"] + " " + \
                " From_watt:" + min_watt + " steps:" + wattstep
            dfdic["filter_msgs"].append(
                " From watt:" + min_watt + " steps:" + wattstep)

        if dfdic["graphmenu"] == "cal":
            # Begininig cal for Graphs
            min_calhr = request.form.get("min_calhr")
            calstep = request.form.get("calstep")

            if not min_calhr:
                return False, "must provide cal/hr value for graphs", dfdic, {}

            if not calstep:
                return False, "must provide cal steps for graphs", dfdic, {}

            dfdic["min_calhr"] = min_calhr
            dfdic["calstep"] = calstep
            dfdic["keywords"] = dfdic["keywords"] + " " + \
                " From_cal:" + min_calhr + " steps:" + calstep
            dfdic["filter_msgs"].append(
                " From cal:" + min_calhr + " steps:" + calstep)

        # add necessary ones
        if "compare_graph" not in dfdic.keys():
            dfdic["compare_graph"] = False

        if "conver_cycling_kms" not in dfdic.keys():
            dfdic["conver_cycling_kms"] = "no"

        dfdic["maintitle"] = "Analysis of sport data"
        dfdic["titles"] = [" ", " ", " "]
        dfdic["author"] = 'emin2010'
        dfdic["subject"] = 'cs50 final project,analysis of sport data'

        return True, " ", dfdic, df
    except Exception as e:
        return False, f"Error getting filters{e}", {}, {}




def create_masks():
    """ createmasks for PIL """
    csv_filename = os.path.join(STATIC_FOLDER,"rgb.csv")
    mask_filename = os.path.join(STATIC_FOLDER,"coloured_mask.png")
    db = []
    dbsor = []
    dbbck = []
    try:
        body_filename = os.path.join(STATIC_FOLDER,"body.png")
        try:
            bodyimage = Image.open(body_filename)
        except Exception as e:
            err_message = f"Error getting body image: {e}"
            logging.error(f"create_masks: {err_message}" )
            return False, err_message
        bodysize = bodyimage.size
        dbsor.append(bodyimage)

        try:
            with open(csv_filename) as dbfile:
                db_reader = csv.DictReader(dbfile)
                for dbline in db_reader:
                    db.append(dbline)
        except Exception as e:
            err_message = f"Error reading csv file: {e}"
            logging.error(f"create_masks: {err_message} : csv_filename:{csv_filename}" )
            return False, err_message, db,dbsor,dbbck
        
        try:
            cmask = cv2.imread(mask_filename)
        except Exception as e:
            err_message = f"Error reading mask file: {e}"
            logging.error(f"create_masks: {err_message} : mask_filename:{mask_filename}" )
            return False, err_message, db,dbsor,dbbck
        

        for i in range(len(db)):

            lower_color = np.array( [ int(db[i]["B"]), int(db[i]["G"]), int(db[i]["R"]) ] )
            upper_color = np.array( [ int(db[i]["B"]), int(db[i]["G"]), int(db[i]["R"]) ] )

            mask2 = cv2.inRange(cmask, lower_color, upper_color)
            tmp_mask_filename = os.path.join(STATIC_FOLDER,"M_" + db[i]["Muscle"]+".png")

            cv2.imwrite(tmp_mask_filename, mask2)
            maskf = Image.open(tmp_mask_filename)
            db[i]["mask"] = maskf

        for i in range(5):

            sorr_filename = os.path.join(STATIC_FOLDER,"sore" + str(i+1) + ".png")

            try:
                sorrimage = Image.open(sorr_filename)
            except Exception as e:
                err_message = f"Error getting soreness image: {e} sorr_filename:{sorr_filename}"
                logging.error(f"create_masks: {err_message}" )
                return False, err_message
            dbsor.append(sorrimage)

            bck_filename = os.path.join(STATIC_FOLDER,"bck" + str(i+1) + ".jpg")

            try:
                background = Image.open(bck_filename).resize(bodysize)
            except Exception as e:
                err_message = f"Error getting bck image: {e}"
                logging.error(f"create_masks: {err_message}" )
                return False, err_message
            dbbck.append(background)


    except Exception as e:
        err_message = f"Error getting masks: {e}"
        logging.error(f"create_masks: {err_message}" )
        return False, err_message, db,dbsor,dbbck
    





    return True,"",db,dbsor,dbbck 


def find_soreness(db_mask):
    """ 
    returns result, err_message, db__user   
    """
    err_message = ""
    total = 0
    db_user= {}
    try:
    
        #logging.info(db_mask )
        for i in range(len(db_mask)):
            db_user[db_mask[i]["Muscle"]] = random.randint(1,5)
            total = total + (db_user[db_mask[i]["Muscle"]] * int(db_mask[i]["Percentage"]) / 100.0)                 

        soreness_level = round(total * 100.0 / 5.0)    
        if soreness_level > 80:
            err_message = "Rest Welll,Soreness Level:" + str(soreness_level) 
        elif  soreness_level > 60:
            err_message = "Rest, Soreness Level:" + str(soreness_level)  
        elif  soreness_level > 20:
            err_message = "Soreness Level:" + str(soreness_level)             
        elif  soreness_level < 10:
            err_message = "Go to Gym,Soreness Level:" + str(soreness_level)  
        
    except Exception as e:
        err_message = f"Error finding soreness: {e}"
        logging.error(f"find soreness: {err_message}" )
        return False, err_message,db_user
           
    return True,err_message,db_user

def create_bd_image(DB_MASK,DB_SOR,DB_BCK,db_user,user_imagename):
    """
    returns result, err_message  
    """
    bodyimage = DB_SOR[0]
    
    background = DB_BCK[int(db_user["Backround"]) - 1]
    
    try:



        for i in range(1,len(DB_MASK)):


            # index 0 is reserved for body
            sorrimage = DB_SOR[db_user[DB_MASK[i]["Muscle"]]]

            maskg =DB_MASK[i]["mask"]
            bodyimage.paste(sorrimage, (0,0), mask=maskg)

        
        maskg =DB_MASK[0]["mask"]
        bodyimage.paste(background, (0,0), mask=maskg)
        bodyimage= bodyimage.filter(ImageFilter.GaussianBlur(radius=1))

    except Exception as e:
        err_message = f"Error: {e}"
        logging.error(f"create_bd_image: {err_message}" )
        return False, err_message

    
    bodyimage.save(user_imagename)

    return True, ""






