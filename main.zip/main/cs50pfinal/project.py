import os
import sys
import logging
import sqlite3 as sql
from datetime import datetime

import copy
import csv


from flask import (
    Flask,
    redirect,
    render_template,
    request,
    session,
    send_from_directory,
)
from werkzeug.security import check_password_hash, generate_password_hash

# check if dispatches is active or not by checking working directory
# in dispatcher working directory is one above so change all links and imports
execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))
if execution_dir == file_dir:
    INDISPATCHER = False
else:
    INDISPATCHER = True

# if dispatcher is active modules are not in working directory so call them by .pmodules
if INDISPATCHER:
    PREFIX = "/p"
    from .pmodules import (
        get_user_info,
        clear_user,
        get_afterdate,
        get_beforedate,
        get_recorded_workouts,
        create_todayadvice,
        get_max_id,
        get_todayYMD,
        get_weekday_abbr,
        write_user_plan,
        read_user_plan,
        read_plans,
        read_exercises,
        create_bd_image,
        find_soreness,
        create_masks,
        apology,
        login_required,
        checkpassword,
        dict_factory,
    )
    from .pconfig import (
        MUSCLELIST,
        DAYSORTLIST,
        DAYLIST,
        FILE_DIR,
        DATABASE,
        UPLOAD_FOLDER,
    )
else:
    PREFIX = ""
    from pmodules import (
        get_user_info,
        clear_user,
        get_afterdate,
        get_beforedate,
        get_recorded_workouts,
        create_todayadvice,
        get_max_id,
        get_todayYMD,
        get_weekday_abbr,
        write_user_plan,
        read_user_plan,
        read_plans,
        read_exercises,
        create_bd_image,
        find_soreness,
        create_masks,
        apology,
        login_required,
        checkpassword,
        dict_factory,
    )
    from pconfig import (
        LOG_FOLDER,
        MUSCLELIST,
        DAYSORTLIST,
        DAYLIST,
        FILE_DIR,
        DATABASE,
        UPLOAD_FOLDER,
    )

    # if dispatcher is not active create your own logging file
    log_filename = os.path.join(LOG_FOLDER, "app.log")
    logging.basicConfig(
        filename=log_filename,
        filemode="a",
        format="%(asctime)s  %(name)s - %(levelname)s - %(message)s",
        encoding="utf-8",
        level=logging.INFO,
    )
logging.info(f"cs50p project: INDISPATCHER={INDISPATCHER} PREFIX={PREFIX}")


# Configure application
app = Flask(__name__)

# Configure upload file path flask
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.secret_key = 'Zr@5=6fdgfdgdfgfdvaIyyLp:%"8h.8wS/sdWKV+cfFG%&jCVAfDm*Ry'

# read, create and test necessary images  into memory
result, err_message, DB_MASK, DB_SOR, DB_BCK, DB_BODY = create_masks()
if not result:
    logging.critical(f"project : CANT CREATE MASKS{err_message}")
    sys.exit(f"project : CANT CREATE MASKS{err_message}")
else:
    logging.info(f"project : masks are created ")
LEN_DB_MASK = len(DB_MASK)

# read exercise data into memory
result, err_message, DB_EX, DIC_EX = read_exercises()
if not result:
    logging.critical(f"project : CANT READ EXERCISES{err_message}")
    sys.exit(f"project : CANT READ EXERCISES{err_message}")
else:
    logging.info(f"project : exercises are read ")

# read and check plans into memory
result, err_message, DB_PLANS = read_plans(DB_EX, DIC_EX)
if not result:
    logging.critical(f"project : CANT READ PLANS {err_message}")
    sys.exit(f"project : CANT READ PLANS {err_message}")
else:
    logging.info(f"project : plans are read ")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def pindex():
    """
    show home page
    create user's body image, and advices
    """

    result, user_message, db_user = find_soreness(DB_MASK, LEN_DB_MASK, DB_EX, DIC_EX)
    if not result:
        logging.info(f"pindex : can not find soreness {user_message}")
        return apology("could't find your soreness", 403)

    html_imagename = "/static/images/u" + str(session["user_id"]) + "image.png"
    imagename = FILE_DIR + html_imagename

    result, err_message = create_bd_image(
        DB_MASK, LEN_DB_MASK, DB_SOR, DB_BCK, DB_BODY, db_user, imagename
    )
    if not result:
        logging.info(f"pindex : can not generate image {err_message}")
        return apology("could't generate image", 403)
    today_name = get_weekday_abbr(datetime.now())

    todayplan = []
    for dayr in session["user_plan"]:
        if dayr["WeekDay"] == today_name:
            todayplan.append(dayr)


    result, err_message, advicestr, todayadvice,todayplan_ext = create_todayadvice(
        db_user, todayplan, DB_EX, DIC_EX, DB_MASK, LEN_DB_MASK
    )
    if not result:
        logging.error(f"pindex : can not create advice {err_message} ")

    get_workdate = get_todayYMD(datetime.now())
    result, err_message, user_work = get_recorded_workouts(get_workdate)
    if not result:
        logging.error(f"pindex : can not read todays workout {err_message} ")
         

    return render_template(
        "phome.html",
        PREFIX=PREFIX,
        todayadvice=todayadvice,
        advicestr=advicestr,
        headerstr=user_message,
        html_imagename=html_imagename,
        todayplan=todayplan_ext,
        user_work=user_work
    )


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    clear_user()
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        useradi = request.form.get("username")

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?", (useradi,)
            ).fetchall()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-login: {err_message} ")
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)
        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        session["user_sx"] = rows[0]["user_sx"]
        session["recovery_level"] = rows[0]["recovery_level"]

        result, err_message, user_plan = read_user_plan(
            session["user_id"], DB_EX, DIC_EX
        )
        if result:
            session["user_plan"] = user_plan
        else:
            session["user_plan"] = []

        logging.info(f"user p-login: userd_id:{session['user_id']}")

        # Redirect user to home page
        return redirect(PREFIX + "/")
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("plogin.html", PREFIX=PREFIX)


@app.route("/logout")
def logout():
    """Log user out"""
    # Forget any user_id
    logging.info(f"user p-logout: userd_id:{session['user_id']}")
    clear_user()
    # Redirect user to login form
    return redirect(PREFIX + "/")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    # Forget any user_id
    clear_user()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        # Ensure password was submitted
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)

        result, message = checkpassword(request.form.get("password"))
        if not result:
            return apology(message, 400)

        if request.form.get("confirmation") != request.form.get("password"):
            return apology("confirmatiom is not correct", 400)

        # Query database for username
        useradi = request.form.get("username")

        result, err_message, get_usersx, get_recoverylevel = get_user_info()
        if not result:
            return apology(err_message, 400)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?", (useradi,)
            ).fetchall()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-register1: {err_message} ")
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Ensure username does no exists and password is correct
        if len(rows) != 0:
            return apology("already registered", 400)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.execute(
                "INSERT INTO users(username,hash,user_sx,recovery_level) VALUES (?,?,?,?)",
                (
                    request.form.get("username"),
                    generate_password_hash(request.form.get("password")),
                    get_usersx,
                    get_recoverylevel,
                ),
            )
            iuserid = cur.lastrowid
            db.commit()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-register2: {err_message} ")
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        logging.info(f"user p-register: userd_id:{iuserid}")
        # Redirect user to home page
        return redirect(PREFIX + "/")
    else:
        return render_template("pregister.html", PREFIX=PREFIX)


@app.route("/changeprofile", methods=["GET", "POST"])
@login_required
def changeprofile():
    """change password"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        get_oldpasswd = request.form.get("oldpassword")
        get_newpasswd = request.form.get("newpassword")
        get_confirm = request.form.get("confirmation")

        change_passwd = False
        if get_oldpasswd or get_newpasswd or get_confirm:
            if not request.form.get("oldpassword"):
                return apology("must provide current password", 400)

            # Ensure new password was submitted
            elif not request.form.get("newpassword"):
                return apology("must provide new password", 400)

            # Ensure conformation  was submitted
            elif not request.form.get("confirmation"):
                return apology("must provide confirmation", 400)

            result, message = checkpassword(request.form.get("newpassword"))
            if not result:
                return apology(message, 400)

            if request.form.get("confirmation") != request.form.get("newpassword"):
                return apology("confirmatiom is not correct", 400)
            change_passwd = True

        result, err_message, get_usersx, get_recoverylevel = get_user_info()
        if not result:
            return apology(err_message, 400)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rusers = cur.execute(
                "SELECT * FROM users WHERE id = ?", (session["user_id"],)
            ).fetchall()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-changeprofile: {err_message} ")
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists
        if len(rusers) != 1:
            return apology("invalid userid", 400)

        # Ensure username exists and password is correct
        if change_passwd:
            if not check_password_hash(
                rusers[0]["hash"], request.form.get("oldpassword")
            ):
                return apology("invalid  password", 403)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            if change_passwd:
                cur.execute(
                    "UPDATE users SET hash = ?, user_sx = ?, recovery_level =?  WHERE id = ?",
                    (
                        generate_password_hash(request.form.get("newpassword")),
                        get_usersx,
                        get_recoverylevel,
                        session["user_id"],
                    ),
                )
            else:
                cur.execute(
                    "UPDATE users SET user_sx = ?, recovery_level =? WHERE id = ?",
                    (get_usersx, get_recoverylevel, session["user_id"]),
                )
            db.commit()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-changeprofile2: {err_message} ")
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        session["user_sx"] = get_usersx
        session["recovery_level"] = get_recoverylevel

        # Redirect user to home page
        return redirect(PREFIX + "/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        get_recovery_level = session["recovery_level"]
        select_male = ""
        select_female = ""
        if session["user_sx"] == 0:
            select_male = "checked"
        else:
            select_female = "checked"

        return render_template(
            "pchangeprofile.html",
            PREFIX=PREFIX,
            select_female=select_female,
            select_male=select_male,
            get_recovery_level=get_recovery_level,
        )


@app.route("/selectplan", methods=["GET", "POST"])
@login_required
def selectplan():
    """
    select a plan for user
    """
    if request.method == "POST":
        get_days = []
        for i in range(len(DAYLIST)):
            if request.form.get(DAYLIST[i]):
                get_days.append(DAYLIST[i])

        if len(get_days) == 0:
            return apology("must select working Days", 403)

        get_csv = ""
        for ci in range(1, 7):
            get_combo = request.form.get("combo-box" + str(ci))
            if get_combo:
                if not get_combo.startswith("Select One Of"):
                    get_csv = get_combo

        if get_csv == "":
            return apology("must select a workout", 403)
        planrec = []
        for plan in DB_PLANS:
            if plan["Csv File"] == get_csv:
                planrec = plan["plan"]

        if len(planrec) == 0:
            logging.error(f"selectplan: plan not found {get_csv}")
            return apology("plan not found", 403)
        headerstr = "Please Check The Workout and Accept"
        return render_template(
            "pacceptplan.html",
            PREFIX=PREFIX,
            plan_key="Day",
            planrec=planrec,
            get_csv=get_csv,
            get_days=get_days,
            headerstr=headerstr,
        )
    else:
        return render_template(
            "pselectplan.html", PREFIX=PREFIX, dbplans=DB_PLANS, daylist=DAYLIST
        )


@app.route("/acceptplan", methods=["POST"])
@login_required
def acceptplan():
    """
    check if plan is accepted or not
    """
    if request.method == "POST":
        get_days = []
        for gi in range(len(DAYLIST)):
            get_day = request.form.get("selected" + str(gi))
            if get_day:
                if get_day in DAYLIST and (not get_day in get_days):
                    get_days.append(get_day)

        if not get_days:
            return apology("must select working Days", 403)

        get_csv = request.form.get("get_csv")
        if not get_csv:
            return apology("must select a workout", 403)

        planrec = []
        for plan in DB_PLANS:
            if plan["Csv File"] == get_csv:
                planrec = plan["plan"]
                plan_how_many_days = int(plan["How Many Days"])

        if len(planrec) == 0:
            logging.error(f"selectplan: plan not found {get_csv}")
            return apology("plan not found", 403)
        if plan_how_many_days != len(get_days):
            logging.critical(
                f"accept plan:program eror:Plan num days {plan_how_many_days} is not match for selected working days {len(get_days)}  "
            )
            return apology("Plan is not match for working days", 403)

        user_planrec = copy.deepcopy(planrec)
        for ui in range(len(user_planrec)):
            # find day num
            if len(user_planrec[ui]["Day"].split()) != 2:
                logging.critical(
                    f"accept plan:program eror:Day field error no{ui} data {user_planrec[ui]['Day']}  "
                )
                logging.critical(f"accept plan:dump of user_planrec {user_planrec}  ")
                logging.critical(f"accept plan:dump of planrec {planrec}  ")
                return apology("Plan is changing,please select another", 403)
            else:
                daynum = int(user_planrec[ui]["Day"].split()[1]) - 1
                user_planrec[ui]["WeekDay"] = get_days[daynum]
                del user_planrec[ui]["Day"]
                user_planrec[ui]["id"] = ui

        result, err_message = write_user_plan(session["user_id"], user_planrec)
        if result:
            session["user_plan"] = user_planrec
        else:
            return apology("could'nt record the plan", 403)

        headerstr = "Your New Working Plan"
        return render_template(
            "pacceptedplan.html",
            PREFIX=PREFIX,
            plan_key="WeekDay",
            planrec=user_planrec,
            headerstr=headerstr,
        )


@app.route("/getplan", methods=["GET"])
@login_required
def getplan():
    """
    send user's plan csv
    don't try to send in pdf format becuse sizes of exercise data is not stable
    """
    UPLOAD_DIRECTORY = FILE_DIR + "/static/images"
    plan_csvname = "u" + str(session["user_id"]) + "plan.csv"

    totalcsvname = UPLOAD_DIRECTORY + "/" + plan_csvname

    if os.path.isfile(totalcsvname):
        return send_from_directory(UPLOAD_DIRECTORY, plan_csvname, as_attachment=True)
    else:
        return apology("could'nt found a plan", 403)


@app.route("/getworkout", methods=["GET"])
@login_required
def getworkout():
    """
    get workouts of user from db and sent to user using csv format
    """
    db_recorded = []
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        db_recorded = cur.execute(
            "SELECT * FROM exercises WHERE user_id = ?  ", (session["user_id"],)
        ).fetchall()
    except Exception as e:
        err_message = f"Error occurred when selecting: {e}"
        logging.error(f"getworkout: {err_message} : userd_id:{session['user_id']}")
        return apology(err_message, 403)
    finally:
        cur.close()
        db.close()

    if len(db_recorded) == 0:
        return apology("No recorded workout", 403)

    for di in range(len(db_recorded)):
        db_recorded[di].pop("id", None)
        db_recorded[di].pop("user_id", None)

    UPLOAD_DIRECTORY = FILE_DIR + "/static/images"
    plan_csvname = "u" + str(session["user_id"]) + "workout.csv"

    totalcsvname = UPLOAD_DIRECTORY + "/" + plan_csvname
    try:
        with open(totalcsvname, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=db_recorded[0].keys())
            writer.writeheader()
            for row in db_recorded:
                writer.writerow(row)
    except Exception as e:
        err_message = f"Error writing user workout: {e}"
        logging.error(f"getworkout: {err_message}")
        return apology(err_message, 403)

    if os.path.isfile(totalcsvname):
        return send_from_directory(UPLOAD_DIRECTORY, plan_csvname, as_attachment=True)
    else:
        return apology("could'nt found a workout", 403)


@app.route("/changeplan", methods=["GET", "POST"])
@login_required
def changeplan():
    """
    change user's plan
    """
    if request.method == "POST":
        user_plan = copy.deepcopy(session["user_plan"])

        for inum in range(len(user_plan)):
            get_id = user_plan[inum]["id"]
            get_sets = request.form.get("sets" + str(get_id))
            get_reps = request.form.get("reps" + str(get_id))
            if not get_sets or not get_reps:
                logging.error(
                    f"changeplan:could not get id {get_id} {session['user_id']} "
                )
                return apology("could not get update", 403)

            user_plan[inum]["Number of Sets"] = get_sets
            user_plan[inum]["Number of Repetitions"] = get_reps

        result, err_message = write_user_plan(session["user_id"], user_plan)
        if result:
            session["user_plan"] = user_plan
        else:
            logging.error(
                f"changeplan:could not save changed exercise{session['user_id']}"
            )
            return apology("exercise can not updated", 403)

        headerstr = "Plan is Updated,Continue to Change"
        user_plan = sorted(
            session["user_plan"], key=lambda x: DAYSORTLIST[x["WeekDay"]]
        )
        return render_template(
            "pchangeplan.html",
            PREFIX=PREFIX,
            musclelist=MUSCLELIST,
            headerstr=headerstr,
            user_plan=user_plan,
            daylist=DAYLIST,
            db_ex=DB_EX,
        )

    else:
        headerstr = "Change Your Current Plan"
        user_plan = sorted(
            session["user_plan"], key=lambda x: DAYSORTLIST[x["WeekDay"]]
        )

        return render_template(
            "pchangeplan.html",
            PREFIX=PREFIX,
            musclelist=MUSCLELIST,
            headerstr=headerstr,
            user_plan=user_plan,
            daylist=DAYLIST,
            db_ex=DB_EX,
        )


@app.route("/deleteplanrec", methods=["GET"])
@login_required
def deleteplanrec():
    """
    delete a plan's record
    """
    user_plan = copy.deepcopy(session["user_plan"])
    get_id = request.args.get("id")
    if not get_id:
        logging.error(f"deleteplanrec:could not find id of exercise")
        return apology("could not find id of exercise", 403)
    found = False
    for i in range(len(user_plan)):
        if str(user_plan[i]["id"]) == str(get_id):
            del user_plan[i]
            found = True
            break
    if found:
        result, err_message = write_user_plan(session["user_id"], user_plan)
        if result:
            session["user_plan"] = user_plan
        else:
            logging.error(
                f"deleteplanrec:could not save deleted exercise{session['user_id']}"
            )
            return apology("exercise can not deleted", 403)
    else:
        logging.error(
            f"deleteplanrec:could not find exercise{session['user_id']} id {get_id}"
        )
        return apology("exercise can not found", 403)

    headerstr = "Exercise is Deleted,Continue to Change"
    user_plan = sorted(session["user_plan"], key=lambda x: DAYSORTLIST[x["WeekDay"]])
    return render_template(
        "pchangeplan.html",
        PREFIX=PREFIX,
        musclelist=MUSCLELIST,
        headerstr=headerstr,
        user_plan=user_plan,
        daylist=DAYLIST,
        db_ex=DB_EX,
    )


@app.route("/addtoplan", methods=["POST"])
@login_required
def addtoplan():
    """
    add a record to user's plan
    """
    user_plan = copy.deepcopy(session["user_plan"])
    get_weekday = request.form.get("weekday")
    if not get_weekday in DAYLIST:
        return apology("select the day of week you want", 403)
    get_sets = request.form.get("sets")
    get_reps = request.form.get("reps")
    if not get_sets or not get_reps:
        logging.error(f"addtoplan:could not get set and reps  ")
        return apology("enter set number and repetions", 403)
    ex_id = ""
    for cb in ["Upper", "Lower", "Core"] + MUSCLELIST:
        get_combo = request.form.get("CB" + cb)
        if get_combo:
            if not get_combo.startswith("Select an Exercise"):
                ex_id = get_combo
    if ex_id == "":
        return apology("select an exercise", 403)
    found = False
    for exrec in DB_EX:
        if str(exrec["id"]) == str(ex_id):
            found = True
            new_id = get_max_id(user_plan) + 1
            user_plan.append(
                {
                    "Category": exrec["Core/Upper/Lower/Total Body"],
                    "Effected Muscles": exrec["Muscle Groups Effected"],
                    "Exercise Name": exrec["Exercise Name"],
                    "Level": exrec["Beginner/Intermediate/Advanced"],
                    "VideoLink": exrec["VideoLink"],
                    "Number of Repetitions": get_reps,
                    "Number of Sets": get_sets,
                    "WeekDay": get_weekday,
                    "id": new_id,
                }
            )
    if not found:
        logging.error(f"addtoplan:exercise not found id {ex_id} ")
        return apology("exercise not found", 403)
    user_plan = sorted(user_plan, key=lambda x: DAYSORTLIST[x["WeekDay"]])
    result, err_message = write_user_plan(session["user_id"], user_plan)
    if result:
        session["user_plan"] = user_plan
    else:
        logging.error(f"addtoplan:could not save changed exercise{session['user_id']}")
        return apology("exercise can not updated", 403)

    headerstr = "Exercise is added,Continue to Change"
    user_plan = sorted(session["user_plan"], key=lambda x: DAYSORTLIST[x["WeekDay"]])
    return render_template(
        "pchangeplan.html",
        PREFIX=PREFIX,
        musclelist=MUSCLELIST,
        headerstr=headerstr,
        user_plan=user_plan,
        daylist=DAYLIST,
        db_ex=DB_EX,
    )


@app.route("/recordworkout", methods=["GET", "POST"])
@login_required
def recordworkout():
    """
    record the workout to db
    """
    if request.method == "POST":
        get_workdate = request.form.get("workdate")
        if not get_workdate:
            return apology("enter the day of workout", 403)

        get_weekdaycombo = request.form.get("weekdaycombo")
        if not get_weekdaycombo:
            return apology("enter the day name of workout that you done", 403)

        record_plan = copy.deepcopy(session["user_plan"])
        count_ex = 0
        for inum in range(len(record_plan)):
            record_plan[inum]["Checked"] = False
            get_id = record_plan[inum]["id"]
            get_check = request.form.get("check" + str(get_id))
            if get_check:
                get_sets = request.form.get("sets" + str(get_id))
                get_reps = request.form.get("reps" + str(get_id))
                get_intens = request.form.get("intens" + str(get_id))
                if not get_sets or not get_reps:
                    continue
                record_plan[inum]["Checked"] = True
                record_plan[inum]["Number of Sets"] = get_sets
                record_plan[inum]["Number of Repetitions"] = get_reps
                record_plan[inum]["Intensity"] = get_intens
                count_ex += 1

        if count_ex == 0:
            return apology("No exercise is checked,nothing to record", 403)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            for inum in range(len(record_plan)):
                if record_plan[inum]["Checked"]:
                    cur.execute(
                        "INSERT INTO exercises(user_id,exercise_date,exercise_name,number_of_sets,number_of_repetitions,intensity_level) VALUES (?,?,?,?,?,?)",
                        (
                            session["user_id"],
                            get_workdate,
                            record_plan[inum]["Exercise Name"],
                            record_plan[inum]["Number of Sets"],
                            record_plan[inum]["Number of Repetitions"],
                            record_plan[inum]["Intensity"],
                        ),
                    )
                    # for future use
                    record_plan[inum]["rowid"] = cur.lastrowid
            db.commit()
        except Exception as e:
            err_message = f"Record Error: {e}"
            logging.error(f"recordworkout: {err_message} ")
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        headerstr = f"Recorded Exercises For {get_workdate}"
        return render_template(
            "precorded.html", PREFIX=PREFIX, planrec=record_plan, headerstr=headerstr
        )

    else:
        today_name = get_weekday_abbr(datetime.now())
        workdic = {}
        today_found = False
        for dayr in session["user_plan"]:
            if dayr["WeekDay"] == today_name:
                today_found = True
                if not ("Today" in workdic):
                    workdic["Today"] = []
                workdic["Today"].append(dayr)
            else:
                if not dayr["WeekDay"] in workdic:
                    workdic[dayr["WeekDay"]] = []
                workdic[dayr["WeekDay"]].append(dayr)

        todaydate = get_todayYMD(datetime.now())

        return render_template(
            "precordworkout.html",
            PREFIX=PREFIX,
            todaydate=todaydate,
            workdic=workdic,
            today_found=today_found,
        )


@app.route("/changeworkout", methods=["GET", "POST"])
@login_required
def changeworkout():
    """
    change workout in db
    """
    if request.method == "POST":
        get_workdate = request.form.get("workdate")
        if not get_workdate:
            get_workdate = get_todayYMD(datetime.now())

    else:
        get_date = request.args.get("date")
        if get_date:
            get_workdate = get_date
        else:
            get_workdate = get_todayYMD(datetime.now())

    result, err_message, user_work = get_recorded_workouts(get_workdate)
    if not result:
        return apology(err_message, 403)
    beforedate = get_beforedate(get_workdate)
    afterdate = get_afterdate(get_workdate)

    headerstr = f"Recorded Exercises For {get_workdate}"
    return render_template(
        "pchangeworkout.html",
        PREFIX=PREFIX,
        afterdate=afterdate,
        beforedate=beforedate,
        get_workdate=get_workdate,
        user_work=user_work,
        headerstr=headerstr,
    )


@app.route("/deleteworkout", methods=["GET"])
@login_required
def deleteworkout():
    """
    delete workout record in db
    """
    get_id = request.args.get("id")

    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.row_factory = dict_factory
        db_recorded = cur.execute(
            "SELECT * FROM exercises WHERE  id = ? ",
            (get_id,),
        ).fetchall()
    except Exception as e:
        err_message = f"Error occurred: {e}"
        logging.error(
            f"deleteworkout: {err_message} : userd_id:{session['user_id']}  id:{get_id} "
        )
        return apology(err_message, 403)
    finally:
        cur.close()
        db.close()

    if len(db_recorded) == 0:
        return apology("No record found to delete", 403)

    if db_recorded[0]["user_id"] != session["user_id"]:
        return apology("this workout is not belong to you", 403)

    get_workdate = db_recorded[0]["exercise_date"]
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()
        cur.execute("DELETE  FROM exercises WHERE id = ? ", (get_id,))
        db.commit()
    except Exception as e:
        err_message = f"Error occurred: {e}"
        logging.error(
            f"deleteworkout: {err_message} userd_id:{session['user_id']} id:{get_id}"
        )
        return apology(err_message, 403)
    finally:
        cur.close()
        db.close()

    result, err_message, user_work = get_recorded_workouts(get_workdate)
    if not result:
        return apology(err_message, 403)
    beforedate = get_beforedate(get_workdate)
    afterdate = get_afterdate(get_workdate)

    headerstr = f"Exercise Deleted,Recorded Exercises For {get_workdate}"
    return render_template(
        "pchangeworkout.html",
        PREFIX=PREFIX,
        afterdate=afterdate,
        beforedate=beforedate,
        get_workdate=get_workdate,
        user_work=user_work,
        headerstr=headerstr,
    )


@app.route("/checklevel", methods=["GET"])
@login_required
def checklevel():
    """
    check fitness level of user
    """

    return render_template(
        "pchecklevel.html",
        PREFIX=PREFIX,
    )


def calculate_level(
    get_num, get_age, table, age_table, user_sx, message1, message2, message3
):
    """
    calculate fitnes levels
    """
    found = False
    for ai in range(len(age_table)):
        if len(age_table[ai].split("-")) == 2:
            minage = int(age_table[ai].split("-")[0])
            maxage = int(age_table[ai].split("-")[1])
        else:
            minage = int(age_table[ai])
            maxage = 110

        if minage <= get_age <= maxage:
            found = True
            break
    if not found:
        return "Your age is out of table limits"

    found = False
    for line in table:
        if len(line[ai + 2].split("-")) == 2:
            minhr = int(line[ai + 2].split("-")[0])
            maxhr = int(line[ai + 2].split("-")[1])
        else:
            minhr = int(line[ai + 2])
            maxhr = 9999
        if line[0] == user_sx and minhr <= get_num <= maxhr:
            return f"{message1} {line[1]} {message2}"
    # message3 is the type of data in get_num
    return f"Your {message3} is out of table limits"


def calculate_level_by_rhr(user_sx, get_rest_hr, get_age):
    """
    calculate fitness level by resting heard rate
    depends on:
    https://www.sundried.com/blogs/training/heart-rate-recovery-and-fitness-levels
    returns str
    """
    age_table = ["18-25", "26-35", "36-45", "46-55", "56-65", "66-95"]

    table = [
        [0, "ATHLETE", "49-55", "49-54", "50-56", "50-57", "51-56", "50-55"],
        [0, "EXCEL'T", "56-61", "55-61", "57-62", "58-63", "57-61", "56-61"],
        [0, "GOOD", "62-65", "62-65", "63-66", "64-67", "62-67", "62-65"],
        [0, "ABOVE AV", "66-69", "66-70", "67-70", "68-71", "68-71", "66-69"],
        [0, "AVERAGE", "70-73", "71-74", "71-75", "72-76", "72-75", "70-73"],
        [0, "BELOW AV", "74-81", "75-81", "76-82", "77-83", "76-81", "74-79"],
        [0, "POOR", "82", "82", "83", "84", "82", "80"],
        [1, "ATHLETE", "54-60", "54-59", "54-59", "54-60", "54-59", "54-59"],
        [1, "EXCEL'T", "61-65", "60-64", "60-64", "61-65", "60-64", "60-64"],
        [1, "GOOD", "66-69", "65-68", "65-69", "66-69", "65-68", "65-68"],
        [1, "ABOVE AV", "70-73", "69-72", "70-73", "70-73", "69-73", "69-72"],
        [1, "AVERAGE", "74-78", "73-76", "74-78", "74-77", "74-77", "73-76"],
        [1, "BELOW AV", "79-84", "77-82", "79-84", "78-83", "78-83", "77-84"],
        [1, "POOR", "85", "83", "85", "84", "84", "84"],
    ]
    return calculate_level(
        get_rest_hr,
        get_age,
        table,
        age_table,
        user_sx,
        "Your Heart Fitness level is",
        "acording to sundried.com",
        "resting hr",
    )


@app.route("/findlevel_by_rhr", methods=["POST"])
@login_required
def findlevel_by_rhr():
    """
    find heart fitnes level by resting heart rate
    """
    try:
        get_rest_hr = int(request.form.get("form1_rest_hr"))
        if not get_rest_hr:
            return apology("please enter Resting Heard Rate ", 403)

        get_age = int(request.form.get("form1_age"))
        if not get_age:
            return apology("please enter age ", 403)
        result = calculate_level_by_rhr(session["user_sx"], get_rest_hr, get_age)
    except Exception as e:
        return apology(f"Error calculating level: {e}", 403)

    return render_template("pchecklevel.html", PREFIX=PREFIX, form1_headerstr=result)


def calculate_level_by_pushup(user_sx, get_pushup, get_age):
    """
    calculate fitness level by pushup numbers
    depend on:
    https://www.topendsports.com/testing/tests/home-pushup.htm
    returns str
    """
    age_table = ["17-19", "20-29", "30-39", "40-49", "50-59", "60-65"]

    table = [
        [0, "Excellent", "57", "48", "42", "35", "32", "31"],
        [0, "Good", "47-56", "39-47", "34-41", "28-34", "25-31", "24-30"],
        [0, "Above average", "35-46", "30-38", "25-33", "21-27", "18-24", "17-23"],
        [0, "Average", "19-34", "17-29", "13-24", "11-20", "9-17", "6-16"],
        [0, "Below average", "11-18", "10-16", "8-12", "6-10", "5-8", "3-5"],
        [0, "Poor", "4-10", "4-9", "2-7", "1-5", "1-4", "1-2"],
        [0, "Very Poor", "0-3", "0-3", "0-1", "0-0", "0-0", "0-0"],
        [1, "Excellent", "31", "33", "29", "21", "17", "13"],
        [1, "Good", "22-30", "24-32", "21-28", "15-20", "13-16", "10-12"],
        [1, "Above Average", "11-21", "14-23", "13-20", "10-14", "9-12", "6-9"],
        [1, "Average", "7-10", "9-13", "7-12", "5-9", "4-8", "3-5"],
        [1, "Below average", "4-6", "5-8", "3-6", "2-4", "2-3", "2-2"],
        [1, "Poor", "1-3", "1-4", "1-2", "1-1", "1-1", "1-1"],
        [1, "Very Poor", "0-0", "0-0", "0-0", "0-0", "0-0", "0-0"],
    ]
    return calculate_level(
        get_pushup,
        get_age,
        table,
        age_table,
        user_sx,
        "Your Chest Muscles Fitness level are",
        "acording to topendsports.com",
        "pushup number",
    )


@app.route("/findlevel_by_pushup", methods=["POST"])
@login_required
def findlevel_by_pushup():
    """
    find chest muscless fitnes level by pushup numbers
    """
    try:
        get_pushup = int(request.form.get("form2_pushup"))
        if not get_pushup:
            return apology("please enter Pushup numbers ", 403)

        get_age = int(request.form.get("form2_age"))
        if not get_age:
            return apology("please enter age ", 403)
        result = calculate_level_by_pushup(session["user_sx"], get_pushup, get_age)
    except Exception as e:
        return apology(f"Error calculating level: {e}", 403)

    return render_template("pchecklevel.html", PREFIX=PREFIX, form2_headerstr=result)


def calculate_level_by_situp(user_sx, get_situp, get_age):
    """
    calculate fitness level by situp numbers
    depend on:
    https://www.topendsports.com/testing/tests/home-situp.htm
    returns str
    """
    age_table = ["18-25", "26-35", "36-45", "46-55", "56-65", "66"]

    table = [
        [0, "Excellent", "50", "46", "42", "36", "32", "29"],
        [0, "Good", "44-49", "40-45", "35-41", "29-35", "25-31", "22-28"],
        [0, "Above average", "39-43", "35-39", "30-34", "25-28", "21-24", "19-21"],
        [0, "Average", "35-38", "31-34", "27-29", "22-24", "17-20", "15-18"],
        [0, "Below Average", "31-34", "29-30", "23-26", "18-21", "13-16", "11-14"],
        [0, "Poor", "25-30", "22-28", "17-22", "13-17", "9-12", "7-10"],
        [0, "Very Poor", "0-24", "0-21", "0-16", "0-12", "0-8", "0-6"],
        [1, "Excellent", "44", "40", "34", "28", "25", "24"],
        [1, "Good", "37-43", "33-39", "27-33", "22-27", "18-24", "17-23"],
        [1, "Above average", "33-36", "29-32", "23-26", "18-21", "13-17", "14-16"],
        [1, "Average", "29-32", "25-28", "19-22", "14-17", "10-12", "11-13"],
        [1, "Below Average", "25-28", "21-24", "15-18", "10-13", "7-9", "5-10"],
        [1, "Poor", "18-24", "13-20", "7-14", "5-9", "3-6", "2-4"],
        [1, "Very Poor", "0-17", "0-12", "0-6", "0-4", "0-2", "0-1"],
    ]
    return calculate_level(
        get_situp,
        get_age,
        table,
        age_table,
        user_sx,
        "Your Core Muscles Fitness level are",
        "acording to topendsports.com",
        "situp number",
    )


@app.route("/findlevel_by_situp", methods=["POST"])
@login_required
def findlevel_by_situp():
    """
    find core muscless fitness level by situp numbers in 1 min
    """
    try:
        get_situp = int(request.form.get("form3_situp"))
        if not get_situp:
            return apology("please enter Situp numbers ", 403)

        get_age = int(request.form.get("form3_age"))
        if not get_age:
            return apology("please enter age ", 403)
        result = calculate_level_by_situp(session["user_sx"], get_situp, get_age)
    except Exception as e:
        return apology(f"Error calculating level: {e}", 403)

    return render_template("pchecklevel.html", PREFIX=PREFIX, form3_headerstr=result)


def calculate_level_by_squat(user_sx, get_squat, get_age):
    """
    calculate fitness level by squat numbers
    depend on:
    https://www.topendsports.com/testing/tests/home-squat.htm
    returns str
    """
    age_table = ["20-29", "30-39", "40-49", "50-59", "60"]

    table = [
        [0, "Excellent", "35", "33", "30", "27", "24"],
        [0, "Good", "33-34", "30-32", "27-29", "24-26", "21-23"],
        [0, "Above average", "30-32", "27-29", "24-26", "21-23", "18-20"],
        [0, "Average", "27-29", "24-26", "21-23", "18-20", "15-17"],
        [0, "Below Average", "24-26", "21-23", "18-20", "15-17", "12-14"],
        [0, "Poor", "21-23", "18-20", "15-17", "12-14", "9-11"],
        [0, "Very Poor", "0-20", "0-17", "0-14", "0-11", "0-8"],
        [1, "Excellent", "30", "27", "24", "21", "18"],
        [1, "Good", "27-29", "24-26", "21-23", "18-20", "15-17"],
        [1, "Above average", "24-26", "21-23", "18-20", "15-17", "12-14"],
        [1, "Average", "21-23", "18-20", "15-17", "12-14", "9-11"],
        [1, "Below Average", "18-20", "15-17", "12-14", "9-11", "6-8"],
        [1, "Poor", "15-17", "12-14", "9-11", "6-8", "3-5"],
        [1, "Very Poor", "0-14", "0-11", "0-8", "0-5", "0-2"],
    ]
    return calculate_level(
        get_squat,
        get_age,
        table,
        age_table,
        user_sx,
        "Your Leg Muscles Fitness level are",
        "acording to topendsports.com",
        "squat number",
    )


@app.route("/findlevel_by_squat", methods=["POST"])
@login_required
def findlevel_by_squat():
    """
    find leg muscless fitness level by squat numbers
    """
    try:
        get_squat = int(request.form.get("form4_squat"))
        if not get_squat:
            return apology("please enter squat numbers ", 403)

        get_age = int(request.form.get("form4_age"))
        if not get_age:
            return apology("please enter age ", 403)
        result = calculate_level_by_squat(session["user_sx"], get_squat, get_age)
    except Exception as e:
        return apology(f"Error calculating level: {e}", 403)

    return render_template("pchecklevel.html", PREFIX=PREFIX, form4_headerstr=result)


if __name__ == "__main__":
    app.run(debug=True)
