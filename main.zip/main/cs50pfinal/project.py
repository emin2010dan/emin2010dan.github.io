import os
import sys
import logging
import sqlite3 as sql
from datetime import datetime
import copy

from flask import Flask,  redirect, render_template, request, session,send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash

execution_dir = os.getcwd()
file_dir = os.path.dirname(os.path.realpath(__file__))
if execution_dir == file_dir:
    INDISPATCHER = False
else:
    INDISPATCHER = True       

if INDISPATCHER:
    PREFIX="/p"
    from .pmodules import  create_todayadvice,get_max_id,get_weekday_abbr,write_user_plan,read_user_plan,read_plans,read_exercises,create_bd_image,find_soreness,create_masks,apology, login_required, checkpassword, dict_factory
    from .pconfig import MUSCLELIST,DAYSORTLIST,DAYLIST,FILE_DIR, DATABASE,  UPLOAD_FOLDER
else:
    PREFIX=""
    from pmodules import  create_todayadvice,get_max_id,get_weekday_abbr,write_user_plan,read_user_plan,read_plans,read_exercises,create_bd_image,find_soreness,create_masks, apology, login_required, checkpassword, dict_factory
    from pconfig import LOG_FOLDER,MUSCLELIST,DAYSORTLIST,DAYLIST,FILE_DIR, DATABASE,UPLOAD_FOLDER
    log_filename = os.path.join(LOG_FOLDER,"app.log")
    logging.basicConfig(filename=log_filename, filemode='a', format='%(asctime)s  %(name)s - %(levelname)s - %(message)s',  encoding='utf-8', level=logging.INFO)
logging.info(f"cs50p project: INDISPATCHER={INDISPATCHER} PREFIX={PREFIX}")








# Configure application
app = Flask(__name__)

# Configure upload file path flask
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = 'Zr@5=6fdgfdgdfgfdvaIyyLp:%"8h.8wS/sdWKV+cfFG%&jCVAfDm*Ry'

result, err_message, DB_MASK,DB_SOR,DB_BCK,DB_BODY = create_masks()
if not result:
    logging.critical(f"project : CANT CREATE MASKS{err_message}")
    sys.exit(f"project : CANT CREATE MASKS{err_message}")
else:
    logging.info(f"project : masks are created ")

result, err_message, DB_EX = read_exercises()
if not result:
    logging.critical(f"project : CANT READ EXERCISES{err_message}")
    sys.exit(f"project : CANT READ EXERCISES{err_message}")
else:
    logging.info(f"project : exercises are read ")   


result, err_message, DB_PLANS = read_plans()
if not result:
    logging.critical(f"project : CANT READ PLANS {err_message}")
    sys.exit(f"project : CANT READ PLANS {err_message}")
else:
    logging.info(f"project : plans are read ")  

@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def pindex():
    """ show home page """

    result, user_message, db_user = find_soreness(DB_MASK)
    if not result:
        logging.info(f"pindex : can not find soreness {user_message}")
        return apology("could't find your soreness", 403)
    
    html_imagename = "/static/images/u" + str(session["user_id"]) + "image.png"
    imagename = FILE_DIR + html_imagename

    result, err_message= create_bd_image(DB_MASK,DB_SOR,DB_BCK,DB_BODY,db_user,imagename)
    if not result:
        logging.info(f"pindex : can not generate image {err_message}")
        return apology("could't generate image", 403)
    today_name = get_weekday_abbr(datetime.now())
    todayplan=[]
    for dayr in session["user_plan"]:
        if dayr["WeekDay"] == today_name:
            todayplan.append(dayr)

    result, err_message, advicestr, todayadvice = create_todayadvice(db_user,todayplan,DB_EX,DB_MASK)
    if not result:
        logging.info(f"pindex : can not create advice {err_message} ")


    return render_template("phome.html",PREFIX=PREFIX,todayadvice=todayadvice,advicestr=advicestr,headerstr=user_message,html_imagename=html_imagename,todayplan=todayplan)
  
@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    session.pop('user_id', None)
    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        useradi = request.form.get("username")

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?",
                (useradi,)).fetchall()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-login: {err_message} " )
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)
        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        result,err_message,user_plan = read_user_plan(session["user_id"])
        if result :
           session["user_plan"] = user_plan
        else:
           session["user_plan"] = []

        logging.info(f"user p-login: userd_id:{session['user_id']}" )

        # Redirect user to home page
        return redirect(PREFIX+"/")
    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("plogin.html", PREFIX=PREFIX)


@app.route("/logout")
def logout():
    """Log user out"""
    # Forget any user_id
    logging.info(f"user p-logout: userd_id:{session['user_id']}" )
    session.pop('user_id', None)
    # Redirect user to login form
    return redirect(PREFIX+"/")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    # Forget any user_id
    # session.clear()
    session.pop('user_id', None)

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        # Ensure password was submitted
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)

        result, message = checkpassword(request.form.get("password"))
        if not result:
            return apology(message, 400)

        if request.form.get("confirmation") != request.form.get("password"):
            return apology("confirmatiom is not correct", 400)

        # Query database for username
        useradi = request.form.get("username")

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rows = cur.execute(
                "SELECT * FROM users WHERE username = ?",
                (useradi,)).fetchall()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-register1: {err_message} " )
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Ensure username does no exists and password is correct
        if len(rows) != 0:
            return apology("already registered", 400)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.execute(
                "INSERT INTO users(username,hash) VALUES (?,?)",
                (request.form.get("username"),
                 generate_password_hash(request.form.get("password"))))
            iuserid = cur.lastrowid
            db.commit()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-register2: {err_message} " )
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Remember which user has logged in
        session["user_id"] = iuserid
        logging.info(f"user p-register: userd_id:{session['user_id']}" )
        # Redirect user to home page
        return redirect(PREFIX+"/")
    else:
        return render_template("pregister.html", PREFIX=PREFIX)


@app.route("/changepassword", methods=["GET", "POST"])
@login_required
def changepassword():
    """change password"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        if not request.form.get("oldpassword"):
            return apology("must provide current password", 400)

        # Ensure new password was submitted
        elif not request.form.get("newpassword"):
            return apology("must provide new password", 400)

        # Ensure conformation  was submitted
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)

        result, message = checkpassword(request.form.get("newpassword"))
        if not result:
            return apology(message, 400)

        if request.form.get("confirmation") != request.form.get("newpassword"):
            return apology("confirmatiom is not correct", 400)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.row_factory = dict_factory
            rusers = cur.execute(
                "SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchall()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-changepassword: {err_message} " )
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Ensure username exists
        if len(rusers) != 1:
            return apology("invalid userid", 400)

        # Ensure username exists and password is correct
        if not check_password_hash(rusers[0]["hash"], request.form.get("oldpassword")):
            return apology("invalid  password", 403)

        try:
            db = sql.connect(DATABASE)
            cur = db.cursor()
            cur.execute("UPDATE users SET hash = ? WHERE id = ?",
                        (generate_password_hash(request.form.get("newpassword")), session["user_id"]))
            db.commit()
        except Exception as e:
            err_message = f"Error occurred: {e}"
            logging.error(f"p-changepassword2: {err_message} " )
            return apology(err_message, 403)
        finally:
            cur.close()
            db.close()

        # Redirect user to home page
        return redirect(PREFIX+"/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("pchangepassword.html", PREFIX=PREFIX)


@app.route("/selectplan", methods=["GET", "POST"])
@login_required
def selectplan():
    if request.method == "POST":
        get_days = []
        for i in range(len(DAYLIST)):
            if request.form.get(DAYLIST[i]):
                get_days.append(DAYLIST[i])

        if len(get_days) == 0:
            return apology("must select working Days", 403)

        get_csv = ""
        for ci in range(1,7):
            get_combo=request.form.get("combo-box"+str(ci))
            if get_combo:
                if not get_combo.startswith("Select One Of"):
                    get_csv = get_combo
       
        if get_csv == "":
            return apology("must select a workout", 403)
        planrec=[]
        for plan in DB_PLANS:
            if plan["Csv File"] == get_csv:
                planrec= plan["plan"]
               
        if len(planrec) == 0:
            logging.error(f"selectplan: plan not found {get_csv}")
            return apology("plan not found", 403) 
        headerstr = "Please Check The Workout and Accept"
        return render_template("pacceptplan.html", PREFIX=PREFIX,plan_key="Day",planrec=planrec,get_csv=get_csv,get_days=get_days,headerstr=headerstr )
    else:
        
        return render_template("pselectplan.html", PREFIX=PREFIX,dbplans=DB_PLANS,daylist=DAYLIST)


@app.route("/acceptplan", methods=["POST"])
@login_required
def acceptplan():
    if request.method == "POST":
        get_days = []
        for gi in range(len(DAYLIST)):
          get_day = request.form.get("selected"+ str(gi))
          if get_day:
            if get_day in DAYLIST and (not get_day in get_days) :
                get_days.append(get_day)

        if not get_days:
            return apology("must select working Days", 403)
   
        get_csv = request.form.get("get_csv")
        if not get_csv:
            return apology("must select a workout", 403)
        
        planrec=[]
        for plan in DB_PLANS:
            if plan["Csv File"] == get_csv:
                planrec= plan["plan"]
                plan_how_many_days = int(plan["How Many Days"])
                       
        if len(planrec) == 0:
            logging.error(f"selectplan: plan not found {get_csv}")
            return apology("plan not found", 403) 
        if plan_how_many_days != len(get_days):
            logging.critical(f"accept plan:program eror:Plan num days {plan_how_many_days} is not match for selected working days {len(get_days)}  ")
            return apology("Plan is not match for working days", 403) 

        user_planrec =copy.deepcopy(planrec) 
        for ui in range(len(user_planrec)):
            #find day num
            if len(user_planrec[ui]["Day"].split()) != 2:
                logging.critical(f"accept plan:program eror:Day field error no{ui} data {user_planrec[ui]['Day']}  ")
                logging.critical(f"accept plan:dump of user_planrec {user_planrec}  ")
                logging.critical(f"accept plan:dump of planrec {planrec}  ")
                return apology("Plan is changing,please select another", 403) 
            else: 
                daynum = int(user_planrec[ui]["Day"].split()[1]) -1
                user_planrec[ui]["WeekDay"] = get_days[daynum]
                del user_planrec[ui]["Day"]
                user_planrec[ui]["id"] = ui
      

        
        result,err_message = write_user_plan(session["user_id"],user_planrec)
        if result :
           session["user_plan"] = user_planrec
        else:
           return apology("could'nt record the plan", 403)  

        headerstr = "Your New Working Plan"
        return render_template("pacceptedplan.html", PREFIX=PREFIX,plan_key="WeekDay",planrec=user_planrec,headerstr=headerstr )

  
@app.route("/getplan", methods=["GET"])
@login_required
def getplan():
    UPLOAD_DIRECTORY = FILE_DIR + "/static/images"
    plan_csvname = "u" + str(session["user_id"]) + "plan.csv"
    totalname = UPLOAD_DIRECTORY + "/" + plan_csvname
    if os.path.isfile(totalname):
        return send_from_directory(UPLOAD_DIRECTORY, plan_csvname, as_attachment=True) 
    else:
        return apology("could'nt found a plan", 403) 


@app.route("/changeplan", methods=["GET", "POST"])
@login_required
def changeplan():
    if request.method == "POST":
        user_plan =copy.deepcopy(session["user_plan"]) 
        for inum in range(len(user_plan)):
            get_sets = request.form.get("sets"+str(inum))
            get_reps = request.form.get("reps"+str(inum))
            if not get_sets or not get_reps:
               logging.error(f"changeplan:could not get id {inum} {session['user_id']} ")
               return apology("could not get update", 403) 
            user_plan[inum]["Number of Sets"] = get_sets 
            user_plan[inum]["Number of Repetitions"] = get_reps

        result,err_message = write_user_plan(session["user_id"],user_plan)
        if result : 
            session["user_plan"] = user_plan
        else:
            logging.error(f"changeplan:could not save changed exercise{session['user_id']}")
            return apology("exercise can not updated", 403)

        headerstr="Plan is Updated,Continue to Change"
        user_plan = sorted(session["user_plan"], key=lambda x: DAYSORTLIST[x['WeekDay']])
        return render_template("pchangeplan.html", PREFIX=PREFIX,musclelist=MUSCLELIST,headerstr=headerstr,user_plan=user_plan,daylist=DAYLIST,db_ex=DB_EX)

    else:
        headerstr="Change Your Current Plan"
        user_plan = sorted(session["user_plan"], key=lambda x: DAYSORTLIST[x['WeekDay']])
        #print("--changeplan get --------",user_plan)
        return render_template("pchangeplan.html", PREFIX=PREFIX,musclelist=MUSCLELIST,headerstr=headerstr,user_plan=user_plan,daylist=DAYLIST,db_ex=DB_EX)



@app.route("/deleteplanrec", methods=["GET"])
@login_required
def deleteplanrec():
        user_plan =copy.deepcopy(session["user_plan"]) 
        get_id = request.args.get("id")
        if not get_id:
            logging.error(f"deleteplanrec:could not find id of exercise")
            return apology("could not find id of exercise", 403)
        found=False
        for i in range(len(user_plan)):
            if str(user_plan[i]["id"]) == str(get_id):
                del user_plan[i]
                found=True
                break
        if found:
            result,err_message = write_user_plan(session["user_id"],user_plan)
            if result : 
                session["user_plan"] = user_plan
            else:
                logging.error(f"deleteplanrec:could not save deleted exercise{session['user_id']}")
                return apology("exercise can not deleted", 403)
        else:
            logging.error(f"deleteplanrec:could not find exercise{session['user_id']} id {get_id}")
            return apology("exercise can not found", 403)                 
            
        headerstr="Exercise is Deleted,Continue to Change"
        user_plan = sorted(session["user_plan"], key=lambda x: DAYSORTLIST[x['WeekDay']])
        return render_template("pchangeplan.html", PREFIX=PREFIX,musclelist=MUSCLELIST,headerstr=headerstr,user_plan=user_plan,daylist=DAYLIST,db_ex=DB_EX)


@app.route("/addtoplan", methods=[ "POST"])
@login_required
def addtoplan():
    user_plan =copy.deepcopy(session["user_plan"]) 
    get_weekday = request.form.get("weekday")
    if not get_weekday in DAYLIST:
        return apology("select the day of week you want", 403)
    get_sets = request.form.get("sets")
    get_reps = request.form.get("reps")
    if not get_sets or not get_reps:
        logging.error(f"addtoplan:could not get set and reps  ")
        return apology("enter set number and repetions", 403) 
    ex_id = ""
    for cb in ["Upper","Lower","Core"] + MUSCLELIST:
            get_combo=request.form.get("CB"+cb)
            if get_combo:
                if not get_combo.startswith("Select an Exercise"):
                    ex_id = get_combo
    if ex_id == "":
        return apology("select an exercise", 403) 
    found=False                
    for exrec in DB_EX:
        if str(exrec["id"]) == str(ex_id):
            found = True
            new_id = get_max_id(user_plan) + 1
            user_plan.append({"Category": exrec["Core/Upper/Lower/Total Body"],
                              "Effected Muscles": exrec["Muscle Groups Effected"],
                              "Exercise Name": exrec["Exercise Name"],
                              "Level": exrec["Beginner/Intermediate/Advanced"],
                              "Number of Repetitions": get_reps,
                              "Number of Sets": get_sets,
                              "WeekDay": get_weekday,
                              "id": new_id})
    if not found:
        logging.error(f"addtoplan:exercise not found id {ex_id} " )
        return apology("exercise not found", 403)         
    user_plan = sorted(user_plan, key=lambda x: DAYSORTLIST[x['WeekDay']])
    result,err_message = write_user_plan(session["user_id"],user_plan)
    if result : 
        session["user_plan"] = user_plan
    else:
        logging.error(f"addtoplan:could not save changed exercise{session['user_id']}")
        return apology("exercise can not updated", 403)

    headerstr="Exersise is added,Continue to Change"
    user_plan = sorted(session["user_plan"], key=lambda x: DAYSORTLIST[x['WeekDay']])
    return render_template("pchangeplan.html", PREFIX=PREFIX,musclelist=MUSCLELIST,headerstr=headerstr,user_plan=user_plan,daylist=DAYLIST,db_ex=DB_EX)




if __name__ == '__main__':
    app.run(debug=True)
