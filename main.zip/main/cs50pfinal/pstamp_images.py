# change image dimension
"""
 Administration tool
  stamp images by mini soreness indicator images 
"""

from PIL import Image
import numpy as np

names = [
    "body0",
    "coloured_mask0",
    "body1",
    "coloured_mask1",
]

for name in names:
    # screen size

    body = Image.open("./static/" + name + ".png")
    bodyw, bodyh = body.size
    stamp = Image.open("./static/stamp.png")
    stw, sth = stamp.size

    xcor = round((bodyw - stw) / 2)
    ycor = round((bodyh - sth) / 2) + 200
    body.paste(stamp, (xcor, ycor))

    body.save("./static/new-" + name + ".png")
