"""
common configuration parameters
"""
import os


# Find the directory in which the current script resides:
FILE_DIR = os.path.dirname(os.path.realpath(__file__))

# SQLite database file path
DATABASE = FILE_DIR + "/pfinal.db"
UPLOAD_FOLDER = FILE_DIR + "/puploads"
LOG_FOLDER = FILE_DIR + "/plogs"
STATIC_FOLDER = FILE_DIR + "/static"
# Define allowed files
ALLOWED_EXTENSIONS = {"csv"}

PLANSHEADER = [
    "Exercise Name",
    "Beginner/Intermediate/Advanced",
    "How Many Days",
    "Csv File",
]
PLANHEADER = [
    "Day",
    "Exercise Name",
    "Number of Sets",
    "Number of Repetitions",
    "Effected Muscles",
    "Category",
    "Level",
]

EXERCISEHEADER = [
    "Exercise Name",
    "Muscle Groups Effected",
    "Core/Upper/Lower/Total Body",
    "Beginner/Intermediate/Advanced",
    "FullBody",
    "Traps",
    "MidBack",
    "Shoulders",
    "LowerBack",
    "Lats",
    "Glutes",
    "Hamstrings",
    "Calves",
    "Chest",
    "Obliques",
    "Abdominals",
    "Quads",
    "Biceps",
    "Forearms",
    "Triceps",
    "VideoLink",
]
RGBHEADER = ["Muscle", "R", "G", "B", "Percentage"]
DAYLIST = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
DAYSORTLIST = {"Mon": 0, "Tue": 1, "Wed": 2, "Thu": 3, "Fri": 4, "Sat": 5, "Sun": 6}
MUSCLELIST = [
    "FullBody",
    "Abdominals",
    "Biceps",
    "Calves",
    "Chest",
    "Forearms",
    "Glutes",
    "Hamstrings",
    "Lats",
    "LowerBack",
    "MidBack",
    "Obliques",
    "Quads",
    "Shoulders",
    "Traps",
    "Triceps",
]
