import os

# Find the directory we executed the script from:
#execution_dir = os.getcwd()

# Find the directory in which the current script resides:
FILE_DIR = os.path.dirname(os.path.realpath(__file__))


# SQLite database file path
DATABASE = FILE_DIR + "/pfinal.db"
CONTROLLIST = ['Log ID', 'Date', 'Description', 'Work Time (Formatted)',
               'Work Time (Seconds)', 'Rest Time (Formatted)', 'Rest Time (Seconds)',
               'Work Distance', 'Rest Distance', 'Stroke Rate/Cadence', 'Stroke Count',
               'Pace', 'Avg Watts', 'Cal/Hour', 'Total Cal', 'Avg Heart Rate',
               'Drag Factor', 'Age', 'Weight', 'Type', 'Ranked', 'Comments',
               'Date Entered']
TYPELIST = ["RowErg", "BikeErg", "SkiErg",
            "On-water", "On-snow",  "Paddle Adapter"]
MAX_BINS = 40
MAX_PACESTEPS = 10
MAX_PACE_MIN = 5
UPLOAD_FOLDER =  FILE_DIR + '/puploads'
LOG_FOLDER =  FILE_DIR + '/plogs'
STATIC_FOLDER = FILE_DIR + '/static'
# Define allowed files
ALLOWED_EXTENSIONS = {'csv'}



