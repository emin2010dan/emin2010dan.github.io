"""
 Administration tool
 1- create body images for program from original ones, giving new dimensions   
 2- create needed soreness images 
"""
from PIL import Image
import numpy as np

names = [
    "body0",
    "coloured_mask0",
    "body1",
    "coloured_mask1",
]

for name in names:
    # screen size
    imageWidth = 1824
    imageHeight = 762
    image_sheet = Image.new("RGB", (imageWidth, imageHeight), (255, 255, 255))

    small = Image.open("./static/org-" + name + ".png")
    samllw, smallh = small.size
    xcor = round((imageWidth - samllw) / 2)
    ycor = round((imageHeight - smallh) / 2)
    image_sheet.paste(small, (xcor, ycor))

    image_sheet.save("./static/" + name + ".png")

names = ["sore0", "sore1", "sore2", "sore3", "sore4"]
colors = [(255, 219, 172), (225, 165, 135), (195, 110, 97), (165, 55, 59), (136, 0, 21)]
i = 0
for name in names:
    # screen size
    imageWidth = 1824
    imageHeight = 762
    image_sheet = Image.new("RGB", (imageWidth, imageHeight), colors[i])
    image_sheet.save("./static/" + name + ".png")
    i = i + 1
