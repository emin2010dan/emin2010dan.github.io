# change image dimension

from PIL import Image

from PIL import Image
import numpy as np
names = ["body","coloured_mask","sore1","sore2","sore3","sore4","sore5"]

for name in names:
    #screen size
    imageWidth=1824
    imageHeight=762
    image_sheet = Image.new("RGB", (imageWidth, imageHeight), (255, 255, 255))


    small = Image.open("./static/org-" + name + ".png")
    samllw,smallh=small.size
    xcor = round((imageWidth - samllw) /2)
    ycor = round((imageHeight - smallh) /2)
    image_sheet.paste(small,(xcor,ycor))

    image_sheet.save("./static/"+ name+ ".png")



