#admin menu
from PIL import Image
#import numpy as np
import sqlite3 as sql
import os

def main():

    print("Administration menu:")
    print("1) Change original images background and create soreness files")
    print("2) Stamp images with stamp.pgn ")
    print("3) Delete all users and exercises in db")
    ans=input ("Your Chice:")
    match ans:
    
        case "1"  : 
            change_size()
        
        case "2" : 
            stamp()

        case "3" : 
            delete_db() 

        case _  : 
            print("Wrong choice")

def change_size():
    """
    Administration tool
    1- create body images for program from original ones, giving new dimensions   
    2- create needed soreness images 
    """

    names = [
        "body0",
        "coloured_mask0",
        "body1",
        "coloured_mask1",
    ]

    for name in names:
        # screen size
        imageWidth = 1824
        imageHeight = 762
        image_sheet = Image.new("RGB", (imageWidth, imageHeight), (255, 255, 255))

        small = Image.open("./static/org-" + name + ".png")
        samllw, smallh = small.size
        xcor = round((imageWidth - samllw) / 2)
        ycor = round((imageHeight - smallh) / 2)
        image_sheet.paste(small, (xcor, ycor))

        image_sheet.save("./static/" + name + ".png")

    names = ["sore0", "sore1", "sore2", "sore3", "sore4"]
    colors = [(255, 219, 172), (225, 165, 135), (195, 110, 97), (165, 55, 59), (136, 0, 21)]
    i = 0
    for name in names:
        # screen size
        imageWidth = 1824
        imageHeight = 762
        image_sheet = Image.new("RGB", (imageWidth, imageHeight), colors[i])
        image_sheet.save("./static/" + name + ".png")
        i = i + 1
    print("New files are ready")


def stamp():
    """
    Administration tool
    stamp images by mini soreness indicator images 
    """



    names = [
        "body0",
        "coloured_mask0",
        "body1",
        "coloured_mask1",
    ]

    for name in names:
  
        body = Image.open("./static/" + name + ".png")
        bodyw, bodyh = body.size
        stamp = Image.open("./static/stamp.png")
        stw, sth = stamp.size

        xcor = round((bodyw - stw) / 2)
        ycor = round((bodyh - sth) / 2) + 200
        body.paste(stamp, (xcor, ycor))

        body.save("./static/new-" + name + ".png")
        print("Stamped files are ready")

def delete_db():
    """ delete all records in db """
    # Find the directory in which the current script resides:
    FILE_DIR = os.path.dirname(os.path.realpath(__file__))

    # SQLite database file path
    DATABASE = FILE_DIR + "/pfinal.db"
    try:
        db = sql.connect(DATABASE)
        cur = db.cursor()

        cur.execute(  "DELETE FROM users ") 
        cur.execute(  "DELETE FROM exercises ") 
        db.commit()

    except Exception as e:
        err_message = f"Error occurred: {e}"
        print(f" delete_db: {err_message} ")
    finally:
        cur.close()
        db.close()



main()