echo "Yedek ismi bosluksuz"
read name
cd ..
if [ -d "yedekler" ]; then
  if [ -d "yedekler"/$name ]; then  
      echo "bu yedek zaten var"
      ls -l yedekler
      exit 1
    fi  
 if [ -d "main" ]; then
      cp -r main yedekler/$name
      cd yedekler/$name
      echo "gereksizleri sil(y/n)"
      pwd
      read ans
      if test $ans = "y"
          then

            find . -type d -name "__pycache__" -exec rm -rf "{}"  \;
            find . -type d -name ".git" -exec rm -rf "{}"  \;
            find . -type d -name ".vscode" -exec rm -rf "{}"  \;
            find . -type d -name ".git" -exec rm -rf "{}"  \;
            rm -rf ./logs/*
            rm -rf ./cs50pfinal/plogs/*
            rm -rf ./cs50pfinal/puploads/*
            rm -rf ./cs50pfinal/static/images/*
            rm -rf ./final/logs/*
            rm -rf ./final/uploads/*
            rm -rf ./final/static/images/*
            fi
      else
      echo "error: no main"
      exit 1
      fi
else
  echo "error: no yedekler"
  exit 1
fi   