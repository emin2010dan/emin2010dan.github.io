
mv ./logs/total.log ./logs/old.log
find .. -name app.log -exec cat {} \; > ./logs/total.log
find .. -name app.log -exec rm -f {} \; 
grep root ./logs/total.log > ./logs/summary.log
echo "-------ERROR-----------" >> ./logs/summary.log
grep ERROR ./logs/total.log >> ./logs/summary.log
echo "-------CRITICAL-----------" >> ./logs/summary.log
grep CRITICAL ./logs/total.log >> ./logs/summary.log
more ./logs/summary.log

