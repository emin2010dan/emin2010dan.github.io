#dispatcher.py
from flask import Flask
#from werkzeug.wsgi import DispatcherMiddleware #use the commented version below for Werkzeug >= v.1.0
from werkzeug.middleware.dispatcher import DispatcherMiddleware
#from werkzeug.exceptions import NotFound

#import sys
import os
import logging
FILE_DIR = os.path.dirname(os.path.realpath(__file__))
LOG_FOLDER =  FILE_DIR + '/logs'
log_filename = os.path.join(LOG_FOLDER,"app.log")
logging.basicConfig(filename=log_filename, filemode='a', format='%(asctime)s  %(name)s - %(levelname)s - %(message)s',  encoding='utf-8', level=logging.INFO)


#from p2.app import app as app2
#from p3.app import app as app3
#from p4.app import app as app4
from final.app import app as finalapp
from cs50pfinal.project import app as cs50pfinalapp

#sys.path.append(os.path.dirname(os.path.realpath(__file__)))

#sys.path.append("./final")
#sys.path.append("./cs50pfinal")

app = Flask(__name__)

app.wsgi_app = DispatcherMiddleware(finalapp, {
    '/p': cs50pfinalapp

})

if __name__ == "__main__":
    app.run()