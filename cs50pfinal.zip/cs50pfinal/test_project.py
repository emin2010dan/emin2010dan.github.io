import os
import sys
import logging
import sqlite3 as sql
from datetime import datetime
import copy
import csv
import re
import cv2
import numpy as np
from PIL import Image, ImageFilter
from flask import redirect, render_template, session, request
from functools import wraps
from datetime import datetime, timedelta
import os
import logging
import copy
import sqlite3 as sql


from project import (
    calculate_level_by_rhr,
    calculate_level_by_pushup,
    calculate_level_by_situp,
    calculate_level_by_squat,
)


def test_calculate_level_by_rhr():
    assert (
        calculate_level_by_rhr(0, 56, 60)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 49, 18)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 55, 25)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 49, 18)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 55, 25)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 49, 26)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 54, 35)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 50, 36)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 56, 45)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 50, 46)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 57, 55)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 51, 56)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 56, 65)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 50, 66)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 55, 95)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )

    assert (
        calculate_level_by_rhr(0, 56, 18)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 61, 25)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 55, 26)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 61, 35)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 57, 36)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 62, 45)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 58, 46)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 63, 55)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 57, 56)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 61, 65)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 56, 66)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 61, 95)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )

    assert (
        calculate_level_by_rhr(0, 62, 18)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 65, 25)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 62, 26)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 65, 35)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 63, 36)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 66, 45)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 64, 46)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 67, 55)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 62, 56)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 67, 65)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 62, 66)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 65, 95)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )

    assert (
        calculate_level_by_rhr(0, 66, 18)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 69, 25)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 66, 26)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 70, 35)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 67, 36)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 70, 45)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 68, 46)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 71, 55)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 68, 56)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 71, 65)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 66, 66)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 69, 95)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )

    assert (
        calculate_level_by_rhr(0, 70, 18)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 73, 25)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 71, 26)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 74, 35)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 71, 36)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 75, 45)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 72, 46)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 76, 55)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 72, 56)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 75, 65)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 70, 66)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 73, 95)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )

    assert (
        calculate_level_by_rhr(0, 74, 18)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 81, 25)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 75, 26)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 81, 35)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 76, 36)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 82, 45)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 77, 46)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 83, 55)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 76, 56)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 81, 65)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 74, 66)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(0, 79, 95)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )

    assert (
        calculate_level_by_rhr(1, 54, 18)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 60, 25)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 54, 26)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 59, 35)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 54, 36)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 59, 45)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 54, 46)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 60, 55)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 54, 56)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 59, 65)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 54, 66)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 59, 95)
        == "Your Heart Fitness level is ATHLETE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 61, 18)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 65, 25)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 60, 26)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 64, 35)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 60, 36)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 64, 45)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 61, 46)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 65, 55)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 60, 56)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 64, 65)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 60, 66)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 64, 95)
        == "Your Heart Fitness level is EXCEL'T acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 66, 18)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 69, 25)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 65, 26)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 68, 35)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 65, 36)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 69, 45)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 66, 46)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 69, 55)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 65, 56)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 68, 65)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 65, 66)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 68, 95)
        == "Your Heart Fitness level is GOOD acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 70, 18)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 73, 25)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 69, 26)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 72, 35)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 70, 36)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 73, 45)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 70, 46)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 73, 55)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 69, 56)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 73, 65)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 69, 66)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 72, 95)
        == "Your Heart Fitness level is ABOVE AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 74, 18)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 78, 25)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 73, 26)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 76, 35)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 74, 36)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 78, 45)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 74, 46)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 77, 55)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 74, 56)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 77, 65)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 73, 66)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 76, 95)
        == "Your Heart Fitness level is AVERAGE acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 79, 18)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 84, 25)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 77, 26)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 82, 35)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 79, 36)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 84, 45)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 78, 46)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 83, 55)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 78, 56)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 83, 65)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 77, 66)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 84, 95)
        == "Your Heart Fitness level is BELOW AV acording to sundried.com"
    )
    assert calculate_level_by_rhr(0, 84, 96) == "Your age is out of table limits"
    assert calculate_level_by_rhr(1, 84, 96) == "Your age is out of table limits"
    assert (
        calculate_level_by_rhr(0, 200, 95)
        == "Your Heart Fitness level is POOR acording to sundried.com"
    )
    assert (
        calculate_level_by_rhr(1, 200, 95)
        == "Your Heart Fitness level is POOR acording to sundried.com"
    )


def test_calculate_level_by_pushup():
    assert (
        calculate_level_by_pushup(0, 15, 60)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )

    assert (
        calculate_level_by_pushup(0, 47, 17)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 56, 19)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 39, 20)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 47, 29)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 34, 30)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 41, 39)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 28, 40)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 34, 49)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 25, 50)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 31, 59)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 24, 60)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 30, 65)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 35, 17)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 46, 19)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 30, 20)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 38, 29)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 25, 30)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 33, 39)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 21, 40)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 27, 49)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 18, 50)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 24, 59)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 17, 60)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 23, 65)
        == "Your Chest Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 19, 17)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 34, 19)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 17, 20)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 29, 29)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 13, 30)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 24, 39)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 11, 40)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 20, 49)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 9, 50)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 17, 59)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 6, 60)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 16, 65)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 11, 17)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 18, 19)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 10, 20)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 16, 29)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 8, 30)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 12, 39)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 6, 40)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 10, 49)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 5, 50)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 8, 59)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 3, 60)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 5, 65)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 4, 17)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 10, 19)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 4, 20)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 9, 29)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 2, 30)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 7, 39)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 1, 40)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 5, 49)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 1, 50)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 4, 59)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 1, 60)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 2, 65)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 17)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 3, 19)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 20)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 3, 29)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 30)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 1, 39)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 40)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 49)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 50)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 59)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 60)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 0, 65)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )

    assert (
        calculate_level_by_pushup(0, 57, 17)
        == "Your Chest Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(0, 31, 60)
        == "Your Chest Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 31, 17)
        == "Your Chest Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 13, 60)
        == "Your Chest Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert calculate_level_by_pushup(1, 31, 66) == "Your age is out of table limits"
    assert calculate_level_by_pushup(1, 13, 66) == "Your age is out of table limits"
    assert calculate_level_by_pushup(0, 31, 66) == "Your age is out of table limits"
    assert calculate_level_by_pushup(0, 13, 66) == "Your age is out of table limits"
    assert calculate_level_by_pushup(0, 13, -66) == "Your age is out of table limits"

    assert (
        calculate_level_by_pushup(1, 22, 17)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 30, 19)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 24, 20)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 32, 29)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 21, 30)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 28, 39)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 15, 40)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 20, 49)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 13, 50)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 16, 59)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 10, 60)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 12, 65)
        == "Your Chest Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 11, 17)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 21, 19)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 14, 20)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 23, 29)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 13, 30)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 20, 39)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 10, 40)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 14, 49)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 9, 50)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 12, 59)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 6, 60)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 9, 65)
        == "Your Chest Muscles Fitness level are Above Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 7, 17)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 10, 19)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 9, 20)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 13, 29)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 7, 30)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 12, 39)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 5, 40)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 9, 49)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 4, 50)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 8, 59)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 3, 60)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 5, 65)
        == "Your Chest Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 4, 17)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 6, 19)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 5, 20)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 8, 29)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 3, 30)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 6, 39)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 2, 40)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 4, 49)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 2, 50)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 3, 59)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 2, 60)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 2, 65)
        == "Your Chest Muscles Fitness level are Below average acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 17)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 3, 19)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 20)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 4, 29)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 30)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 2, 39)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 40)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 49)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 50)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 59)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 60)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 1, 65)
        == "Your Chest Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 17)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 19)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 20)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 29)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 30)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 39)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 40)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 49)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 50)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 59)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 60)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_pushup(1, 0, 65)
        == "Your Chest Muscles Fitness level are Very Poor acording to topendsports.com"
    )


def test_calculate_level_by_situp():
    assert (
        calculate_level_by_situp(0, 40, 60)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 50, 18)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 70, 25)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 46, 26)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 70, 35)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 42, 36)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 70, 45)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 36, 46)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 70, 55)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 32, 56)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 70, 65)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 29, 66)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 70, 70)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )

    assert (
        calculate_level_by_situp(0, 44, 18)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 49, 25)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 40, 26)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 45, 35)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 35, 36)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 41, 45)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 29, 46)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 35, 55)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 25, 56)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 31, 65)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 22, 66)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 28, 70)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 39, 18)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 43, 25)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 35, 26)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 39, 35)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 30, 36)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 34, 45)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 25, 46)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 28, 55)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 21, 56)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 24, 65)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 19, 66)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 21, 70)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 35, 18)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 38, 25)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 31, 26)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 34, 35)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 27, 36)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 29, 45)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 22, 46)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 24, 55)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 17, 56)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 20, 65)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 15, 66)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 18, 70)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 31, 18)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 34, 25)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 29, 26)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 30, 35)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 23, 36)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 26, 45)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 18, 46)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 21, 55)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 13, 56)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 16, 65)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 11, 66)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 14, 70)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 25, 18)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 30, 25)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 22, 26)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 28, 35)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 17, 36)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 22, 45)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 13, 46)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 17, 55)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 9, 56)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 12, 65)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 7, 66)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 10, 70)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 0, 18)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 24, 25)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 0, 26)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 21, 35)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 0, 36)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 16, 45)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 0, 46)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 12, 55)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 0, 56)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 8, 65)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 0, 66)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(0, 6, 70)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )

    assert calculate_level_by_situp(1, 13, 17) == "Your age is out of table limits"
    assert calculate_level_by_situp(0, 31, 17) == "Your age is out of table limits"

    assert (
        calculate_level_by_situp(1, 44, 18)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 70, 25)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 40, 26)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 70, 35)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 34, 36)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 70, 45)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 28, 46)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 70, 55)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 25, 56)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 70, 65)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 24, 66)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 70, 70)
        == "Your Core Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 37, 18)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 43, 25)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 33, 26)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 39, 35)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 27, 36)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 33, 45)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 22, 46)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 27, 55)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 18, 56)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 24, 65)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 17, 66)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 23, 70)
        == "Your Core Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 33, 18)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 36, 25)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 29, 26)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 32, 35)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 23, 36)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 26, 45)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 18, 46)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 21, 55)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 13, 56)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 17, 65)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 14, 66)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 16, 70)
        == "Your Core Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 29, 18)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 32, 25)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 25, 26)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 28, 35)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 19, 36)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 22, 45)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 14, 46)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 17, 55)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 10, 56)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 12, 65)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 11, 66)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 13, 70)
        == "Your Core Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 25, 18)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 28, 25)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 21, 26)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 24, 35)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 15, 36)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 18, 45)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 10, 46)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 13, 55)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 7, 56)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 9, 65)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 5, 66)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 10, 70)
        == "Your Core Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 18, 18)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 24, 25)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 13, 26)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 20, 35)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 7, 36)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 14, 45)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 5, 46)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 9, 55)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 3, 56)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 6, 65)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 2, 66)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 4, 70)
        == "Your Core Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 0, 18)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 17, 25)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 0, 26)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 12, 35)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 0, 36)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 6, 45)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 0, 46)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 4, 55)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 0, 56)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 2, 65)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 0, 66)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_situp(1, 1, 70)
        == "Your Core Muscles Fitness level are Very Poor acording to topendsports.com"
    )


def test_calculate_level_by_squat():
    assert (
        calculate_level_by_squat(0, 24, 60)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 35, 20)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 70, 29)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 33, 30)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 70, 39)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 30, 40)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 70, 49)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 27, 50)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 70, 59)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 24, 60)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 70, 70)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )

    assert (
        calculate_level_by_squat(0, 33, 20)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 34, 29)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 30, 30)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 32, 39)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 27, 40)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 29, 49)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 24, 50)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 26, 59)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 21, 60)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 23, 70)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )

    assert (
        calculate_level_by_squat(0, 30, 20)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 32, 29)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 27, 30)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 29, 39)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 24, 40)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 26, 49)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 21, 50)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 23, 59)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 18, 60)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 20, 70)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 27, 20)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 29, 29)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 24, 30)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 26, 39)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 21, 40)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 23, 49)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 18, 50)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 20, 59)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 15, 60)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 17, 70)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 24, 20)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 26, 29)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 21, 30)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 23, 39)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 18, 40)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 20, 49)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 15, 50)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 17, 59)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 12, 60)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 14, 70)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 21, 20)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 23, 29)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 18, 30)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 20, 39)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 15, 40)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 17, 49)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 12, 50)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 14, 59)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 9, 60)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 11, 70)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 0, 20)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 20, 29)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 0, 30)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 17, 39)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 0, 40)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 14, 49)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 0, 50)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 11, 59)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 0, 60)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(0, 8, 70)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )

    assert (
        calculate_level_by_squat(1, 30, 20)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 70, 29)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 27, 30)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 70, 39)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 24, 40)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 70, 49)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 21, 50)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 70, 59)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 18, 60)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 70, 70)
        == "Your Leg Muscles Fitness level are Excellent acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 27, 20)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 29, 29)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 24, 30)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 26, 39)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 21, 40)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 23, 49)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 18, 50)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 20, 59)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 15, 60)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 17, 70)
        == "Your Leg Muscles Fitness level are Good acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 24, 20)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 26, 29)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 21, 30)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 23, 39)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 18, 40)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 20, 49)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 15, 50)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 17, 59)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 12, 60)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 14, 70)
        == "Your Leg Muscles Fitness level are Above average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 21, 20)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 23, 29)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 18, 30)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 20, 39)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 15, 40)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 17, 49)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 12, 50)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 14, 59)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 9, 60)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 11, 70)
        == "Your Leg Muscles Fitness level are Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 18, 20)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 20, 29)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 15, 30)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 17, 39)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 12, 40)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 14, 49)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 9, 50)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 11, 59)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 6, 60)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 8, 70)
        == "Your Leg Muscles Fitness level are Below Average acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 15, 20)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 17, 29)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 12, 30)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 14, 39)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 9, 40)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 11, 49)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 6, 50)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 8, 59)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 3, 60)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 5, 70)
        == "Your Leg Muscles Fitness level are Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 0, 20)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 14, 29)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 0, 30)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 11, 39)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 0, 40)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 8, 49)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 0, 50)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 5, 59)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 0, 60)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )
    assert (
        calculate_level_by_squat(1, 2, 70)
        == "Your Leg Muscles Fitness level are Very Poor acording to topendsports.com"
    )

    assert calculate_level_by_squat(1, 13, 19) == "Your age is out of table limits"
    assert calculate_level_by_squat(0, 31, 19) == "Your age is out of table limits"
