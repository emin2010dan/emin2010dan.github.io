


# CS50P Final Project : Fitness Tracker
#### Video Demo:  https://youtu.be/3oUe_uLSNXY








#### Description: As an old rower my biggest problem is overloading. I have injured myself countless times because it is very hard to calculate the load of rowing and cycling workouts compared to fitness ones.  I wrote a program to track fitness workouts and body soreness to prevent overloading.








#### How To Use:





1- Enter my home page [Home Page](https://emin2010dan.github.io/) and from the Sport Calculators page go to the Cs50p project  at the top of the page. Press the `Go to CS50P Final Project` button.








2- Or use this link to connect the project directly. [CS50P Final Project Page](https://emin2010dan.pythonanywhere.com/p/login)








3-  Every user needs to register. A user record is needed to differentiate their body type, recovery level and csv plan files. Please do not use your real name or banking passwords.




![Register page image](https://i.ibb.co/0YczL2P/Ekran-g-r-nt-s-2023-10-11-102231.png)




4- Login after the registration




![Login page image](https://i.ibb.co/stgkqvw/Ekran-g-r-nt-s-2023-10-11-102158.png)








5- After login, you will see your body image according to the choice you made in registration. Colors of muscles are changed when you do exercises from rested (light) colors to tired (dark) colors. When you rest enough, the colors of muscles become lighter and your soreness level drops. Your recovery performance is calculated according to the info you give in registration. At the left of the page, you will see the exercises you have done and the exercises you plan to do today. At the right side of the screen, you will see fitness advice of the program.




![Main Screen image](https://i.ibb.co/k5HZx8B/Ekran-g-r-nt-s-2023-10-11-102336.png)




6- First, you have to select an exercise plan by Clicking "Select Plan" link. Program asks for the days you want to exercise and lists selection boxes according to the number of days you plan to exercise.




![Select Plan image](https://i.ibb.co/GQ16R51/Ekran-g-r-nt-s-2023-10-11-102519.png)




7- If you choose more days, the system offers different plans for you. All exercise plans and exercise lists are offered by AIs. I used bard and chatgpt for the planning of exercises and decided to choose chatgpt's plans.  




![Select Plan image2](https://i.ibb.co/WvCT6JR/Ekran-g-r-nt-s-2023-10-11-102556.png)




8- When you choose a plan, the program lists it and asks for confirmation.




![Accept Plan Image](https://i.ibb.co/jk0VVxH/Ekran-g-r-nt-s-2023-10-11-102642.png)




9- After the plan is selected, you will see today's workout at the left of the screen if it is not a rest day.




![Main screen with plan Image](https://i.ibb.co/nLcXX45/Ekran-g-r-nt-s-2023-10-11-103036.png)




10- You can add, delete or change sets/repetitions of exercises by "Change Plan" link. After changing the sets and/or repetitions press the "Update" button.




![Change Plan Image](https://i.ibb.co/MBZRJHG/Ekran-g-r-nt-s-2023-10-11-102731.png)




10- To add a new exercise, you have to select the muscle that you want to activate first. The selection may be a specific muscle or general term as (Upper/Lower/core) or Fullbody. Program will offer exercises according to this choice. After entering sets and repetitions press "Add an Exercise" link.




![Change Plan Image2](https://i.ibb.co/k0WkhWV/Ekran-g-r-nt-s-2023-10-11-102838.png)




11- To get the copy of the plan, use the "Get Plan" link. A csv file will be downloaded to your system.




![Get Plan Image](https://i.ibb.co/TkK4ffm/Ekran-g-r-nt-s-2023-10-11-102938.png)




12- After the workout is done, you have to record it by "Record Workout" link. You may change the number of sets, repetitions, or cancel some exercises in the workout. You may change the workout day and decide to do it on a different day. If you want to add exercise, you have to change the plan first. In this page you will click the exercises you have done, change set/repetitions and enter Intensity level of exercise. If it is light, the program decreases the soreness level by half, if it is hard, soreness level is increased.




![Record Workout Image](https://i.ibb.co/HNyzXk1/Ekran-g-r-nt-s-2023-10-11-103150.png)




13- After the recording of workout, your soreness level of muscles changes according to the set number and intensity of exercises. If it is normal intensity and 3 sets, the program gives a normal soreness level. If you do more sets, soreness will be increased proportionally. Every exercise affects different muscles so some of your muscles' color may remain light while others become dark. Total Soreness level is calculated using the muscle's mass ratio. All muscles-exercise relation and muscles-body ratio data were given by chatgpt.




![Body After workout Image](https://i.ibb.co/W0kz5Pg/Ekran-g-r-nt-s-2023-10-11-103226.png)




14- Recorded exercises can be listed and/or deleted by "Change Workout" Link. You can change your past workouts also. After the deletion you can enter new exercises by "Record Workout" link.




![Change Workout Image](https://i.ibb.co/F416FNz/Ekran-g-r-nt-s-2023-10-11-103600.png)




15- After a heavy workout, your soreness level is increased a lot so the system may give you warnings at the right side of the screen if needed. Muscles under the risk of injury will be listed and the planned exercises that affect these muscles are given with a warning.




![Bod after heavy workout Image](https://i.ibb.co/897BDP9/Ekran-g-r-nt-s-2023-10-11-103529.png)








16- To download all workout data to your system, use the "Get Workout" link. Data will be in csv format.




![Get Workout Image](https://i.ibb.co/R7zRHx9/Ekran-g-r-nt-s-2023-10-11-103644.png)




17- You can change your Recovery level, body type and/or password by "Change Profile" link.




![Change Profile Image](https://i.ibb.co/wRmK2qR/Ekran-g-r-nt-s-2023-10-11-103744.png)




18- If you choose Female body type, the image in the main screen will be changed. At the right side of the screen, the program gives critical advice if there is heavy risk of injury today. It is best to cancel some planned exercises.




![Female Body Type Image](https://i.ibb.co/f47L7ZR/Ekran-g-r-nt-s-2023-10-11-104028.png)




19- You have to check your fitness level once in every month. To do this use the "Check Level" link. This link gives you 4 tests.




![Check Level Image](https://i.ibb.co/hF4z5tV/Ekran-g-r-nt-s-2023-10-11-104100.png)




Heart Fitness Level: using your resting heart rate  and age, this menu gives your level. I use the data from:
https://www.sundried.com/blogs/training/heart-rate-recovery-and-fitness-levels




Chest Muscles Fitness Level: using your pushup number and age, this menu gives your chest level. I use the data from:
https://www.topendsports.com/testing/tests/home-pushup.htm




Core Muscles Fitness Level: using your situp number in 1 minute and age, this menu gives your core level. I use the data from:
https://www.topendsports.com/testing/tests/home-situp.htm




Leg Muscles Fitness Level: using your squat number (Chair Height) and age, this menu gives your leg level. I use the data from:
https://www.topendsports.com/testing/tests/home-squat.htm












#### Design Issues:








I use Flask for this project. Project is installed in pythonanywhere. Also connected to my  [Home Page](https://emin2010dan.github.io/) .


Project is designed to work stand alone and also under a dispatcher. My aim is to collect all of my fitness related projects(cs50x final project is also fitness related) under a dispatcher. Program checks files' directory and working directory to understand the working environment. All imports of modules and links are changed according to that.

If you want to run project in Harvard's workspace, the directory is : `/workspaces/140657365/cs50pfinal`
Please use the command: `flask --app project run`
The link to use the program is:https://laughing-memory-wr79546vgx7xhgpg-5000.app.github.dev/login



The most time consuming part of the project was finding trusted fitness exercise data and plans. The free data that I found is mostly missing. So I decided to use artificial Intelligence. I prompted bard and chatgpt a lot and created a big exercise table that gives a lot of exercises and affected muscles. Also 1-6 working days exercise plans are created for home and gym beginners. Intermediate plans are also professionally prepared for 3-6 working days. Since Intermediate level uses more weights, these plans are prepared to give more time to recover muscles.




Generating needed images and masks were also a problem that I solved with the help of an ai (imagine.art). The most difficult part was to persuade the AI to generate simple images. It mostly created very good images but they were very complex to use. At the end, I colorized the muscles in an image and created muscle maps for the program.




Originally the program was slow because there are a lot of image pasting operations. Every muscle has its mask and including background, generating a single body image needs 16 pasting, 33 image reading operations. To speed up, I hold the images in memory. This solves the waiting time problem. Program creates masks once in initial load and holds them in memory. It also saves them to disk for debugging purposes.




I only use db to record workouts, not plans of users. Every user's plan is saved in a separate excel. Plans are changed a lot before the workout so no need to use db.  












#### Contact Info:
- Name: Hayrettin Emin Demirel
- Email: emin2010dan@gmail.com
- City: Istanbul
- Country: Turkey
- Age: 60
- Profession: Computer Engineer(Retired)
- School: Middle East Technical University
- [Home Page](https://emin2010dan.github.io/)


- [CS50P Final Project Page](https://emin2010dan.pythonanywhere.com/p/login)




#### Files:




- project.py: Main Program. To run in Harvard's environment please use: flask --app  project run


- test_project.py: Test of 4 functions in main program


- pmodules.py: Modules for Main program


- pconfig.py: All global variables that are shared between modules are defined here.


- pfinal.db: user and workout records


- padmin.py: Administrator procedures to create initial images and clear db


- static/styles.css : all styles needed in Flask


- static/*.csv : csv files for exercises and plans


- static/*.png : images and masks of body



